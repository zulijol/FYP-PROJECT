<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('assessment_responses', function (Blueprint $table) {
            // Remove the columns you don't want
            $table->dropColumn('description');      // Remove Column E (description)
            $table->dropColumn('score_value');      // Remove score_value generated column
            $table->dropColumn('needs_attention');  // Remove needs_attention generated column
            
            // Note: is_answered column stays because you want to keep it
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('assessment_responses', function (Blueprint $table) {
            // Add back the columns if you rollback
            $table->text('description')->nullable();                // Add back Column E
            $table->integer('score_value')->nullable();             // Add back score_value
            $table->boolean('needs_attention')->default(false);     // Add back needs_attention
        });
    }
};