<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // First, let's check what columns actually exist
        $existingColumns = Schema::getColumnListing('users');
        
        Schema::table('users', function (Blueprint $table) use ($existingColumns) {
            
            // =====================================
            // 1. REMOVE FORTIFY 2FA COLUMNS (if they exist)
            // =====================================
            if (in_array('two_factor_secret', $existingColumns)) {
                $table->dropColumn('two_factor_secret');
            }
            
            if (in_array('two_factor_recovery_codes', $existingColumns)) {
                $table->dropColumn('two_factor_recovery_codes');
            }
            
            if (in_array('two_factor_confirmed_at', $existingColumns)) {
                $table->dropColumn('two_factor_confirmed_at');
            }
            
            // =====================================
            // 2. ADD EMAIL 2FA COLUMNS (if they don't exist)
            // =====================================
            if (!in_array('two_factor_code', $existingColumns)) {
                $table->string('two_factor_code', 6)->nullable()->after('email_verified_at');
            }
            
            if (!in_array('two_factor_expires_at', $existingColumns)) {
                $table->timestamp('two_factor_expires_at')->nullable()->after('two_factor_code');
            }
            
            if (!in_array('two_factor_enabled', $existingColumns)) {
                $table->boolean('two_factor_enabled')->default(false)->after('two_factor_expires_at');
            }
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Re-add Fortify columns
            $table->text('two_factor_secret')->nullable();
            $table->text('two_factor_recovery_codes')->nullable();
            $table->timestamp('two_factor_confirmed_at')->nullable();
            
            // Remove our email 2FA columns
            $table->dropColumn([
                'two_factor_code',
                'two_factor_expires_at',
                'two_factor_enabled',
            ]);
        });
    }
};