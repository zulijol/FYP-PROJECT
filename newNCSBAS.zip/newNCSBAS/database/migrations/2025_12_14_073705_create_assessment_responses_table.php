<?php
// File: 2024_12_14_000002_create_assessment_responses_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('assessment_responses', function (Blueprint $table) {
            $table->id();
            
            // Foreign key to uploads table
            $table->foreignId('assessment_upload_id')->constrained('assessment_uploads')->onDelete('cascade');
            
            // ========== EXCEL COLUMNS (A-G) ==========
            $table->integer('question_number');                     // Column A
            $table->string('domain', 50)->nullable();               // Column B
            $table->string('category', 200)->nullable();            // Column C
            $table->string('element', 200)->nullable();             // Column D
            $table->text('description')->nullable();                // Column E
            $table->text('questionnaire');                          // Column F
            $table->string('response', 10)->nullable();             // Column G
            // =========================================
            
            // Generated columns for easier querying
            $table->integer('score_value')->virtualAs(
                "CASE 
                    WHEN UPPER(response) = 'YES' THEN 1
                    WHEN UPPER(response) = 'NO' THEN 0
                    ELSE NULL
                END"
            );
            
            $table->boolean('is_answered')->virtualAs(
                "response IS NOT NULL AND response != '' AND UPPER(response) IN ('YES', 'NO')"
            );
            
            $table->boolean('needs_attention')->virtualAs(
                "UPPER(response) = 'NO'"
            );
            
            // Timestamps
            $table->timestamps();
            
            // Indexes
            $table->index(['assessment_upload_id', 'question_number']);
            $table->index('domain');
            $table->index('response');
            $table->index('is_answered');
            $table->index('needs_attention');
            $table->index('score_value');
            
            // Unique constraint to prevent duplicate questions in same upload
            $table->unique(['assessment_upload_id', 'question_number'], 'unique_upload_question');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('assessment_responses');
    }
};