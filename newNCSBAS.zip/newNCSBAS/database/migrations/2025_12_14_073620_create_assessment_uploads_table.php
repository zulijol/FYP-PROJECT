<?php
// File: 2024_12_14_000001_create_assessment_uploads_table.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('assessment_uploads', function (Blueprint $table) {
            $table->id();
            $table->string('upload_id', 50)->unique(); // Custom ID for easier reference
            $table->string('file_name');
            $table->string('original_file_name')->nullable();
            $table->string('organization_name');
            $table->date('assessment_date');
            $table->string('assessment_type')->default('Baseline');
            
            // User info
            $table->string('uploaded_by');
            $table->string('uploaded_by_email')->nullable();
            
            // Processing status
            $table->enum('processing_status', ['uploaded', 'processing', 'completed', 'failed'])
                  ->default('uploaded');
            $table->text('error_message')->nullable();
            
            // Calculated scores
            $table->integer('total_questions')->default(0);
            $table->integer('answered_questions')->default(0);
            $table->integer('yes_count')->default(0);
            $table->integer('no_count')->default(0);
            $table->decimal('overall_score', 5, 2)->default(0.00);
            
            // Timestamps
            $table->timestamp('processing_completed_at')->nullable();
            $table->timestamps();
            
            // Indexes
            $table->index('upload_id');
            $table->index('organization_name');
            $table->index('processing_status');
            $table->index('uploaded_by');
            $table->index('created_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('assessment_uploads');
    }
};