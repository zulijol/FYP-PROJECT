<?php
// database/migrations/2024_12_14_000003_remove_all_calculation_columns_from_tables.php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Remove from assessment_uploads
        Schema::table('assessment_uploads', function (Blueprint $table) {
            // Remove ALL calculation columns
            $table->dropColumn([
                'total_questions',
                'answered_questions',
                'yes_count',        // ← Remove this
                'no_count',         // ← Remove this
                'overall_score',
                'processing_completed_at',
                'error_message'
            ]);
        });

        // 2. Remove from assessment_responses
        Schema::table('assessment_responses', function (Blueprint $table) {
            $table->dropColumn('is_answered');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // 1. Add back to assessment_uploads
        Schema::table('assessment_uploads', function (Blueprint $table) {
            $table->integer('total_questions')->default(0)->after('assessment_type');
            $table->integer('answered_questions')->default(0)->after('total_questions');
            $table->integer('yes_count')->default(0)->after('answered_questions');
            $table->integer('no_count')->default(0)->after('yes_count');
            $table->decimal('overall_score', 5, 2)->default(0.00)->after('no_count');
            $table->timestamp('processing_completed_at')->nullable()->after('overall_score');
            $table->text('error_message')->nullable()->after('processing_completed_at');
        });

        // 2. Add back to assessment_responses
        Schema::table('assessment_responses', function (Blueprint $table) {
            $table->boolean('is_answered')->virtualAs(
                "response IS NOT NULL AND response != '' AND UPPER(response) IN ('YES', 'NO')"
            )->after('response');
        });
    }
};