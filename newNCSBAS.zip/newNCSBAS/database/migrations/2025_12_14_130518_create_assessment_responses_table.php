<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('assessment_responses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('assessment_id')->constrained()->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->integer('number')->nullable();
            $table->string('domain')->nullable();
            $table->string('category')->nullable();
            $table->string('element')->nullable();
            $table->text('description')->nullable();
            $table->text('question');
            $table->enum('response', ['Yes', 'No'])->nullable();
            $table->timestamp('uploaded_at')->nullable();
            $table->timestamps();
            
            // Indexes for better performance
            $table->index(['assessment_id', 'user_id']);
            $table->index(['domain']);
            $table->index(['category']);
            $table->index(['element']);
            $table->index(['response']);
            $table->index(['user_id']);
            $table->index(['number']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('assessment_responses');
    }
};