<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesAndPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create roles if they don't exist
        $adminRole = Role::firstOrCreate(['name' => 'admin']);
        $assessorRole = Role::firstOrCreate(['name' => 'assessor']);
        $reviewerRole = Role::firstOrCreate(['name' => 'reviewer']);

        // Create permissions if they don't exist
        $permissions = [
            // Assessment Permissions
            'create assessment',
            'view own assessments',
            'view all assessments',
            'edit assessment',
            'delete assessment',
            'download assessment',
            
            // Maturity Calculation Permissions
            'calculate maturity',
            'view maturity dashboard',
            'download maturity report',
            
            // Review Permissions
            'review assessment',
            'approve assessment',
            'reject assessment',
            'add feedback',
            
            // User Management Permissions
            'view users',
            'create users',
            'edit users',
            'delete users',
            'assign roles',
            
            // System Permissions
            'manage system settings',
            'view audit logs',
            'export data',
        ];

        foreach ($permissions as $permission) {
            Permission::firstOrCreate(['name' => $permission]);
        }

        // ============================================
        // ASSIGN PERMISSIONS TO ROLES
        // ============================================
        
        // ADMIN: All permissions
        $adminRole->syncPermissions(Permission::all());
        
        // ASSESSOR: Assessment-related permissions
        $assessorRole->syncPermissions([
            'create assessment',
            'view own assessments',
            'edit assessment',
            'delete assessment',
            'download assessment',
            'calculate maturity',
            'view maturity dashboard',
            'download maturity report',
        ]);
        
        // REVIEWER: Review and view permissions
        $reviewerRole->syncPermissions([
            'view all assessments',
            'review assessment',
            'approve assessment',
            'reject assessment',
            'add feedback',
            'view maturity dashboard',
            'export data',
        ]);
    }
}