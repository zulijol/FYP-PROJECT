<?php

return [
    
    'Cyber Security Policy' => [
        0 => 0,
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3, 
    ],
 
    'Cyber Security Objectives' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Resources (Manpower & Budget)' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3, 
    ],

    'Authorities and Special Interest Group' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Cyber Security Awareness and Training' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'IT Acceptable Use Policy' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Cyber Security Audit' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3, 
    ],

    'Supplier Relationship Security' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Asset Management' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3, 
    ],

    'Capacity Management' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 2, 
        4 => 3, 
    ],

    'Risk Assessment' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],

    'Risk Treatment' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],

    'Change Management' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3, 
    ],

    'Data Leakage Prevention (DLP)' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Data Privacy and Protection' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],

    'Software and Application Security' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],

    'Secure Configuration' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Non-Disclosure Agreement (NDA)' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Physical Security Procedure' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],

    'Security Perimeters' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Network Security Policies and Procedures' => [
        0 => 0, 
        1 => 0, 
        2 => 0, 
        3 => 1, 
        4 => 2, 
        5 => 3,
    ],

    'Physical and Logical Network Diagrams' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3, 
    ],

    'Network Security Controls' => [
        0 => 0, 
        1 => 1, 
        2 => 1, 
        3 => 2, 
        4 => 3, 
    ],

    'Malware Detection and Prevention' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3,
    ],

    'Identity and Access Management (IAM)' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3,
    ],

    'Segregation of Duties' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Password Management System' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3,
    ],

    'Vulnerability Management Procedure' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 3,
    ],

    'Vulnerability Assessment' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],

    'Event Management' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Incident Procedure and Handling' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3, 
    ],

    'Business Continuity Plan' => [
        0 => 0, 
        1 => 1, 
        2 => 2, 
        3 => 3,
    ],

    'Testing and Simulation' => [
        0 => 0, 
        1 => 0, 
        2 => 1, 
        3 => 2, 
        4 => 2, 
        5 => 3,
    ],
];