<?php
// app/Helpers/AssessmentHelper.php

if (!function_exists('getMaturityColor')) {
    function getMaturityColor(int $level): string
    {
        return match($level) {
            0 => 'danger',     // Red
            1 => 'warning',    // Yellow/Orange
            2 => 'info',       // Blue
            3 => 'success',    // Green
            default => 'secondary',
        };
    }
}