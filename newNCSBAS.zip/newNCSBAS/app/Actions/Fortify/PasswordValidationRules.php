<?php

namespace App\Actions\Fortify;

use Illuminate\Validation\Rules\Password;

trait PasswordValidationRules
{
    /**
     * Get the validation rules used to validate passwords.
     *
     * @return array<int, \Illuminate\Contracts\Validation\Rule|array<mixed>|string>
     */
protected function passwordRules(): array
{
    return [
        'required',
        'string',
        Password::min(8) // Minimum length of 8 characters
            ->letters() // At least one letter
            ->mixedCase() // Must contain both uppercase and lowercase letters
            ->numbers() // At least one number
            ->symbols() // At least one special character (e.g., @, #, $, etc.)
            ->uncompromised(), // Ensures password is not too common (checks against known compromised passwords)
        'confirmed', // Password confirmation
    ];
}
}
