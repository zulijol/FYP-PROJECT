<?php

namespace App\Services;

use App\Models\AssessmentResponse;
use Illuminate\Support\Collection;

class MaturityCalculatorService
{
    protected $maturityConfig;
    protected $totalElements = 33; // Fixed: You have 33 elements
    
    public function __construct()
    {
        $this->maturityConfig = config('maturity');
    }
    
    /**
     * Calculate maturity for a specific assessment
     */
    public function calculateForAssessment(int $assessmentId)
    {
        // Get all responses for this assessment
        $responses = AssessmentResponse::where('assessment_id', $assessmentId)->get();
        
        // Group responses by element for easier processing
        $responsesByElement = $responses->groupBy('element');
        
        // Step 1: Calculate element maturity levels and details
        $elementResults = $this->calculateElementLevels($responsesByElement);
        
        // Step 2: Calculate overall maturity score (0.00-1.00)
        $overallMaturity = $this->calculateOverallMaturity($elementResults['details']);
        
        // Step 3: Calculate category maturity (average of elements in category)
        $categoryResults = $this->calculateCategoryLevels($responses, $elementResults['levels']);
        
        // Step 4: Calculate domain maturity (average of categories in domain)
        $domainResults = $this->calculateDomainLevels($responses, $categoryResults['levels']);
        
        return [
            'assessment_id' => $assessmentId,
            'calculated_at' => now(),
            'overall_maturity' => $overallMaturity,
            'elements_started' => $this->countElementsStarted($elementResults['details']),
            'total_elements' => $this->totalElements,
            'domains' => $domainResults,
            'categories' => $categoryResults,
            'elements' => $elementResults,
        ];
    }
    
    /**
     * Calculate element-level maturity (0-3 for each of 33 elements)
     */
    private function calculateElementLevels(Collection $responsesByElement)
    {
        $elementLevels = [];
        $elementDetails = [];
        
        foreach ($this->maturityConfig as $elementName => $scoringArray) {
            $elementResponses = $responsesByElement->get($elementName, collect());
            
            // Count Yes responses for this element
            $yesCount = $elementResponses->where('response', 'Yes')->count();
            
            // Get maturity level from config array
            $maxIndex = count($scoringArray) - 1;
            $index = min($yesCount, $maxIndex);
            $level = $scoringArray[$index];
            
            // Store results
            $elementLevels[$elementName] = $level;
            $elementDetails[$elementName] = [
                'level' => $level,
                'yes_count' => $yesCount,
                'has_started' => $yesCount >= 1, // For overall calculation
                'total_questions' => $elementResponses->count(),
                'max_possible_yes' => $maxIndex,
                'next_level_required' => $this->getYesNeededForNextLevel($elementName, $yesCount),
                'questions' => $elementResponses->map(function($response) {
                    return [
                        'question' => $response->question,
                        'response' => $response->response
                    ];
                })->toArray()
            ];
        }
        
        return [
            'levels' => $elementLevels,
            'details' => $elementDetails
        ];
    }
    
    /**
     * Calculate overall maturity score (0.00-1.00)
     * Formula: (Elements with ≥1 YES) ÷ 33
     */
    private function calculateOverallMaturity(array $elementDetails): float
    {
        $elementsWithYes = $this->countElementsStarted($elementDetails);
        
        return round($elementsWithYes / $this->totalElements, 2);
    }
    
    /**
     * Count how many elements have at least 1 YES
     */
    private function countElementsStarted(array $elementDetails): int
    {
        $count = 0;
        
        foreach ($elementDetails as $details) {
            if ($details['has_started']) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * Calculate how many more Yes needed for next level
     */
    private function getYesNeededForNextLevel(string $elementName, int $currentYes): int
    {
        $scoringArray = $this->maturityConfig[$elementName];
        $currentLevel = $scoringArray[min($currentYes, count($scoringArray) - 1)];
        
        // If already at max level (3)
        if ($currentLevel === 3) {
            return 0;
        }
        
        // Find next level threshold
        for ($i = $currentYes + 1; $i < count($scoringArray); $i++) {
            if ($scoringArray[$i] > $currentLevel) {
                return $i - $currentYes;
            }
        }
        
        return 0;
    }
    
    /**
     * Calculate category-level maturity
     */
    private function calculateCategoryLevels(Collection $responses, array $elementLevels)
    {
        // Get unique categories
        $categories = $responses->pluck('category')->unique()->filter()->values();
        
        $categoryLevels = [];
        $categoryDetails = [];
        
        foreach ($categories as $category) {
            // Get all elements in this category
            $categoryElements = $responses->where('category', $category)
                ->pluck('element')
                ->unique()
                ->values();
            
            $elementScores = [];
            $total = 0;
            $count = 0;
            
            foreach ($categoryElements as $element) {
                if (isset($elementLevels[$element])) {
                    $elementScores[] = [
                        'element' => $element,
                        'level' => $elementLevels[$element]
                    ];
                    $total += $elementLevels[$element];
                    $count++;
                }
            }
            
            $average = $count > 0 ? $total / $count : 0;
            
            $categoryLevels[$category] = round($average, 2);
            $categoryDetails[$category] = [
                'average' => round($average, 2),
                'element_count' => $count,
                'elements' => $elementScores,
                'weakest_element' => $this->findMinMaxElement($elementScores, 'min'),
                'strongest_element' => $this->findMinMaxElement($elementScores, 'max')
            ];
        }
        
        return [
            'levels' => $categoryLevels,
            'details' => $categoryDetails
        ];
    }
    
    /**
     * Calculate domain-level maturity
     */
    private function calculateDomainLevels(Collection $responses, array $categoryLevels)
    {
        // Get unique domains
        $domains = $responses->pluck('domain')->unique()->filter()->values();
        
        $domainLevels = [];
        $domainDetails = [];
        
        foreach ($domains as $domain) {
            // Get all categories in this domain
            $domainCategories = $responses->where('domain', $domain)
                ->pluck('category')
                ->unique()
                ->values();
            
            $categoryScores = [];
            $total = 0;
            $count = 0;
            
            foreach ($domainCategories as $category) {
                if (isset($categoryLevels[$category])) {
                    $categoryScores[] = [
                        'category' => $category,
                        'score' => $categoryLevels[$category]
                    ];
                    $total += $categoryLevels[$category];
                    $count++;
                }
            }
            
            $average = $count > 0 ? $total / $count : 0;
            
            $domainLevels[$domain] = round($average, 2);
            $domainDetails[$domain] = [
                'average' => round($average, 2),
                'category_count' => $count,
                'categories' => $categoryScores,
                'weakest_category' => $this->findMinMaxCategory($categoryScores, 'min'),
                'strongest_category' => $this->findMinMaxCategory($categoryScores, 'max')
            ];
        }
        
        return [
            'levels' => $domainLevels,
            'details' => $domainDetails
        ];
    }
    
    private function findMinMaxElement(array $elements, string $type): ?array
    {
        if (empty($elements)) {
            return null;
        }
        
        usort($elements, function($a, $b) use ($type) {
            return $type === 'min' ? $a['level'] <=> $b['level'] : $b['level'] <=> $a['level'];
        });
        
        return $elements[0];
    }
    
    private function findMinMaxCategory(array $categories, string $type): ?array
    {
        if (empty($categories)) {
            return null;
        }
        
        usort($categories, function($a, $b) use ($type) {
            return $type === 'min' ? $a['score'] <=> $b['score'] : $b['score'] <=> $a['score'];
        });
        
        return $categories[0];
    }
    
    /**
     * Format data for radar charts
     */
    public function formatForRadarCharts(array $results): array
    {
        return [
            'element' => [
                'labels' => array_keys($results['elements']['levels']),
                'data' => array_values($results['elements']['levels']),
                'max' => 3, // Max level for scaling
            ],
            'category' => [
                'labels' => array_keys($results['categories']['levels']),
                'data' => array_values($results['categories']['levels']),
                'max' => 3,
            ],
            'domain' => [
                'labels' => array_keys($results['domains']['levels']),
                'data' => array_values($results['domains']['levels']),
                'max' => 3,
            ],
        ];
    }
}