<?php
// app/Models/AssessmentUpload.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Services\ElementMaturityCalculator;

class AssessmentUpload extends Model
{
    protected $table = 'assessment_uploads';
    
    protected $fillable = [
        'upload_id',
        'file_name',
        'organization_name',
        'assessment_date',
        'uploaded_by',
        'uploaded_by_email',
    ];
    
    protected $casts = [
        'assessment_date' => 'date',
    ];
    
    public function responses(): HasMany
    {
        return $this->hasMany(AssessmentResponse::class, 'assessment_upload_id');
    }
    
    /**
     * Get element maturity calculations
     */
    public function getElementMaturityAttribute(): array
    {
        $calculator = new ElementMaturityCalculator();
        return $calculator->calculateElementMaturity($this);
    }
    
    /**
     * Get data formatted for radar chart
     */
    public function getRadarChartDataAttribute(): array
    {
        $calculator = new ElementMaturityCalculator();
        return $calculator->getRadarChartData($this);
    }
    
    public static function generateUploadId(): string
    {
        return 'ASSESS_' . now()->format('Ymd_His');
    }
}