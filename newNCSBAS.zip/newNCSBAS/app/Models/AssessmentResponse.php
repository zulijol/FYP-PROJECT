<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AssessmentResponse extends Model
{
    protected $table = 'assessment_responses';
    
    protected $fillable = [
        'assessment_id',
        'user_id',
        'number',
        'domain',
        'category',
        'element',
        'description',
        'question',
        'response',
        'uploaded_at'
    ];
    
    protected $casts = [
        'uploaded_at' => 'datetime',
    ];
    
    // Relationship with Assessment model
    public function assessment()
    {
        return $this->belongsTo(Assessment::class);
    }
    
    // Relationship with User model
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}