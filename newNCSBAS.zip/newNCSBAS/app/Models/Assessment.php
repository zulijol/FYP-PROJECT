<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Assessment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'filename',
        'total_questions',
        'status',
        'file_path',
        'notes',
        'uploaded_at',
        'reviewed_at',      // Added
        'reviewed_by',      // Added
    ];

    protected $casts = [
        'uploaded_at' => 'datetime',
        'reviewed_at' => 'datetime', // Added
        'total_questions' => 'integer',
    ];

    protected $attributes = [
        'status' => 'imported',
        'total_questions' => 0,
    ];

    /**
     * Get the user that owns the assessment.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the reviewer who reviewed this assessment.
     */
    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    /**
     * Get all responses for this assessment.
     */
    public function responses(): HasMany
    {
        return $this->hasMany(AssessmentResponse::class);
    }

    /**
     * Scope to get assessments for current user.
     */
    public function scopeForCurrentUser($query)
    {
        return $query->where('user_id', auth()->id());
    }

    /**
     * Scope to get assessments that need review.
     */
    public function scopeNeedsReview($query)
    {
        return $query->whereNull('reviewed_at');
    }

    /**
     * Scope to get reviewed assessments.
     */
    public function scopeReviewed($query)
    {
        return $query->whereNotNull('reviewed_at');
    }

    /**
     * Check if assessment has been reviewed.
     */
    public function isReviewed(): bool
    {
        return !is_null($this->reviewed_at);
    }

    /**
     * Get formatted uploaded date.
     */
    public function getFormattedUploadedAtAttribute(): string
    {
        return $this->uploaded_at?->format('d M Y, H:i') ?? 'N/A';
    }

    /**
     * Get formatted reviewed date.
     */
    public function getFormattedReviewedAtAttribute(): string
    {
        return $this->reviewed_at?->format('d M Y, H:i') ?? 'Not reviewed';
    }

    /**
     * Get file extension.
     */
    public function getFileExtensionAttribute(): string
    {
        return pathinfo($this->filename, PATHINFO_EXTENSION);
    }

    /**
     * Check if assessment has responses.
     */
    public function hasResponses(): bool
    {
        return $this->responses()->count() > 0;
    }

    /**
     * Get assessment statistics.
     */
    public function getStatsAttribute(): array
    {
        return [
            'total' => $this->responses()->count(),
            'yes_count' => $this->responses()->where('response', 'Yes')->count(),
            'no_count' => $this->responses()->where('response', 'No')->count(),
            'empty_count' => $this->responses()->whereNull('response')->count(),
        ];
    }

    /**
     * Mark assessment as reviewed.
     */
    public function markAsReviewed($userId): void
    {
        $this->update([
            'reviewed_at' => now(),
            'reviewed_by' => $userId,
            'status' => 'reviewed',
        ]);
    }
}