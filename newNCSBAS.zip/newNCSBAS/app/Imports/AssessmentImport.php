<?php

namespace App\Imports;

use App\Models\AssessmentResponse;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Auth;

class AssessmentImport implements ToCollection, WithHeadingRow
{
    protected $assessmentId;
    protected $userId;
    protected $filename;
    
    // Forward-fill variables
    protected $currentDomain = null;
    protected $currentCategory = null;
    protected $currentElement = null;
    protected $currentDescription = null;

    public function __construct($assessmentId, $filename)
    {
        $this->assessmentId = $assessmentId;
        $this->userId = Auth::id();
        $this->filename = $filename;
    }

    public function collection(Collection $rows)
    {
        $imported = 0;

        foreach ($rows as $row) {
            // Extract data from Excel (handle different column name variations)
            $number = $this->getValue($row, ['number', 'no', 'question_number']);
            $domain = $this->getValue($row, ['domain']);
            $category = $this->getValue($row, ['category']);
            $element = $this->getValue($row, ['element']);
            $description = $this->getValue($row, ['description']);
            
            // Question column might be named differently
            $question = $this->getValue($row, ['question', 'questionnaire', 'question_text', 'questionnaire_text']);
            
            // Response column might be named differently
            $response = $this->getValue($row, ['response', 'response_yes_no', 'response_yes/no', 'answer', 'response']);

            // Skip if no question
            if (empty($question)) {
                continue;
            }

            // Update forward-fill variables
            if (!empty(trim($domain ?? ''))) $this->currentDomain = trim($domain);
            if (!empty(trim($category ?? ''))) $this->currentCategory = trim($category);
            if (!empty(trim($element ?? ''))) $this->currentElement = trim($element);
            if (!empty(trim($description ?? ''))) $this->currentDescription = trim($description);

            // Normalize response
            $normalizedResponse = $this->normalizeResponse($response);

            // Create response record
            AssessmentResponse::create([
                'assessment_id' => $this->assessmentId,
                'user_id' => $this->userId,
                'number' => $number ? (int) $number : null,
                'domain' => $this->currentDomain,
                'category' => $this->currentCategory,
                'element' => $this->currentElement,
                'description' => $this->currentDescription,
                'question' => trim($question),
                'response' => $normalizedResponse,
                'uploaded_at' => now(),
            ]);
            
            $imported++;
        }

        return $imported;
    }

    /**
     * Get value from row with multiple possible column names
     */
    private function getValue($row, $possibleKeys)
    {
        foreach ($possibleKeys as $key) {
            if (isset($row[$key]) && !empty($row[$key])) {
                return $row[$key];
            }
        }
        return null;
    }

    /**
     * Normalize response to Yes/No/null
     */
    private function normalizeResponse($response)
    {
        if (empty($response)) {
            return null;
        }

        $response = strtolower(trim($response));
        
        return match($response) {
            'yes', 'y', '1', 'true', 'ya' => 'Yes',
            'no', 'n', '0', 'false', 'tidak' => 'No',
            default => null,
        };
    }

    /**
     * Get total imported count (optional)
     */
    public function getImportedCount(): int
    {
        return AssessmentResponse::where('assessment_id', $this->assessmentId)->count();
    }
}