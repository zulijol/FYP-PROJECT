<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class AdminController extends Controller
{
    /**
     * Admin Dashboard - Shows all users
     */
    public function dashboard()
    {
        $users = User::with('roles')->latest()->paginate(20);
        $roles = Role::all();
        
        return view('admin.dashboard', compact('users', 'roles'));
    }
    
    /**
     * Update user role
     */
    public function updateUserRole(Request $request, $id)
    {
        $request->validate([
            'role' => 'required|exists:roles,id',
        ]);
        
        $user = User::findOrFail($id);
        
        // Prevent changing your own role
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.dashboard')
                ->with('error', 'You cannot change your own role.');
        }
        
        // Assign new role (sync removes existing roles)
        $role = Role::findById($request->role);
        $user->syncRoles([$role]);
        
        return redirect()->route('admin.dashboard')
            ->with('success', 'User role updated successfully.');
    }
    
    /**
     * Delete user
     */
    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        
        // Prevent deleting yourself
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.dashboard')
                ->with('error', 'You cannot delete your own account.');
        }
        
        $user->delete();
        
        return redirect()->route('admin.dashboard')
            ->with('success', 'User deleted successfully.');
    }
}