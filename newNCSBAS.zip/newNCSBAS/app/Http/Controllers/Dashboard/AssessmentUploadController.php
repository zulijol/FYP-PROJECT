<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Assessment;
use App\Imports\AssessmentImport;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Auth;

class AssessmentUploadController extends Controller
{
    public function upload(Request $request)
    {
        $request->validate([
            'excel' => 'required|mimes:xlsx,xls|max:5120', // 5MB max
        ]);

        $file = $request->file('excel');
        $userId = Auth::id();

        try {
            // 1. Create assessment record
            $assessment = Assessment::create([
                'user_id' => $userId,
                'filename' => $file->getClientOriginalName(),
                'uploaded_at' => now(),
            ]);

            // 2. Import Excel data
            $import = new AssessmentImport($assessment->id, $file->getClientOriginalName());
            $importedCount = Excel::import($import, $file);

            // 3. Update total questions count
            $assessment->update([
                'total_questions' => $assessment->responses()->count()
            ]);

            return back()->with('success', 
                "Successfully imported {$assessment->total_questions} questions. Assessment ID: {$assessment->id}"
            );

        } catch (\Exception $e) {
            // Clean up if import fails
            if (isset($assessment)) {
                $assessment->delete();
            }
            
            return back()->with('error', 
                'Import failed: ' . $e->getMessage()
            );
        }
    }

    // Other methods for viewing, stats, etc...
}