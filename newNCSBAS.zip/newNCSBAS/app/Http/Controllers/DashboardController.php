<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    /**
     * Show the dashboard
     */
    public function index()
    {
        $user = Auth::user();
        
        // Get user's recent uploads
        $recentUploads = Assessment::where('user_id', $user->id)
            ->orderBy('uploaded_at', 'desc')
            ->take(10)
            ->get();
            
        // Get total uploads count
        $totalUploads = Assessment::where('user_id', $user->id)->count();
        
        // Get statistics
        $stats = [
            'total_questions' => 0,
            'yes_count' => 0,
            'no_count' => 0,
        ];
        
        foreach ($recentUploads as $upload) {
            $stats['total_questions'] += $upload->total_questions;
        }
        
        // Remove organizations from compact() since we don't have that column
        return view('dashboard', compact('recentUploads', 'totalUploads', 'stats'));
    }
}