<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReviewerController extends Controller
{
    /**
     * Reviewer Dashboard
     */
    public function dashboard()
    {
        // Get counts for dashboard
        $totalAssessments = Assessment::count();
        $importedAssessments = Assessment::where('status', 'imported')->count();
        $inReviewAssessments = Assessment::where('status', 'in_review')->count();
        $completedAssessments = Assessment::where('status', 'completed')->count();
        
        // Get recent imported assessments (these need review)
        $recentAssessments = Assessment::with('user')
            ->where('status', 'imported')
            ->orWhere('status', 'in_review')
            ->latest('uploaded_at')
            ->take(5)
            ->get();
        
        return view('reviewer.dashboard', compact(
            'totalAssessments',
            'importedAssessments',
            'inReviewAssessments',
            'completedAssessments',
            'recentAssessments'
        ));
    }
    
    /**
     * Show assessments that NEED REVIEW
     */
    public function index()
    {
        // Get assessments that need review (imported or in_review)
        $assessments = Assessment::with('user')
            ->whereIn('status', ['imported', 'in_review'])
            ->latest('uploaded_at')
            ->paginate(10);
        
        return view('reviewer.index', compact('assessments'));
    }
    
    /**
     * View a single assessment in detail
     */
    public function show($id)
    {
        $assessment = Assessment::with(['responses' => function($query) {
            $query->orderBy('number', 'asc');
        }, 'user'])->findOrFail($id);
        
        // Calculate statistics
        $total = $assessment->responses->count();
        $yesCount = $assessment->responses->where('response', 'Yes')->count();
        $noCount = $assessment->responses->where('response', 'No')->count();
        $emptyCount = $assessment->responses->where('response', '')->count() + 
                      $assessment->responses->whereNull('response')->count();
        
        $stats = [
            'total' => $total,
            'yes_count' => $yesCount,
            'no_count' => $noCount,
            'empty_count' => $emptyCount,
            'yes_percentage' => $total > 0 ? round(($yesCount / $total) * 100, 2) : 0,
            'no_percentage' => $total > 0 ? round(($noCount / $total) * 100, 2) : 0,
            'empty_percentage' => $total > 0 ? round(($emptyCount / $total) * 100, 2) : 0,
        ];
        
        // Group responses by domain
        $responsesByDomain = $assessment->responses->groupBy('domain');
        
        return view('reviewer.show', compact('assessment', 'stats', 'responsesByDomain'));
    }
    
/**
 * Update assessment status
 */
public function updateStatus(Request $request, $id)
{
    $request->validate([
        'status' => 'required|in:imported,in_review,completed,not_reviewed',
        'comments' => 'nullable|string|max:1000',
    ]);
    
    $assessment = Assessment::findOrFail($id);
    
    $status = $request->status;
    
    $updateData = [
        'status' => $status,
        'review_comments' => $request->comments,
    ];
    
    // Only set reviewed_at and reviewed_by if marking as completed
    if ($status === 'completed') {
        $updateData['reviewed_at'] = now();
        $updateData['reviewed_by'] = Auth::id();
    }
    
    // If changing back to imported/in_review, clear reviewed info
    if (in_array($status, ['imported', 'in_review'])) {
        $updateData['reviewed_at'] = null;
        $updateData['reviewed_by'] = null;
    }
    
    $assessment->update($updateData);
    
    return redirect()->route('review.dashboard')
        ->with('success', 'Assessment marked as ' . str_replace('_', ' ', ucfirst($status)) . '.');
}

/**
 * Quick mark as reviewed
 */
public function markAsReviewed($id)
{
    $assessment = Assessment::findOrFail($id);
    
    $assessment->update([
        'reviewed_at' => now(),
        'reviewed_by' => Auth::id(),
        'status' => 'completed',
    ]);
    
    return redirect()->route('review.dashboard')
        ->with('success', 'Assessment marked as completed.');
}
    
    /**
     * Show all completed assessments
     */
    public function reviewed()
    {
        $assessments = Assessment::with('user')
            ->where('status', 'completed')
            ->latest('reviewed_at')
            ->paginate(10);
        
        return view('reviewer.reviewed', compact('assessments'));
    }
}