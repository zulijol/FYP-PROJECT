<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use App\Models\AssessmentResponse;
use App\Imports\AssessmentImport;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Services\MaturityCalculatorService;
use Barryvdh\DomPDF\Facade\Pdf;

class AssessmentController extends Controller
{
    protected $calculatorService;
    
    public function __construct(MaturityCalculatorService $calculatorService)
    {
        $this->calculatorService = $calculatorService;
    }

    /**
     * Show upload form
     */
    public function index()
    {
        return view('assessment.upload');
    }

    /**
     * List all assessments
     */
    public function list()
    {
        $assessments = Assessment::orderBy('uploaded_at', 'desc')
            ->paginate(15); // Adjust per page as needed
        
        $totalQuestions = Assessment::sum('total_questions');
        
        return view('assessment.list', [
            'assessments' => $assessments,
            'totalQuestions' => $totalQuestions
        ]);
    }

    /**
     * Show upload form (alternative method name)
     */
    public function showUploadForm()
    {
        return view('assessment.upload');
    }

    /**
     * Handle Excel upload
     */
    public function upload(Request $request)
    {
        // Validate only the file
        $validator = Validator::make($request->all(), [
            'excel_file' => 'required|mimes:xlsx,xls,xlsm|max:10240',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        // Get the uploaded file
        $file = $request->file('excel_file');
        
        if (!$file) {
            return back()->with('error', 'No file was uploaded.')->withInput();
        }

        $userId = Auth::id();
        $filename = $file->getClientOriginalName();

        try {
            // 1. Create assessment record
            $assessment = Assessment::create([
                'user_id' => $userId,
                'filename' => $filename,
                'uploaded_at' => now(),
                'status' => 'imported',
            ]);

            // 2. Import Excel data
            $import = new AssessmentImport($assessment->id, $filename);
            Excel::import($import, $file);

            // 3. Get imported count
            $importedCount = $import->getImportedCount();
            $assessment->update([
                'total_questions' => $importedCount
            ]);

            // 4. Calculate maturity immediately after upload
            $this->calculateAndStoreMaturity($assessment->id);

            // SUCCESS: Redirect to assessment details page
            return redirect()->route('assessment.show', $assessment->id)
                ->with('success', 
                    "✅ Successfully imported {$importedCount} questions from '{$filename}'. Maturity calculation completed."
                );

        } catch (\Exception $e) {
            // Clean up if import fails
            if (isset($assessment)) {
                AssessmentResponse::where('assessment_id', $assessment->id)->delete();
                $assessment->delete();
            }
            
            return back()->with('error', 
                '❌ Import failed: ' . $e->getMessage()
            )->withInput();
        }
    }

    /**
     * Show assessment details with maturity results
     */
    public function show($id)
    {
        $assessment = Assessment::with(['responses' => function($query) {
            $query->orderBy('number');
        }])
        ->where('user_id', Auth::id())
        ->findOrFail($id);

        // Calculate basic statistics
        $stats = [
            'total' => $assessment->responses->count(),
            'yes_count' => $assessment->responses->where('response', 'Yes')->count(),
            'no_count' => $assessment->responses->where('response', 'No')->count(),
            'empty_count' => $assessment->responses->whereNull('response')->count(),
        ];

        // Calculate percentages
        if ($stats['total'] > 0) {
            $stats['yes_percentage'] = round(($stats['yes_count'] / $stats['total']) * 100, 2);
            $stats['no_percentage'] = round(($stats['no_count'] / $stats['total']) * 100, 2);
            $stats['empty_percentage'] = round(($stats['empty_count'] / $stats['total']) * 100, 2);
        } else {
            $stats['yes_percentage'] = $stats['no_percentage'] = $stats['empty_percentage'] = 0;
        }

        // Get or calculate maturity results
        $maturityResults = $this->getMaturityResults($assessment);

        return view('assessment.show', compact('assessment', 'stats', 'maturityResults'));
    }

    /**
     * Show maturity dashboard with radar charts
     */
    public function showMaturityDashboard($id)
    {
        $assessment = Assessment::where('user_id', Auth::id())->findOrFail($id);
        
        // Get or calculate maturity results
        $maturityResults = $this->getMaturityResults($assessment);
        
        // Format data for radar charts
        $radarData = $this->calculatorService->formatForRadarCharts($maturityResults);

        return view('assessment.maturity-dashboard', [
            'assessment' => $assessment,
            'results' => $maturityResults,
            'radarData' => $radarData
        ]);
    }

    /**
     * Calculate maturity for an assessment
     */
    public function calculateMaturity($id)
    {
        $assessment = Assessment::where('user_id', Auth::id())->findOrFail($id);
        
        $results = $this->calculateAndStoreMaturity($id);
        
        return back()->with('success', 'Maturity calculation completed!');
    }

    /**
     * Get assessment statistics (API)
     */
    public function stats($id)
    {
        $assessment = Assessment::with('responses')
            ->where('user_id', Auth::id())
            ->findOrFail($id);

        $stats = [
            'total_questions' => $assessment->total_questions,
            'filename' => $assessment->filename,
            'uploaded_at' => $assessment->uploaded_at->format('Y-m-d H:i:s'),
            'responses' => [
                'Yes' => $assessment->responses->where('response', 'Yes')->count(),
                'No' => $assessment->responses->where('response', 'No')->count(),
                'Empty' => $assessment->responses->whereNull('response')->count(),
            ],
            'maturity' => $assessment->overall_maturity ?? 'Not calculated',
            'calculated_at' => $assessment->calculated_at ? $assessment->calculated_at->format('Y-m-d H:i:s') : null,
        ];

        return response()->json($stats);
    }

    /**
     * Get maturity data as JSON (for AJAX requests)
     */
    public function getMaturityData($id)
    {
        $assessment = Assessment::where('user_id', Auth::id())->findOrFail($id);
        
        $maturityResults = $this->getMaturityResults($assessment);
        $radarData = $this->calculatorService->formatForRadarCharts($maturityResults);

        return response()->json([
            'success' => true,
            'data' => $maturityResults,
            'radarData' => $radarData
        ]);
    }

    /**
     * Delete assessment
     */
    public function destroy($id)
    {
        $assessment = Assessment::where('user_id', Auth::id())->findOrFail($id);
        
        // Delete associated responses first
        AssessmentResponse::where('assessment_id', $id)->delete();
        
        // Delete assessment
        $assessment->delete();

        return redirect()->route('assessment.list')
            ->with('success', 'Assessment deleted successfully.');
    }

    /**
     * Download assessment as PDF Report
     */
public function downloadPdfReport($id)
{
    $assessment = Assessment::with('responses')
        ->where('user_id', Auth::id())
        ->findOrFail($id);
        
    // Get or calculate maturity results
    $maturityResults = $this->getMaturityResults($assessment);
    
    // Get basic statistics
    $stats = [
        'total' => $assessment->responses->count(),
        'yes_count' => $assessment->responses->where('response', 'Yes')->count(),
        'no_count' => $assessment->responses->where('response', 'No')->count(),
        'empty_count' => $assessment->responses->whereNull('response')->count(),
    ];
    
    if ($stats['total'] > 0) {
        $stats['yes_percentage'] = round(($stats['yes_count'] / $stats['total']) * 100, 2);
        $stats['no_percentage'] = round(($stats['no_count'] / $stats['total']) * 100, 2);
        $stats['empty_percentage'] = round(($stats['empty_count'] / $stats['total']) * 100, 2);
    } else {
        $stats['yes_percentage'] = $stats['no_percentage'] = $stats['empty_percentage'] = 0;
    }
    
    // Calculate level descriptions
    $levelDescription = $this->getLevelDescription($maturityResults['overall_maturity'] ?? 0);
    $domainLevels = [];
    
    foreach ($maturityResults['domains']['levels'] ?? [] as $domain => $score) {
        $domainLevels[$domain] = $this->getLevelDescription($score);
    }
    
    // Prepare data for PDF
    $data = [
        'assessment' => $assessment,
        'stats' => $stats,
        'results' => $maturityResults,
        'domains' => $maturityResults['domains']['levels'] ?? [],
        'domainLevels' => $domainLevels,
        'categories' => $maturityResults['categories']['levels'] ?? [],
        'elements' => $maturityResults['elements']['details'] ?? [],
        'overall_maturity' => $maturityResults['overall_maturity'] ?? 0,
        'overall_level' => $levelDescription,
        'report_date' => now()->format('F j, Y'),
        'user' => Auth::user()
    ];
    
    $pdf = PDF::loadView('reports.assessment-report', $data);
    
    $filename = 'NCSBAS_Report_' . $assessment->filename . '_' . date('Y-m-d') . '.pdf';
    
    return $pdf->download($filename);
}


    /**
     * Download detailed assessment data as CSV (optional - keeping for reference)
     */
    public function downloadCsv($id)
    {
        $assessment = Assessment::with('responses')
            ->where('user_id', Auth::id())
            ->findOrFail($id);

        $filename = 'assessment_' . $assessment->id . '_' . date('Y-m-d') . '.csv';
        
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ];

        $callback = function() use ($assessment) {
            $file = fopen('php://output', 'w');
            
            // Write headers
            fputcsv($file, [
                'Number', 'Domain', 'Category', 'Element', 
                'Description', 'Question', 'Response', 'Uploaded At'
            ]);
            
            // Write data
            foreach ($assessment->responses as $response) {
                fputcsv($file, [
                    $response->number,
                    $response->domain,
                    $response->category,
                    $response->element,
                    $response->description,
                    $response->question,
                    $response->response,
                    $response->uploaded_at->format('Y-m-d H:i:s'),
                ]);
            }
            
            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }

    /**
     * View PDF Report in Browser
     */
    public function viewPdfReport($id)
    {
        $assessment = Assessment::with('responses')
            ->where('user_id', Auth::id())
            ->findOrFail($id);
            
        // Get or calculate maturity results
        $maturityResults = $this->getMaturityResults($assessment);
        
        // Get basic statistics
        $stats = [
            'total' => $assessment->responses->count(),
            'yes_count' => $assessment->responses->where('response', 'Yes')->count(),
            'no_count' => $assessment->responses->where('response', 'No')->count(),
            'empty_count' => $assessment->responses->whereNull('response')->count(),
        ];
        
        if ($stats['total'] > 0) {
            $stats['yes_percentage'] = round(($stats['yes_count'] / $stats['total']) * 100, 2);
            $stats['no_percentage'] = round(($stats['no_count'] / $stats['total']) * 100, 2);
            $stats['empty_percentage'] = round(($stats['empty_count'] / $stats['total']) * 100, 2);
        } else {
            $stats['yes_percentage'] = $stats['no_percentage'] = $stats['empty_percentage'] = 0;
        }
        
        // Prepare data for PDF
        $data = [
            'assessment' => $assessment,
            'stats' => $stats,
            'results' => $maturityResults,
            'domains' => $maturityResults['domains']['levels'] ?? [],
            'categories' => $maturityResults['categories']['levels'] ?? [],
            'elements' => $maturityResults['elements']['details'] ?? [],
            'overall_maturity' => $maturityResults['overall_maturity'] ?? 0,
            'report_date' => now()->format('F j, Y'),
            'user' => Auth::user()
        ];
        
        $pdf = PDF::loadView('reports.assessment-report', $data);
        
        $filename = 'NCSBAS_Report_' . $assessment->filename . '_' . date('Y-m-d') . '.pdf';
        
        return $pdf->stream($filename);
    }

    /**
     * Private helper methods
     */
    
    private function calculateAndStoreMaturity($assessmentId)
    {
        $assessment = Assessment::findOrFail($assessmentId);
        
        $results = $this->calculatorService->calculateForAssessment($assessmentId);
        
        $assessment->update([
            'maturity_results' => $results,
            'calculated_at' => now(),
            'overall_maturity' => $results['overall_maturity'],
            // Store domain scores if you have these columns
            'govern_score' => $results['domains']['levels']['GOVERN'] ?? 0,
            'identify_score' => $results['domains']['levels']['IDENTIFY'] ?? 0,
            'protect_score' => $results['domains']['levels']['PROTECT'] ?? 0,
            'detect_score' => $results['domains']['levels']['DETECT'] ?? 0,
            'respond_score' => $results['domains']['levels']['RESPOND'] ?? 0,
            'recover_score' => $results['domains']['levels']['RECOVER'] ?? 0,
        ]);
        
        return $results;
    }
    
    private function getMaturityResults($assessment)
    {
        if ($assessment->maturity_results && $assessment->calculated_at) {
            return $assessment->maturity_results;
        }
        
        return $this->calculateAndStoreMaturity($assessment->id);
    }
    
    private function getLevelDescription($score)
    {
        if ($score >= 2.5) return 'Established';
        if ($score >= 1.5) return 'Developing';
        if ($score >= 0.5) return 'Basic';
        return 'Initial';
    }
}