


<?php $__env->startSection('title', 'Upload Assessment'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
        <h1 class="h2 text-white">
            <i class="fas fa-file-upload text-teal me-2"></i>Upload Assessment Excel
        </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-check-circle fa-2x me-3 text-success"></i>
            <div class="flex-grow-1">
                <h5 class="alert-heading mb-1 text-dark">Success!</h5>
                <p class="mb-0 text-dark"><?php echo e(session('success')); ?></p>
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
        <div class="d-flex align-items-center">
            <i class="fas fa-exclamation-triangle fa-2x me-3 text-danger"></i>
            <div class="flex-grow-1">
                <h5 class="alert-heading mb-2 text-white">Please fix the following errors:</h5>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-light"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Upload Form -->
    <div class="row">
        <!-- Main Upload Form -->
        <div class="col-lg-8 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0 text-white">
                        <i class="fas fa-file-excel text-teal me-2"></i>
                        Upload Assessment File
                    </h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('assessment.upload')); ?>" enctype="multipart/form-data" id="uploadForm">
                        <?php echo csrf_field(); ?>

                        <!-- File Upload Section -->
                        <div class="mb-4">
                            <label for="excel_file" class="form-label text-white mb-3">
                                <i class="fas fa-cloud-upload-alt me-2 text-teal"></i>
                                Excel File <span class="text-teal">*</span>
                            </label>
                            
                            <!-- Drag & Drop Zone -->
                            <div class="file-upload-area mb-3">
                                <input type="file" class="form-control d-none <?php $__errorArgs = ['excel_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       id="excel_file" name="excel_file" 
                                       accept=".xlsx,.xls,.xlsm" required>
                                
                                <div class="file-upload-box p-5 text-center border border-dashed rounded" 
                                     id="dropZone">
                                    <div class="upload-icon mb-3">
                                        <i class="fas fa-file-excel fa-4x text-teal"></i>
                                    </div>
                                    <h5 class="text-white mb-2">Drop your Excel file here</h5>
                                    <p class="text-light mb-3">or click to browse</p>
                                    <button type="button" class="btn btn-outline-teal" id="browseBtn">
                                        <i class="fas fa-folder-open me-2"></i> Browse Files
                                    </button>
                                    <p class="text-muted mt-3 mb-0" id="fileInfo">No file selected</p>
                                </div>
                            </div>
                            
                            <?php $__errorArgs = ['excel_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                            <!-- File Requirements -->
                            <div class="file-requirements mt-4">
                                <h6 class="text-white mb-3">
                                    <i class="fas fa-clipboard-check text-teal me-2"></i>
                                    File Requirements:
                                </h6>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start mb-2">
                                            <i class="fas fa-check-circle text-success mt-1 me-2"></i>
                                            <span class="text-light">Excel format (.xlsx, .xls, .xlsm)</span>
                                        </div>
                                        <div class="d-flex align-items-start mb-2">
                                            <i class="fas fa-check-circle text-success mt-1 me-2"></i>
                                            <span class="text-light">Follow the template format</span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex align-items-start mb-2">
                                            <i class="fas fa-check-circle text-success mt-1 me-2"></i>
                                            <span class="text-light">Sheet name: "CS Baseline Questionnaires"</span>
                                        </div>
                                        <div class="d-flex align-items-start mb-2">
                                            <i class="fas fa-check-circle text-success mt-1 me-2"></i>
                                            <span class="text-light">Columns A-G for assessment data</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Important Notes -->
                        <div class="alert alert-info mb-4">
                            <div class="d-flex">
                                <i class="fas fa-info-circle fa-2x text-info me-3 mt-1"></i>
                                <div>
                                    <h6 class="text-white mb-2">Important Notes:</h6>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="d-flex align-items-start mb-2">
                                                <i class="fas fa-calculator text-teal mt-1 me-2"></i>
                                                <span class="text-light">Automatically calculates maturity levels for 33 elements</span>
                                            </div>
                                            <div class="d-flex align-items-start mb-2">
                                                <i class="fas fa-check text-teal mt-1 me-2"></i>
                                                <span class="text-light">Only "YES" responses counted</span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="d-flex align-items-start mb-2">
                                                <i class="fas fa-times text-teal mt-1 me-2"></i>
                                                <span class="text-light">"NO" or blank responses ignored</span>
                                            </div>
                                            <div class="d-flex align-items-start mb-2">
                                                <i class="fas fa-clock text-teal mt-1 me-2"></i>
                                                <span class="text-light">Processing takes a few moments</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Form Actions -->
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="reset" class="btn btn-outline-light me-md-2">
                                <i class="fas fa-redo me-1"></i> Clear Form
                            </button>
                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                <i class="fas fa-upload me-1"></i> Upload & Process
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar Help -->
        <div class="col-lg-4">
            <!-- Template Format Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0 text-white">
                        <i class="fas fa-table text-teal me-2"></i>
                        Template Format
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark table-bordered mb-3">
                            <thead>
                                <tr>
                                    <th class="text-teal">Column</th>
                                    <th class="text-teal">Content</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td class="fw-bold text-white">A</td><td class="text-light">Question Number</td></tr>
                                <tr><td class="fw-bold text-white">B</td><td class="text-light">Domain</td></tr>
                                <tr><td class="fw-bold text-white">C</td><td class="text-light">Category</td></tr>
                                <tr><td class="fw-bold text-white">D</td><td class="text-light">Element</td></tr>
                                <tr><td class="fw-bold text-white">E</td><td class="text-light">Description</td></tr>
                                <tr><td class="fw-bold text-white">F</td><td class="text-light">Questionnaire</td></tr>
                                <tr><td class="fw-bold text-white">G</td><td class="text-light">Response (Yes/No)</td></tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Response Values -->
                    <h6 class="text-white mb-3">Response Values:</h6>
                    <div class="row mb-4">
                        <div class="col-12 mb-2">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-teal text-dark me-2">YES</span>
                                <span class="text-light">Counted for maturity calculation</span>
                            </div>
                        </div>
                        <div class="col-12 mb-2">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-danger me-2">NO</span>
                                <span class="text-light">Ignored in calculations</span>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="d-flex align-items-center">
                                <span class="badge bg-secondary me-2">Blank</span>
                                <span class="text-light">Ignored in calculations</span>
                            </div>
                        </div>
                    </div>

                    <!-- Warning Alert -->
                    <div class="alert alert-warning">
                        <div class="d-flex">
                            <i class="fas fa-exclamation-triangle text-warning me-2 mt-1"></i>
                            <div>
                                <h6 class="text-white mb-2">Before Uploading:</h6>
                                <p class="text-light mb-0">
                                    Make sure your Excel file has 125 questions (rows 2-126) 
                                    with proper formatting and all required columns.
                                </p>
                            </div>
                        </div>
                    </div>

                    <!-- Template Download -->
                    <a href="<?php echo e(asset('New Template Assessment.xlsx')); ?>" class="btn btn-outline-teal w-100" download>
                        <i class="fas fa-download me-2"></i> Download Template
                    </a>
                </div>
            </div>

            <!-- Quick Stats Card -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0 text-white">
                        <i class="fas fa-chart-line text-teal me-2"></i>
                        Your Upload Stats
                    </h5>
                </div>
                <div class="card-body">
                    <?php
                        $user = auth()->user();
                        $userUploads = \App\Models\AssessmentUpload::where('uploaded_by_email', $user->email)->count();
                        $lastUpload = \App\Models\AssessmentUpload::where('uploaded_by_email', $user->email)->latest()->first();
                    ?>
                    
                    <div class="text-center mb-4">
                        <div class="display-2 fw-bold text-teal"><?php echo e($userUploads); ?></div>
                        <p class="text-light mb-0">Total Uploads</p>
                    </div>
                    
                    <hr class="border-secondary">
                    
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <h6 class="text-white mb-1">Last Upload</h6>
                            <p class="text-light mb-0">
                                <?php if($userUploads > 0 && $lastUpload): ?>
                                    <?php echo e($lastUpload->created_at->format('d M Y, H:i')); ?>

                                <?php else: ?>
                                    <span class="text-muted">No uploads yet</span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="text-end">
                            <div class="icon-circle bg-teal">
                                <i class="fas fa-history text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Loading Modal -->
<div class="modal fade" id="loadingModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark">
            <div class="modal-body text-center p-5">
                <div class="mb-4">
                    <div class="spinner-border text-teal" role="status" style="width: 4rem; height: 4rem;">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
                <h4 class="text-white mb-3">Processing Your File</h4>
                <p class="text-light mb-4">Please wait while we analyze and process your assessment data...</p>
                <div class="progress bg-dark" style="height: 6px;">
                    <div class="progress-bar bg-teal progress-bar-striped progress-bar-animated" style="width: 100%"></div>
                </div>
                <p class="text-muted mt-3 mb-0">This may take a few moments depending on file size</p>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('excel_file');
    const dropZone = document.getElementById('dropZone');
    const browseBtn = document.getElementById('browseBtn');
    const fileInfo = document.getElementById('fileInfo');
    const uploadForm = document.getElementById('uploadForm');
    const submitBtn = document.getElementById('submitBtn');

    // Browse button click handler
    browseBtn.addEventListener('click', function() {
        fileInput.click();
    });

    // File input change handler
    fileInput.addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            const file = e.target.files[0];
            updateFileInfo(file);
            dropZone.classList.add('file-selected');
        }
    });

    // Drag and drop functionality
    dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropZone.classList.add('drag-over');
    });

    dropZone.addEventListener('dragleave', function() {
        dropZone.classList.remove('drag-over');
    });

    dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.classList.remove('drag-over');
        
        if (e.dataTransfer.files.length > 0) {
            const file = e.dataTransfer.files[0];
            
            // Check if file is Excel
            const validTypes = ['.xlsx', '.xls', '.xlsm'];
            const fileExt = '.' + file.name.split('.').pop().toLowerCase();
            
            if (validTypes.includes(fileExt)) {
                // Create a new FileList and set it to the input
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                fileInput.files = dataTransfer.files;
                
                updateFileInfo(file);
                dropZone.classList.add('file-selected');
                
                // Trigger change event
                fileInput.dispatchEvent(new Event('change'));
            } else {
                showError('Please select an Excel file (.xlsx, .xls, .xlsm)');
            }
        }
    });

    // Form submission handler
    uploadForm.addEventListener('submit', function(e) {
        // Validate file
        if (!fileInput.files.length) {
            e.preventDefault();
            showError('Please select a file to upload');
            return;
        }

        // Show loading modal
        const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
        loadingModal.show();
        
        // Disable submit button
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Processing...';
        submitBtn.classList.add('processing');
    });

    // Reset form handler
    uploadForm.addEventListener('reset', function() {
        fileInfo.textContent = 'No file selected';
        dropZone.classList.remove('file-selected', 'drag-over');
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fas fa-upload me-1"></i> Upload & Process';
        submitBtn.classList.remove('processing');
    });

    // Helper functions
    function updateFileInfo(file) {
        const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
        fileInfo.innerHTML = `
            <div class="d-flex align-items-center justify-content-center">
                <i class="fas fa-file-excel text-teal me-2"></i>
                <div class="text-start">
                    <div class="text-white">${file.name}</div>
                    <small class="text-muted">${sizeInMB} MB • ${file.type || 'Excel File'}</small>
                </div>
            </div>
        `;
    }

    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger alert-dismissible fade show mt-3';
        errorDiv.innerHTML = `
            <i class="fas fa-exclamation-circle me-2"></i>
            ${message}
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert"></button>
        `;
        
        // Remove any existing error alerts
        const existingAlerts = document.querySelectorAll('.alert-danger');
        existingAlerts.forEach(alert => alert.remove());
        
        // Insert after form
            uploadForm.parentNode.insertBefore(errorDiv, uploadForm.nextSibling);
    }
});
</script>

<style>
/* Custom Variables */
:root {
    --teal: #20c997;
    --teal-dark: #198754;
    --dark: #212529;
    --darker: #121416;
    --card-bg: #2c3034;
    --border-color: #343a40;
    --light-text: #e9ecef;
}

/* Card Styling */
.card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
}

.card-header {
    background: rgba(33, 37, 41, 0.9);
    border-bottom: 1px solid var(--border-color);
    padding: 1.25rem 1.5rem;
}

.card-title {
    font-weight: 600;
    color: white;
}

/* File Upload Area */
.file-upload-area {
    margin-top: 1rem;
}

.file-upload-box {
    background: rgba(32, 201, 151, 0.05);
    border: 2px dashed rgba(32, 201, 151, 0.3);
    transition: all 0.3s ease;
    cursor: pointer;
}

.file-upload-box:hover {
    background: rgba(32, 201, 151, 0.1);
    border-color: var(--teal);
}

.file-upload-box.drag-over {
    background: rgba(32, 201, 151, 0.15);
    border-color: var(--teal);
    transform: scale(1.02);
}

.file-upload-box.file-selected {
    background: rgba(32, 201, 151, 0.08);
    border-color: var(--teal);
    border-style: solid;
}

.upload-icon {
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
}

/* Button Styling */
.btn-primary {
    background: linear-gradient(135deg, var(--teal), var(--teal-dark));
    border: none;
    font-weight: 600;
    padding: 0.75rem 2rem;
    transition: all 0.3s ease;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(32, 201, 151, 0.4);
}

.btn-primary.processing {
    opacity: 0.8;
    cursor: not-allowed;
}

.btn-outline-teal {
    color: var(--teal);
    border-color: var(--teal);
    font-weight: 500;
}

.btn-outline-teal:hover {
    background: var(--teal);
    color: var(--dark);
    border-color: var(--teal);
}

.btn-outline-light {
    color: rgba(255, 255, 255, 0.8);
    border-color: rgba(255, 255, 255, 0.3);
}

.btn-outline-light:hover {
    background: rgba(255, 255, 255, 0.1);
    color: white;
    border-color: rgba(255, 255, 255, 0.5);
}

/* Alert Styling */
.alert {
    border: none;
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.alert-info {
    background: rgba(23, 162, 184, 0.15);
    border-left: 4px solid #17a2b8;
}

.alert-warning {
    background: rgba(255, 193, 7, 0.15);
    border-left: 4px solid #ffc107;
}

.alert-success {
    background: rgba(32, 201, 151, 0.15);
    border-left: 4px solid var(--teal);
}

.alert-danger {
    background: rgba(220, 53, 69, 0.15);
    border-left: 4px solid #dc3545;
}

/* Table Styling */
.table-dark {
    --bs-table-bg: var(--darker);
    --bs-table-striped-bg: rgba(255, 255, 255, 0.05);
    --bs-table-hover-bg: rgba(32, 201, 151, 0.1);
    color: var(--light-text);
    border-color: var(--border-color);
}

.table-dark th {
    background-color: rgba(33, 37, 41, 0.9);
    border-color: var(--border-color);
    font-weight: 600;
}

/* Badge Styling */
.badge {
    font-weight: 600;
    padding: 0.4em 0.8em;
    border-radius: 6px;
}

.bg-teal {
    background-color: var(--teal) !important;
    color: var(--dark) !important;
}

/* Icon Circle */
.icon-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--teal);
    color: var(--dark);
    font-size: 1rem;
}

/* Progress Bar */
.progress {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 10px;
    overflow: hidden;
}

.progress-bar {
    background: linear-gradient(90deg, var(--teal), var(--teal-dark));
}

/* Form Control */
.form-control {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid var(--border-color);
    color: white;
}

.form-control:focus {
    background: rgba(255, 255, 255, 0.08);
    border-color: var(--teal);
    box-shadow: 0 0 0 0.25rem rgba(32, 201, 151, 0.25);
    color: white;
}

.form-label {
    font-weight: 500;
}

/* Modal Styling */
.modal-content {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 12px;
}

.spinner-border.text-teal {
    border-color: var(--teal);
    border-right-color: transparent;
}

/* Text Colors */
.text-teal {
    color: var(--teal) !important;
}

.text-white {
    color: white !important;
}

.text-light {
    color: var(--light-text) !important;
    opacity: 0.9;
}

.text-muted {
    color: #6c757d !important;
}

/* Display Numbers */
.display-2 {
    font-weight: 700;
    letter-spacing: -1px;
}

/* Hr Styling */
hr.border-secondary {
    border-color: rgba(108, 117, 125, 0.3) !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\assessment\upload.blade.php ENDPATH**/ ?>