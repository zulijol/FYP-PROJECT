<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | NCSBAS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Black & Teal gradient animation */
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        body {
            background: linear-gradient(
                -45deg,
                #000000,    /* Pure Black */
                #0a1929,    /* Deep Navy Blue */
                #0d2538,    /* Dark Teal Blue */
                #0a2e2e,    /* Dark Forest Green */
                #083344,    /* Deep Ocean Blue */
                #134e4a,    /* Dark Emerald */
                #115e59,    /* Teal */
                #0f766e,    /* Medium Teal */
                #0d9488,    /* Bright Teal */
                #14b8a6,    /* Light Teal */
                #2dd4bf     /* Pale Teal */
            );
            background-size: 400% 400%;
            animation: gradientShift 20s ease infinite;
            color: #f8fafc;
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Animated gradient overlay */
        .gradient-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                45deg,
                rgba(20, 184, 166, 0.1),
                rgba(13, 148, 136, 0.05),
                rgba(15, 118, 110, 0.03),
                transparent
            );
            pointer-events: none;
            z-index: -1;
        }
        
        /* Floating particles */
        .particle {
            position: fixed;
            background: rgba(20, 184, 166, 0.1);
            border-radius: 50%;
            pointer-events: none;
            z-index: -1;
        }
        
        .glass-card {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(45, 212, 191, 0.25);
            box-shadow: 
                0 10px 40px rgba(0, 0, 0, 0.4),
                0 0 40px rgba(20, 184, 166, 0.15),
                inset 0 1px 0 rgba(255, 255, 255, 0.1);
            transition: all 0.4s ease;
        }
        
        .glass-card:hover {
            border-color: rgba(94, 234, 212, 0.4);
            box-shadow: 
                0 15px 50px rgba(0, 0, 0, 0.5),
                0 0 60px rgba(20, 184, 166, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.15);
        }
        
        .teal-glow {
            box-shadow: 0 0 20px rgba(20, 184, 166, 0.5);
        }
        
        .input-field {
            background: rgba(30, 41, 59, 0.7);
            border: 1px solid rgba(94, 234, 212, 0.3);
            transition: all 0.3s ease;
        }
        
        .input-field:focus {
            background: rgba(30, 41, 59, 0.9);
            border-color: rgba(94, 234, 212, 0.6);
            box-shadow: 0 0 0 3px rgba(20, 184, 166, 0.3);
        }
        
        .teal-gradient-btn {
            background: linear-gradient(135deg, 
                #0d9488 0%, 
                #14b8a6 25%, 
                #2dd4bf 50%, 
                #14b8a6 75%, 
                #0d9488 100%);
            background-size: 200% auto;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }
        
        .teal-gradient-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent, 
                rgba(255, 255, 255, 0.2), 
                transparent);
            transition: 0.5s;
        }
        
        .teal-gradient-btn:hover::before {
            left: 100%;
        }
        
        .teal-gradient-btn:hover {
            background-position: right center;
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(20, 184, 166, 0.5);
        }
        
        .label-animation {
            transition: all 0.3s ease;
        }
        
        .input-field:focus + .input-label,
        .input-field:not(:placeholder-shown) + .input-label {
            transform: translateY(-24px) scale(0.9);
            color: #5eead4;
        }
        
        .checkbox-teal:checked {
            background-color: #0d9488;
            border-color: #0d9488;
        }
        
        .teal-link {
            color: #5eead4;
            position: relative;
            text-decoration: none;
        }
        
        .teal-link:hover {
            color: #99f6e4;
        }
        
        .teal-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -2px;
            left: 0;
            background: linear-gradient(90deg, #5eead4, #14b8a6);
            transition: width 0.3s ease;
        }
        
        .teal-link:hover::after {
            width: 100%;
        }
        
        .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #14b8a6;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { 
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(20, 184, 166, 0.7); 
            }
            70% { 
                transform: scale(1);
                box-shadow: 0 0 0 10px rgba(20, 184, 166, 0); 
            }
            100% { 
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(20, 184, 166, 0); 
            }
        }
        
        /* NCSBAS branding with teal effect */
        .ncsbas-text {
            font-family: 'Arial', sans-serif;
            letter-spacing: 2px;
            font-weight: 800;
            text-shadow: 
                0 0 20px rgba(20, 184, 166, 0.5),
                0 0 40px rgba(20, 184, 166, 0.3);
            position: relative;
            display: inline-block;
        }
        
        .ncsbas-text::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: -5px;
            left: 0;
            background: linear-gradient(90deg, 
                transparent, 
                #5eead4, 
                #14b8a6, 
                #5eead4, 
                transparent);
            border-radius: 2px;
        }
        
        /* Password strength meter */
        .strength-container {
            margin-top: 8px;
        }
        
        .strength-meter {
            height: 6px;
            border-radius: 3px;
            width: 0%;
            transition: width 0.4s ease, background-color 0.4s ease;
            background: linear-gradient(90deg, 
                #ef4444, 
                #f59e0b, 
                #3b82f6, 
                #10b981, 
                #0d9488);
            background-size: 500% 100%;
            background-position: 0% 0;
        }
        
        .strength-labels {
            display: flex;
            justify-content: space-between;
            margin-top: 6px;
            font-size: 0.75rem;
            color: #94a3b8;
        }
        
        .strength-label {
            padding: 2px 6px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .strength-label.active {
            color: #f8fafc;
            font-weight: 600;
            text-shadow: 0 0 10px rgba(20, 184, 166, 0.5);
        }
        
        .requirement-list {
            margin-top: 8px;
            padding-left: 5px;
        }
        
        .requirement-item {
            display: flex;
            align-items: center;
            margin-bottom: 4px;
            font-size: 0.8rem;
            color: #94a3b8;
            transition: all 0.3s ease;
        }
        
        .requirement-item.valid {
            color: #10b981;
        }
        
        .requirement-item i {
            margin-right: 6px;
            font-size: 0.7rem;
        }
        
        .password-toggle {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            transition: color 0.3s;
            z-index: 10;
        }
        
        .password-toggle:hover {
            color: #5eead4;
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            color: #94a3b8;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid rgba(94, 234, 212, 0.3);
        }
        
        .divider:not(:empty)::before {
            margin-right: 1em;
        }
        
        .divider:not(:empty)::after {
            margin-left: 1em;
        }
        
        /* Password match indicators */
        .match-indicator {
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.8rem;
            margin-top: 4px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
        }
        
        .match-good {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: #10b981;
        }
        
        .match-bad {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #ef4444;
        }
    </style>
</head>

<body class="flex justify-center items-center min-h-screen p-4">
    <!-- Gradient Overlay -->
    <div class="gradient-overlay"></div>
    
    <!-- Animated Particles -->
    <div id="particles-container"></div>
    
    <div class="max-w-lg w-full z-10">
        <!-- Registration Card -->
        <div class="glass-card rounded-2xl p-8 space-y-6 relative overflow-hidden">
            <!-- Animated teal accent line at top -->
            <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-teal-500 to-transparent"></div>
            
            <!-- Header with NCSBAS branding -->
            <div class="flex flex-col items-center space-y-4">
                <div class="flex items-center space-x-3">
                    <div class="w-12 h-12 rounded-full bg-gradient-to-br from-teal-700 to-teal-900 flex items-center justify-center teal-glow animate-pulse">
                        <i class="fas fa-user-plus text-teal-300 text-xl"></i>
                    </div>
                    <h1 class="text-3xl font-bold bg-gradient-to-r from-teal-400 via-teal-300 to-teal-200 bg-clip-text text-transparent ncsbas-text">NCSBAS</h1>
                </div>
                <h2 class="text-3xl font-bold text-center text-slate-100">Create Your Account</h2>
                <p class="text-slate-300 text-center">Join NCSBAS today</p>
            </div>

            <!-- Form -->
            <form method="POST" action="<?php echo e(route('register')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>
                
                <!-- Name Input -->
                <div class="relative group">
                    <input 
                        id="name" 
                        type="text" 
                        name="name" 
                        value="<?php echo e(old('name')); ?>" 
                        required 
                        autofocus
                        placeholder=" "
                        class="w-full px-5 py-4 rounded-xl input-field text-slate-200 placeholder-transparent focus:outline-none group-hover:border-teal-400 transition-all duration-300"
                    >
                    <label for="name" class="input-label absolute left-5 top-4 text-slate-300 pointer-events-none label-animation">
                        <i class="fas fa-user mr-2 text-teal-400"></i>Full Name
                    </label>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="flex items-center mt-2 text-rose-400 text-sm">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Email Input -->
                <div class="relative group">
                    <input 
                        id="email" 
                        type="email" 
                        name="email" 
                        value="<?php echo e(old('email')); ?>" 
                        required
                        placeholder=" "
                        class="w-full px-5 py-4 rounded-xl input-field text-slate-200 placeholder-transparent focus:outline-none group-hover:border-teal-400 transition-all duration-300"
                    >
                    <label for="email" class="input-label absolute left-5 top-4 text-slate-300 pointer-events-none label-animation">
                        <i class="fas fa-envelope mr-2 text-teal-400"></i>Email Address
                    </label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="flex items-center mt-2 text-rose-400 text-sm">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password Input -->
                <div class="relative group">
                    <input 
                        id="password" 
                        type="password" 
                        name="password" 
                        required
                        placeholder=" "
                        class="w-full px-5 py-4 rounded-xl input-field text-slate-200 placeholder-transparent focus:outline-none pr-12 group-hover:border-teal-400 transition-all duration-300"
                        onkeyup="checkPasswordStrength()"
                    >
                    <button type="button" class="password-toggle" onclick="togglePasswordVisibility('password')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <label for="password" class="input-label absolute left-5 top-4 text-slate-300 pointer-events-none label-animation">
                        <i class="fas fa-key mr-2 text-teal-400"></i>Password
                    </label>
                    
                    <!-- Password strength meter -->
                    <div class="strength-container">
                        <div id="strength-bar" class="strength-meter"></div>
                        <div class="strength-labels">
                            <span id="strength-label-0" class="strength-label">Weak</span>
                            <span id="strength-label-1" class="strength-label">Fair</span>
                            <span id="strength-label-2" class="strength-label">Good</span>
                            <span id="strength-label-3" class="strength-label">Strong</span>
                            <span id="strength-label-4" class="strength-label">Very Strong</span>
                        </div>
                    </div>
                    
                    <!-- Password requirements -->
                    <div class="requirement-list">
                        <div id="req-length" class="requirement-item">
                            <i class="fas fa-circle"></i> At least 8 characters
                        </div>
                        <div id="req-uppercase" class="requirement-item">
                            <i class="fas fa-circle"></i> One uppercase letter
                        </div>
                        <div id="req-lowercase" class="requirement-item">
                            <i class="fas fa-circle"></i> One lowercase letter
                        </div>
                        <div id="req-number" class="requirement-item">
                            <i class="fas fa-circle"></i> One number
                        </div>
                        <div id="req-special" class="requirement-item">
                            <i class="fas fa-circle"></i> One special character
                        </div>
                    </div>
                    
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="flex items-center mt-2 text-rose-400 text-sm">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Confirm Password Input -->
                <div class="relative group">
                    <input 
                        id="password_confirmation" 
                        type="password" 
                        name="password_confirmation" 
                        required
                        placeholder=" "
                        class="w-full px-5 py-4 rounded-xl input-field text-slate-200 placeholder-transparent focus:outline-none pr-12 group-hover:border-teal-400 transition-all duration-300"
                        onkeyup="checkPasswordMatch()"
                    >
                    <button type="button" class="password-toggle" onclick="togglePasswordVisibility('password_confirmation')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <label for="password_confirmation" class="input-label absolute left-5 top-4 text-slate-300 pointer-events-none label-animation">
                        <i class="fas fa-key mr-2 text-teal-400"></i>Confirm Password
                    </label>
                    <div id="password-match" class="mt-2">
                        <div id="match-indicator" class="match-indicator hidden">
                            <i class="fas fa-check-circle mr-2"></i>
                            <span>Passwords match</span>
                        </div>
                        <div id="mismatch-indicator" class="match-indicator hidden">
                            <i class="fas fa-times-circle mr-2"></i>
                            <span>Passwords do not match</span>
                        </div>
                    </div>
                </div>

                <!-- Terms Agreement -->
                <div class="flex items-start mt-4 group">
                    <input id="terms" type="checkbox" name="terms" class="form-checkbox rounded checkbox-teal text-teal-600 focus:ring-teal-500 focus:ring-offset-slate-800 mt-1 group-hover:ring-2 group-hover:ring-teal-400 transition-all duration-300">
                    <label for="terms" class="ml-2 text-sm text-slate-300 group-hover:text-teal-300 transition-colors duration-300">
                        I agree to the NCSBAS <a href="#" class="teal-link hover:text-teal-300 transition-colors duration-300">Terms of Service</a> and <a href="#" class="teal-link hover:text-teal-300 transition-colors duration-300">Privacy Policy</a>
                    </label>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full py-4 text-slate-100 font-semibold rounded-xl teal-gradient-btn text-lg mt-2">
                    <i class="fas fa-user-plus mr-2"></i>Create Account
                </button>
            </form>

            <!-- Login Link -->
            <div class="text-center pt-4">
                <p class="text-slate-300">
                    Already have an account?
                    <a href="<?php echo e(route('login')); ?>" class="teal-link font-medium ml-1 hover:text-teal-300 transition-colors duration-300">Sign in here</a>
                </p>
            </div>
            
            <!-- Status indicator -->
            <div class="flex items-center justify-center pt-2">
                <div class="pulse-dot mr-2"></div>
                <span class="text-xs text-teal-300">NCSBAS</span>
            </div>
        </div>
        
        <!-- Footer note -->
        <p class="text-center text-slate-400 text-sm mt-6">
            <i class="fas fa-shield-alt mr-1 text-teal-400"></i>
        </p>
    </div>

    <script>
        // Create animated particles
        function createParticles() {
            const container = document.getElementById('particles-container');
            const particleCount = 30;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random size
                const size = Math.random() * 100 + 20;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                
                // Random position
                particle.style.left = `${Math.random() * 100}vw`;
                particle.style.top = `${Math.random() * 100}vh`;
                
                // Random opacity
                particle.style.opacity = Math.random() * 0.1 + 0.05;
                
                // Random animation
                const duration = Math.random() * 20 + 10;
                const delay = Math.random() * 5;
                
                particle.style.animation = `
                    float ${duration}s ease-in-out ${delay}s infinite alternate
                `;
                
                container.appendChild(particle);
            }
            
            // Add CSS for floating animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes float {
                    0% {
                        transform: translate(0, 0) rotate(0deg);
                    }
                    33% {
                        transform: translate(${Math.random() * 100 - 50}px, ${Math.random() * 100 - 50}px) rotate(${Math.random() * 180}deg);
                    }
                    66% {
                        transform: translate(${Math.random() * 100 - 50}px, ${Math.random() * 100 - 50}px) rotate(${Math.random() * 180}deg);
                    }
                    100% {
                        transform: translate(0, 0) rotate(0deg);
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        // Password strength meter
        function checkPasswordStrength() {
            const password = document.getElementById("password").value;
            const strengthMeter = document.getElementById("strength-bar");
            const strengthLabels = [
                document.getElementById("strength-label-0"),
                document.getElementById("strength-label-1"),
                document.getElementById("strength-label-2"),
                document.getElementById("strength-label-3"),
                document.getElementById("strength-label-4")
            ];
            
            // Reset all labels
            strengthLabels.forEach(label => {
                label.classList.remove('active');
            });
            
            // Check requirements
            const hasLength = password.length >= 8;
            const hasUpperCase = /[A-Z]/.test(password);
            const hasLowerCase = /[a-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
            
            // Update requirement indicators
            updateRequirement('req-length', hasLength);
            updateRequirement('req-uppercase', hasUpperCase);
            updateRequirement('req-lowercase', hasLowerCase);
            updateRequirement('req-number', hasNumber);
            updateRequirement('req-special', hasSpecial);
            
            // Calculate strength
            let strength = 0;
            if (hasLength) strength += 1;
            if (hasUpperCase) strength += 1;
            if (hasLowerCase) strength += 1;
            if (hasNumber) strength += 1;
            if (hasSpecial) strength += 1;
            
            // Set strength meter width and background position
            const strengthWidth = strength * 20;
            strengthMeter.style.width = strengthWidth + "%";
            
            // Set background position to show appropriate color
            const bgPosition = (strength - 1) * 25;
            strengthMeter.style.backgroundPosition = `${bgPosition}% 0`;
            
            // Activate appropriate label
            if (strength > 0) {
                const activeIndex = Math.min(strength - 1, 4);
                strengthLabels[activeIndex].classList.add('active');
            }
            
            // Check password match if confirmation field has value
            checkPasswordMatch();
        }
        
        // Update requirement indicator
        function updateRequirement(elementId, isValid) {
            const element = document.getElementById(elementId);
            if (isValid) {
                element.classList.add('valid');
                element.innerHTML = '<i class="fas fa-check-circle text-teal-400"></i> ' + element.textContent.replace('●', '').trim();
            } else {
                element.classList.remove('valid');
                element.innerHTML = '<i class="fas fa-circle"></i> ' + element.textContent.replace('✓', '').trim();
            }
        }
        
        // Check if passwords match
        function checkPasswordMatch() {
            const password = document.getElementById("password").value;
            const confirmPassword = document.getElementById("password_confirmation").value;
            const matchIndicator = document.getElementById("match-indicator");
            const mismatchIndicator = document.getElementById("mismatch-indicator");
            
            if (confirmPassword.length === 0) {
                matchIndicator.classList.add('hidden');
                mismatchIndicator.classList.add('hidden');
                return;
            }
            
            if (password === confirmPassword) {
                matchIndicator.classList.remove('hidden');
                matchIndicator.classList.remove('match-bad');
                matchIndicator.classList.add('match-good');
                mismatchIndicator.classList.add('hidden');
            } else {
                mismatchIndicator.classList.remove('hidden');
                mismatchIndicator.classList.remove('match-good');
                mismatchIndicator.classList.add('match-bad');
                matchIndicator.classList.add('hidden');
            }
        }
        
        // Toggle password visibility
        function togglePasswordVisibility(fieldId) {
            const field = document.getElementById(fieldId);
            const toggleButton = field.nextElementSibling;
            const icon = toggleButton.querySelector('i');
            
            if (field.type === "password") {
                field.type = "text";
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = "password";
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        // Form interaction enhancements
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            
            const inputs = document.querySelectorAll('.input-field');
            
            inputs.forEach(input => {
                // Add floating label effect on page load if input has value
                if (input.value) {
                    input.nextElementSibling.classList.add('transformed');
                }
                
                // Add focus/blur effects
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('teal-glow');
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('teal-glow');
                });
            });
            
            // Form submission animation
            const form = document.querySelector('form');
            form.addEventListener('submit', function(e) {
                const terms = document.getElementById('terms');
                if (!terms.checked) {
                    e.preventDefault();
                    alert('Please agree to the NCSBAS Terms of Service and Privacy Policy');
                    return;
                }
                
                const btn = this.querySelector('button[type="submit"]');
                btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Creating Account...';
                btn.classList.add('opacity-90');
                btn.disabled = true;
            });
            
            // Initialize password strength on page load if password has value
            const passwordField = document.getElementById('password');
            if (passwordField && passwordField.value) {
                checkPasswordStrength();
            }
            
            // Initialize password match if confirmation field has value
            const confirmField = document.getElementById('password_confirmation');
            if (confirmField && confirmField.value) {
                checkPasswordMatch();
            }
        });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\auth\register.blade.php ENDPATH**/ ?>