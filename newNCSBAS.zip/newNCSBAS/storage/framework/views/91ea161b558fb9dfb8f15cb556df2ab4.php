
<div id="chatbot-widget" class="chatbot-widget">
    <!-- Floating Chat Bubble Button -->
    <button id="chatbot-toggle" class="chatbot-toggle">
        💬
    </button>

    <!-- Chat Window Card -->
    <div id="chatbot-window" class="chatbot-window">
        <!-- Header -->
        <div class="chatbot-header">
            <div>
                <div class="chatbot-title">CyberBot</div>
                <div class="chatbot-subtitle">NCSBAS Assistant</div>
            </div>
            <button id="chatbot-close" class="chatbot-close-btn">
                &times;
            </button>
        </div>

        <!-- Messages Area -->
        <div id="chatbot-messages" class="chatbot-messages">
            <!-- Messages will be added here by JavaScript -->
        </div>

        <!-- Input Row -->
        <div class="chatbot-input-row">
            <input 
                type="text" 
                id="chatbot-input" 
                class="chatbot-input"
                placeholder="Ask about this system..." 
                autocomplete="off"
            />
            <button id="chatbot-send" class="chatbot-send-btn">
                Send
            </button>
        </div>

        <!-- Typing Indicator -->
        <div id="chatbot-typing" class="chatbot-typing">
            CyberBot is typing...
        </div>
    </div>
</div>

<style>
    /* Chatbot Styles */
    .chatbot-widget {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 9999;
    }

    .chatbot-toggle {
        background: linear-gradient(135deg, #20c997, #198754);
        color: #212529;
        border: none;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        font-size: 24px;
        cursor: move;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
    }

    .chatbot-toggle:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 20px rgba(32, 201, 151, 0.4);
    }

    .chatbot-window {
        width: 350px;
        max-width: 90vw;
        background: #2c3034;
        border: 1px solid #20c997;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        display: none;
        position: absolute;
        bottom: 70px;
        right: 0;
        cursor: move;
    }

    .chatbot-header {
        background: #212529;
        padding: 12px 16px;
        border-bottom: 1px solid #343a40;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 12px 12px 0 0;
    }

    .chatbot-title {
        color: #20c997;
        font-weight: bold;
        font-size: 16px;
    }

    .chatbot-subtitle {
        color: #6c757d;
        font-size: 11px;
        margin-top: -2px;
    }

    .chatbot-close-btn {
        background: none;
        border: none;
        color: #6c757d;
        font-size: 24px;
        cursor: pointer;
        line-height: 1;
        padding: 0;
        width: 24px;
        height: 24px;
    }

    .chatbot-close-btn:hover {
        color: #20c997;
    }

    .chatbot-messages {
        height: 250px;
        overflow-y: auto;
        padding: 16px;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .message {
        max-width: 80%;
        padding: 10px 14px;
        border-radius: 12px;
        font-size: 14px;
        line-height: 1.4;
        word-wrap: break-word;
    }

    .message-user {
        background: #20c997;
        color: #212529;
        align-self: flex-end;
        border-bottom-right-radius: 4px;
    }

    .message-bot {
        background: #343a40;
        color: #e9ecef;
        align-self: flex-start;
        border-bottom-left-radius: 4px;
        border: 1px solid #495057;
    }

    .chatbot-input-row {
        padding: 12px 16px;
        border-top: 1px solid #343a40;
        display: flex;
        gap: 10px;
    }

    .chatbot-input {
        flex: 1;
        padding: 10px 14px;
        background: #343a40;
        border: 1px solid #495057;
        border-radius: 8px;
        color: #e9ecef;
        font-size: 14px;
    }

    .chatbot-input:focus {
        outline: none;
        border-color: #20c997;
        box-shadow: 0 0 0 2px rgba(32, 201, 151, 0.25);
    }

    .chatbot-send-btn {
        background: #20c997;
        color: #212529;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 14px;
    }

    .chatbot-send-btn:hover:not(:disabled) {
        background: #198754;
    }

    .chatbot-send-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }

    .chatbot-typing {
        color: #6c757d;
        font-size: 12px;
        padding: 8px 16px;
        display: none;
        font-style: italic;
        border-top: 1px solid #343a40;
    }

    @media (max-width: 768px) {
        .chatbot-window {
            width: 300px;
            bottom: 70px;
            right: 10px;
        }
        
        .chatbot-messages {
            height: 200px;
        }
    }
</style>

<script>
// Chatbot Class - Pure Vanilla JavaScript
class Chatbot {
    constructor() {
        this.isOpen = false;
        this.isDragging = false;
        this.dragOffset = { x: 0, y: 0 };
        
        // Elements
        this.widget = document.getElementById('chatbot-widget');
        this.toggleBtn = document.getElementById('chatbot-toggle');
        this.window = document.getElementById('chatbot-window');
        this.closeBtn = document.getElementById('chatbot-close');
        this.messagesContainer = document.getElementById('chatbot-messages');
        this.input = document.getElementById('chatbot-input');
        this.sendBtn = document.getElementById('chatbot-send');
        this.typingIndicator = document.getElementById('chatbot-typing');
        
        this.init();
    }
    
    init() {
        // Event Listeners
        this.toggleBtn.addEventListener('click', () => this.toggleWindow());
        this.closeBtn.addEventListener('click', () => this.closeWindow());
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        this.input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
        
        // Drag functionality
        this.toggleBtn.addEventListener('mousedown', (e) => this.startDrag(e));
        this.window.addEventListener('mousedown', (e) => this.startDrag(e));
        document.addEventListener('mousemove', (e) => this.drag(e));
        document.addEventListener('mouseup', () => this.stopDrag());
        
        // Touch support for mobile
        this.toggleBtn.addEventListener('touchstart', (e) => this.startDrag(e.touches[0]));
        this.window.addEventListener('touchstart', (e) => this.startDrag(e.touches[0]));
        document.addEventListener('touchmove', (e) => this.drag(e.touches[0]));
        document.addEventListener('touchend', () => this.stopDrag());
        
        // Add welcome message
        this.addMessage('Hello! 👋 I\'m CyberBot, your assistant for NCSBAS. How can I help you today?', 'bot');
    }
    
    toggleWindow() {
        this.isOpen = !this.isOpen;
        this.window.style.display = this.isOpen ? 'block' : 'none';
        if (this.isOpen) {
            setTimeout(() => this.input.focus(), 100);
        }
    }
    
    closeWindow() {
        this.isOpen = false;
        this.window.style.display = 'none';
    }
    
    startDrag(e) {
        this.isDragging = true;
        const rect = this.widget.getBoundingClientRect();
        this.dragOffset.x = e.clientX - rect.right;
        this.dragOffset.y = e.clientY - rect.bottom;
        this.toggleBtn.style.cursor = 'grabbing';
        this.window.style.cursor = 'grabbing';
    }
    
    drag(e) {
        if (!this.isDragging) return;
        
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        // Calculate new position
        const right = Math.max(0, windowWidth - e.clientX + this.dragOffset.x);
        const bottom = Math.max(0, windowHeight - e.clientY + this.dragOffset.y);
        
        // Update position
        this.widget.style.right = right + 'px';
        this.widget.style.bottom = bottom + 'px';
    }
    
    stopDrag() {
        this.isDragging = false;
        this.toggleBtn.style.cursor = 'move';
        this.window.style.cursor = 'move';
    }
    
    addMessage(text, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message message-${sender}`;
        messageDiv.innerHTML = this.formatMessage(text);
        this.messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    }
    
    formatMessage(text) {
        // Simple formatting - escape HTML and preserve newlines
        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/\n/g, '<br>')
            .replace(/\n\n+/g, '<br><br>');
    }
    
    async sendMessage() {
        const message = this.input.value.trim();
        if (!message) return;
        
        // Add user message
        this.addMessage(message, 'user');
        this.input.value = '';
        this.sendBtn.disabled = true;
        
        // Show typing indicator
        this.typingIndicator.style.display = 'block';
        this.scrollToBottom();
        
        try {
            // Send to Laravel backend
            const response = await fetch('<?php echo e(route("chatbot.message")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ message: message })
            });
            
            const data = await response.json();
            this.addMessage(data.reply, 'bot');
        } catch (error) {
            this.addMessage("Sorry, I couldn't connect to the assistant. Please try again.", 'bot');
        } finally {
            this.typingIndicator.style.display = 'none';
            this.sendBtn.disabled = false;
            this.input.focus();
        }
    }
    
    scrollToBottom() {
        setTimeout(() => {
            this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
        }, 100);
    }
}

// Initialize chatbot when page loads
document.addEventListener('DOMContentLoaded', () => {
    new Chatbot();
});
</script><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\components\chatbot.blade.php ENDPATH**/ ?>