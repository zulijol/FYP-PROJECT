<form method="POST" action="<?php echo e(route('password.update')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="token" value="<?php echo e($token); ?>">
    <input type="email" name="email" required />
    <input type="password" name="password" required />
    <input type="password" name="password_confirmation" required />
    <button type="submit">Reset Password</button>
</form>
<?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\auth\resetpassword.blade.php ENDPATH**/ ?>