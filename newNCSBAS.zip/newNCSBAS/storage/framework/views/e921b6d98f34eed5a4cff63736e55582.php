<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>NCSBAS Assessment Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
        .logo { font-size: 24px; font-weight: bold; color: #0d9488; }
        .subtitle { color: #666; margin-top: 5px; }
        .section { margin-bottom: 25px; }
        .section-title { background-color: #f0f0f0; padding: 10px; font-weight: bold; border-left: 4px solid #0d9488; }
        .table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        .table th { background-color: #0d9488; color: white; padding: 10px; text-align: left; }
        .table td { padding: 10px; border: 1px solid #ddd; }
        .maturity-score { font-size: 36px; font-weight: bold; color: #0d9488; text-align: center; }
        .domain-row { background-color: #f9f9f9; }
        .footer { margin-top: 50px; text-align: center; color: #666; font-size: 12px; border-top: 1px solid #ddd; padding-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">NCSBAS</div>
        <div class="subtitle">National Cyber Security Baseline Assessment System</div>
        <h1>Cybersecurity Maturity Assessment Report</h1>
    </div>
    
    <div class="section">
        <div class="section-title">Assessment Overview</div>
        <table class="table">
            <tr>
                <td><strong>Assessment File:</strong></td>
                <td><?php echo e($assessment->filename); ?></td>
            </tr>
            <tr>
                <td><strong>Date:</strong></td>
                <td><?php echo e($assessment->uploaded_at->format('F j, Y')); ?></td>
            </tr>
            <tr>
                <td><strong>Organization:</strong></td>
                <td><?php echo e($user->name ?? 'Not specified'); ?></td>
            </tr>
        </table>
    </div>
    
    <div class="section">
        <div class="section-title">Overall Maturity Score</div>
        <div class="maturity-score"><?php echo e(number_format($overall_maturity, 2)); ?>/3.0</div>
        <p style="text-align: center;">
            <?php
                $overall_level = 'Initial';
                if ($overall_maturity >= 2.5) {
                    $overall_level = 'Advanced';
                } elseif ($overall_maturity >= 1.5) {
                    $overall_level = 'Intermediate';
                } elseif ($overall_maturity >= 0.5) {
                    $overall_level = 'Basic';
                }
            ?>
            <?php echo e($overall_level); ?>

        </p>
    </div>
    
    <div class="section">
        <div class="section-title">Domain Level Results</div>
        <table class="table">
            <tr>
                <th>Domain</th>
                <th>Score</th>
                <th>Level</th>
            </tr>
            <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="domain-row">
                <td><?php echo e($domain); ?></td>
                <td><?php echo e(number_format($score, 2)); ?></td>
                <td>
                    <?php
                        $domain_level = 'Initial';
                        if ($score >= 2.5) {
                            $domain_level = 'Advanced';
                        } elseif ($score >= 1.5) {
                            $domain_level = 'Intermediate';
                        } elseif ($score >= 0.5) {
                            $domain_level = 'Basic';
                        }
                    ?>
                    <?php echo e($domain_level); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    
    <div class="section">
        <div class="section-title">Response Statistics</div>
        <table class="table">
            <tr>
                <th>Response Type</th>
                <th>Count</th>
                <th>Percentage</th>
            </tr>
            <tr>
                <td>Yes</td>
                <td><?php echo e($stats['yes_count']); ?></td>
                <td><?php echo e($stats['yes_percentage']); ?>%</td>
            </tr>
            <tr>
                <td>No</td>
                <td><?php echo e($stats['no_count']); ?></td>
                <td><?php echo e($stats['no_percentage']); ?>%</td>
            </tr>
            <tr>
                <td>Not Answered</td>
                <td><?php echo e($stats['empty_count']); ?></td>
                <td><?php echo e($stats['empty_percentage']); ?>%</td>
            </tr>
            <tr>
                <td><strong>Total Questions</strong></td>
                <td colspan="2"><strong><?php echo e($stats['total']); ?></strong></td>
            </tr>
        </table>
    </div>
    
    <div class="footer">
        <p>Report generated on <?php echo e($report_date); ?> by NCSBAS System</p>
        <p>Official National Cyber Security Baseline Assessment Framework</p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\reports\assessment-report.blade.php ENDPATH**/ ?>