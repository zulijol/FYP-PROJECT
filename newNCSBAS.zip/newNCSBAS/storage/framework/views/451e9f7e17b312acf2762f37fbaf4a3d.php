
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'NCSBAS'); ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Your Custom CSS -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <!-- Alpine.js CDN -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.8/dist/cdn.min.js"></script>
    
</head>
<body>
    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                <i class="fas fa-shield-virus"></i>
                NCSBAS
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" 
                    aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarMain">
                <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <!-- Dashboard - All Roles -->
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" 
                           href="<?php echo e(route('dashboard')); ?>">
                            <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                        </a>
                    </li>
                    
                    <!-- ASSESSOR MENU ITEMS -->
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'assessor')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('assessment.list') ? 'active' : ''); ?>" 
                           href="<?php echo e(route('assessment.list')); ?>">
                            <i class="fas fa-file-alt me-1"></i> My Assessments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('assessment.upload.*') ? 'active' : ''); ?>" 
                           href="<?php echo e(route('assessment.upload.form')); ?>">
                            <i class="fas fa-upload me-1"></i> Upload
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- REVIEWER MENU ITEMS -->
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'reviewer')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('review.*') ? 'active' : ''); ?>" 
                           href="<?php echo e(route('review.dashboard')); ?>">
                            <i class="fas fa-search me-1"></i> Review
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <!-- ADMIN MENU ITEMS (Removed - Admin only sees Dashboard) -->
                    <!-- No special admin menu items - they only see Dashboard -->
                </ul>
                <?php endif; ?>
                
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" 
                           role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="avatar-sm me-2">
                                <?php echo e(strtoupper(substr(Auth::user()->name, 0, 1))); ?>

                            </div>
                            <div class="d-none d-sm-block">
                                <div class="fw-semibold" style="font-size: 0.875rem;"><?php echo e(Auth::user()->name); ?></div>
                                <small class="text-primary" style="font-size: 0.75rem;">
                                    <?php echo e(Auth::user()->email); ?>

                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                        <span class="role-badge badge-admin ms-2">Admin</span>
                                    <?php elseif(Auth::user()->hasRole('reviewer')): ?>
                                        <span class="role-badge badge-reviewer ms-2">Reviewer</span>
                                    <?php elseif(Auth::user()->hasRole('assessor')): ?>
                                        <span class="role-badge badge-assessor ms-2">Assessor</span>
                                    <?php endif; ?>
                                </small>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">
                                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                                </a>
                            </li>
                            <li>
                            </li>
                            <li>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="mb-0">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-primary px-2" href="<?php echo e(route('login')); ?>">
                            <i class="fas fa-sign-in-alt me-1"></i> Login
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
    <main class="container-fluid">
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <div class="fade-in">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    
    <!-- Footer -->
    <footer class="mt-3">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="d-flex align-items-center">
                        <div class="avatar-sm me-2">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div>
                            <h6 class="mb-1 text-white" style="font-size: 0.875rem;">NCSBAS Assessment System</h6>
                            <p class="mb-0 small">&copy; <?php echo e(date('Y')); ?> All rights reserved</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-md-end mt-2 mt-md-0">
                    <div class="d-flex justify-content-md-end gap-3">
                        <a href="#" class="text-decoration-none">
                            <i class="fas fa-question-circle me-1"></i> Help
                        </a>
                        <a href="#" class="text-decoration-none">
                            <i class="fas fa-envelope me-1"></i> Contact
                        </a>
                        <a href="#" class="text-decoration-none">
                            <i class="fas fa-shield-alt me-1"></i> Privacy
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Your Custom JavaScript -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    <!-- Chatbot Component -->
    <?php echo $__env->make('components.chatbot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\layouts\app.blade.php ENDPATH**/ ?>