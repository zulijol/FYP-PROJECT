

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-1">Reviewer Dashboard</h2>
            <p class="text-muted mb-0">Welcome back, <?php echo e(Auth::user()->name); ?></p>
        </div>
        <div class="col-auto">
            <a href="<?php echo e(route('review.assessments')); ?>" class="btn btn-primary">
                <i class="fas fa-list me-1"></i>View All Assessments
            </a>
        </div>
    </div>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-primary"><?php echo e($totalAssessments); ?></h3>
                    <p class="text-muted mb-0">Total Assessments</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-secondary"><?php echo e($importedAssessments); ?></h3>
                    <p class="text-muted mb-0">Imported</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-warning"><?php echo e($inReviewAssessments); ?></h3>
                    <p class="text-muted mb-0">In Review</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-success"><?php echo e($completedAssessments); ?></h3>
                    <p class="text-muted mb-0">Completed</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Assessments Needing Review -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Recent Assessments Needing Review</h5>
            <p class="text-muted mb-0">Latest imported and in-review assessments</p>
        </div>
        <div class="card-body">
            <?php if($recentAssessments->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Filename</th>
                                <th>Uploaded By</th>
                                <th>Upload Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentAssessments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assessment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#<?php echo e($assessment->id); ?></td>
                                <td>
                                    <span class="d-inline-block text-truncate" style="max-width: 200px;">
                                        <?php echo e($assessment->filename); ?>

                                    </span>
                                </td>
                                <td><?php echo e($assessment->user->name ?? 'Unknown'); ?></td>
                                <td><?php echo e($assessment->uploaded_at->format('d M Y')); ?></td>
                                <td>
                                    <?php
                                        $statusClass = [
                                            'imported' => 'secondary',
                                            'in_review' => 'warning',
                                            'completed' => 'success',
                                            'not_reviewed' => 'danger'
                                        ][$assessment->status] ?? 'secondary';
                                        
                                        $statusLabels = [
                                            'imported' => 'Imported',
                                            'in_review' => 'In Review',
                                            'completed' => 'Completed',
                                            'not_reviewed' => 'Not Reviewed'
                                        ];
                                    ?>
                                    <span class="badge bg-<?php echo e($statusClass); ?>">
                                        <?php echo e($statusLabels[$assessment->status] ?? $assessment->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="<?php echo e(route('review.show', $assessment->id)); ?>" 
                                           class="btn btn-outline-primary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <?php if($assessment->status == 'imported'): ?>
                                            <form action="<?php echo e(route('review.mark.reviewed', $assessment->id)); ?>" 
                                                  method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-outline-warning" 
                                                        title="Mark as In Review">
                                                    <i class="fas fa-play-circle"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-center mt-3">
                    <a href="<?php echo e(route('review.assessments')); ?>" class="btn btn-primary">
                        <i class="fas fa-list me-1"></i>View All Assessments
                    </a>
                </div>
            <?php else: ?>
                <div class="text-center py-4">
                    <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                    <h5 class="text-muted">All caught up!</h5>
                    <p class="text-muted mb-0">No assessments need review at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\reviewer\dashboard.blade.php ENDPATH**/ ?>