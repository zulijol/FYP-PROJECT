

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-1">Admin Dashboard</h2>
            <p class="text-muted mb-0">Manage users and their roles</p>
        </div>
        <div class="col-auto">
            <div class="alert alert-info mb-0">
                <i class="fas fa-info-circle me-2"></i>
                You are logged in as: <strong><?php echo e(Auth::user()->name); ?></strong>
            </div>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-primary"><?php echo e($users->total()); ?></h3>
                    <p class="text-muted mb-0">Total Users</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-danger"><?php echo e($users->filter(fn($user) => $user->hasRole('admin'))->count()); ?></h3>
                    <p class="text-muted mb-0">Admins</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-warning"><?php echo e($users->filter(fn($user) => $user->hasRole('reviewer'))->count()); ?></h3>
                    <p class="text-muted mb-0">Reviewers</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-info"><?php echo e($users->filter(fn($user) => $user->hasRole('assessor'))->count()); ?></h3>
                    <p class="text-muted mb-0">Assessors</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">All Users</h5>
            <p class="text-muted mb-0">Manage user roles and delete users</p>
        </div>
        <div class="card-body">
            <?php if($users->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Current Role</th>
                                <th>Change Role</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#<?php echo e($user->id); ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-circle-sm bg-primary text-white me-2">
                                            <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                        </div>
                                        <div>
                                            <?php echo e($user->name); ?>

                                            <?php if($user->id === auth()->id()): ?>
                                                <span class="badge bg-info ms-1">You</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge 
                                            <?php if($role->name === 'admin'): ?> bg-danger
                                            <?php elseif($role->name === 'reviewer'): ?> bg-warning text-dark
                                            <?php elseif($role->name === 'assessor'): ?> bg-primary
                                            <?php else: ?> bg-secondary <?php endif; ?>">
                                            <?php echo e(ucfirst($role->name)); ?>

                                        </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('admin.users.updateRole', $user->id)); ?>" method="POST" class="d-flex">
                                        <?php echo csrf_field(); ?>
                                        <select name="role" class="form-select form-select-sm me-2" 
                                                onchange="this.form.submit()" <?php echo e($user->id === auth()->id() ? 'disabled' : ''); ?>>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>" 
                                                    <?php echo e($user->hasRole($role->name) ? 'selected' : ''); ?>>
                                                    <?php echo e(ucfirst($role->name)); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                </td>
                                <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                                <td>
                                    <?php if($user->id !== auth()->id()): ?>
                                        <form action="<?php echo e(route('admin.users.delete', $user->id)); ?>" 
                                              method="POST" class="d-inline"
                                              onsubmit="return confirm('Are you sure you want to delete <?php echo e($user->name); ?>? This action cannot be undone.');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete User">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small">(Current User)</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if($users->hasPages()): ?>
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($users->links()); ?>

                </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No users found</h5>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Role Legend -->
    <div class="card mt-4">
        <div class="card-header">
            <h6 class="mb-0">Role Descriptions</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="d-flex align-items-center mb-2">
                        <span class="badge bg-danger me-2">Admin</span>
                        <span class="small">Full system access, can manage users</span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center mb-2">
                        <span class="badge bg-warning text-dark me-2">Reviewer</span>
                        <span class="small">Can review and approve assessments</span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center mb-2">
                        <span class="badge bg-primary me-2">Assessor</span>
                        <span class="small">Can upload assessments and view results</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .avatar-circle-sm {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 14px;
    }
    .badge {
        font-size: 0.75em;
        padding: 0.35em 0.65em;
    }
    .form-select-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
        width: 120px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>