

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('review.dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('review.assessments')); ?>">All Assessments</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Assessment #<?php echo e($assessment->id); ?></li>
                </ol>
            </nav>
            
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h2 class="mb-1">Assessment #<?php echo e($assessment->id); ?></h2>
                    <p class="text-muted mb-0"><?php echo e($assessment->filename); ?></p>
                    <p class="text-muted mb-0">
                        Uploaded by <strong><?php echo e($assessment->user->name ?? 'Unknown User'); ?></strong> 
                        on <?php echo e($assessment->uploaded_at->format('d M Y, H:i')); ?>

                    </p>
                </div>
                <a href="<?php echo e(route('review.assessments')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to List
                </a>
            </div>
        </div>
    </div>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-primary">
                <div class="card-body text-center">
                    <h3 class="card-title display-6 text-primary"><?php echo e($stats['total']); ?></h3>
                    <p class="card-text text-muted">Total Questions</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-success"><?php echo e($stats['yes_count']); ?></h3>
                    <p class="text-muted mb-0">Yes (<?php echo e($stats['yes_percentage']); ?>%)</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-danger"><?php echo e($stats['no_count']); ?></h3>
                    <p class="text-muted mb-0">No (<?php echo e($stats['no_percentage']); ?>%)</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-warning"><?php echo e($stats['empty_count']); ?></h3>
                    <p class="text-muted mb-0">Empty (<?php echo e($stats['empty_percentage']); ?>%)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Review Actions Card -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Review Actions</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('review.update.status', $assessment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">Update Status</label>
                            <select name="status" class="form-select" required>
                                <option value="imported" <?php echo e($assessment->status == 'imported' ? 'selected' : ''); ?>>Imported</option>
                                <option value="in_review" <?php echo e($assessment->status == 'in_review' ? 'selected' : ''); ?>>In Review</option>
                                <option value="completed" <?php echo e($assessment->status == 'completed' ? 'selected' : ''); ?>>Mark as Completed</option>
                                <option value="not_reviewed" <?php echo e($assessment->status == 'not_reviewed' ? 'selected' : ''); ?>>Not Reviewed</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label class="form-label">Review Comments (Optional)</label>
                            <textarea name="comments" class="form-control" rows="2" 
                                      placeholder="Add any comments or feedback for the assessor..."><?php echo e($assessment->notes ?? ''); ?></textarea>
                            <small class="text-muted">Comments will be saved in the assessment notes.</small>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <div>
                        <a href="<?php echo e(route('review.assessments')); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i>Back to List
                        </a>
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Status
                        </button>
                        
                        <?php if($assessment->status == 'imported'): ?>
                            <button type="button" class="btn btn-warning" 
                                    onclick="document.querySelector('select[name=\"status\"]').value='in_review'; document.querySelector('form').submit();">
                                <i class="fas fa-play-circle me-1"></i>Start Review
                            </button>
                        <?php endif; ?>
                        
                        <?php if($assessment->status == 'in_review'): ?>
                            <button type="button" class="btn btn-success" 
                                    onclick="document.querySelector('select[name=\"status\"]').value='completed'; document.querySelector('form').submit();">
                                <i class="fas fa-check-circle me-1"></i>Mark as Completed
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Current Status Info -->
    <div class="alert 
        <?php if($assessment->status == 'imported'): ?> alert-secondary
        <?php elseif($assessment->status == 'in_review'): ?> alert-warning
        <?php elseif($assessment->status == 'completed'): ?> alert-success
        <?php elseif($assessment->status == 'not_reviewed'): ?> alert-danger
        <?php else: ?> alert-info <?php endif; ?>">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <strong>Current Status:</strong>
                <?php
                    $statusClass = [
                        'imported' => 'secondary',
                        'in_review' => 'warning',
                        'completed' => 'success',
                        'not_reviewed' => 'danger'
                    ][$assessment->status] ?? 'secondary';
                    
                    $statusLabels = [
                        'imported' => 'Imported',
                        'in_review' => 'In Review',
                        'completed' => 'Completed',
                        'not_reviewed' => 'Not Reviewed'
                    ];
                ?>
                <span class="badge bg-<?php echo e($statusClass); ?> ms-2">
                    <?php echo e($statusLabels[$assessment->status] ?? $assessment->status); ?>

                </span>
                
                <?php if($assessment->reviewed_at): ?>
                    <div class="mt-1">
                        <i class="fas fa-calendar-check me-1"></i>
                        Reviewed on: <?php echo e($assessment->reviewed_at->format('d M Y, H:i')); ?>

                        <?php if($assessment->reviewed_by): ?>
                            by <?php echo e($assessment->reviewed_by_user->name ?? 'Reviewer'); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if($assessment->notes): ?>
                <div>
                    <button class="btn btn-sm btn-outline-info" type="button" data-bs-toggle="collapse" data-bs-target="#notesCollapse">
                        <i class="fas fa-sticky-note me-1"></i>View Notes
                    </button>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if($assessment->notes): ?>
        <div class="collapse mt-3" id="notesCollapse">
            <div class="card card-body">
                <strong>Assessment Notes:</strong>
                <p class="mb-0"><?php echo e($assessment->notes); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Responses by Domain -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Questions & Responses</h5>
            <p class="text-muted mb-0">Organized by domain</p>
        </div>
        <div class="card-body">
            <?php if($responsesByDomain->count() > 0): ?>
                <?php $__currentLoopData = $responsesByDomain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain => $responses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-5">
                    <h5 class="border-bottom pb-2 mb-3">
                        <?php echo e($domain); ?>

                        <span class="badge bg-secondary ms-2"><?php echo e($responses->count()); ?> questions</span>
                    </h5>
                    
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th width="60">#</th>
                                    <th>Category</th>
                                    <th>Element</th>
                                    <th>Question</th>
                                    <th width="100">Response</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-muted"><?php echo e($response->number); ?></td>
                                    <td><small><?php echo e($response->category); ?></small></td>
                                    <td><small><?php echo e($response->element); ?></small></td>
                                    <td>
                                        <div class="fw-bold mb-1"><?php echo e($response->question); ?></div>
                                        <?php if($response->description): ?>
                                            <small class="text-muted d-block"><?php echo e($response->description); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($response->response === 'Yes'): ?>
                                            <span class="badge bg-success">Yes</span>
                                        <?php elseif($response->response === 'No'): ?>
                                            <span class="badge bg-danger">No</span>
                                        <?php elseif($response->response === 'N/A' || $response->response === 'NA'): ?>
                                            <span class="badge bg-secondary">N/A</span>
                                        <?php elseif(empty($response->response) || $response->response === null): ?>
                                            <span class="badge bg-warning text-dark">Empty</span>
                                        <?php else: ?>
                                            <span class="badge bg-info"><?php echo e($response->response); ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="text-center py-4">
                    <p class="text-muted">No responses found for this assessment.</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <div class="d-flex justify-content-between align-items-center">
                <div class="text-muted small">
                    Assessment ID: #<?php echo e($assessment->id); ?> | 
                    Questions: <?php echo e($assessment->total_questions); ?> |
                    Uploaded: <?php echo e($assessment->uploaded_at->format('d M Y')); ?>

                </div>
                <a href="<?php echo e(route('review.assessments')); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to All Assessments
                </a>
            </div>
        </div>
    </div>
</div>

<style>
    .table-sm td, .table-sm th {
        padding: 0.75rem 0.5rem;
    }
    .badge {
        font-size: 0.85em;
        padding: 0.35em 0.65em;
    }
    .alert {
        border-left: 4px solid;
    }
    .alert-secondary {
        border-left-color: #6c757d;
    }
    .alert-warning {
        border-left-color: #ffc107;
    }
    .alert-success {
        border-left-color: #198754;
    }
    .alert-danger {
        border-left-color: #dc3545;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\reviewer\show.blade.php ENDPATH**/ ?>