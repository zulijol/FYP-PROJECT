


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
        <h1 class="h2 text-white mb-0">
            <i class="fas fa-chart-bar text-teal me-2"></i>Assessment Results
            <small class="text-teal d-block mt-1"><?php echo e($upload->organization_name); ?></small>
        </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="<?php echo e(route('assessment.list')); ?>" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-1"></i> Back to List
            </a>
        </div>
    </div>

    <!-- Radar Chart Card -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="card-title mb-0 text-white">
                <i class="fas fa-radar text-teal me-2"></i>Element Maturity Radar Chart
            </h5>
        </div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="radarChart" height="100"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Element Maturity Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0 text-white">
                <i class="fas fa-table text-teal me-2"></i>Element Maturity Details
            </h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4">Element</th>
                            <th>YES Count</th>
                            <th>Maturity Level</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $elementMaturity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td class="ps-4">
                                <div class="d-flex align-items-center">
                                    <div class="element-icon me-2">
                                        <i class="fas fa-layer-group text-teal"></i>
                                    </div>
                                    <span class="text-white"><?php echo e($element); ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="fw-bold text-teal"><?php echo e($data['yes_count']); ?></span>
                            </td>
                            <td>
                                <?php
                                    $maturityColors = [
                                        0 => 'danger',
                                        1 => 'warning',
                                        2 => 'info',
                                        3 => 'success'
                                    ];
                                    $color = $maturityColors[$data['maturity_level']] ?? 'secondary';
                                ?>
                                <span class="badge bg-<?php echo e($color); ?> text-dark">
                                    Level <?php echo e($data['maturity_level']); ?>/3
                                </span>
                            </td>
                            <td>
                                <?php if($data['maturity_level'] >= 2): ?>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-check-circle text-success me-2"></i>
                                        <span class="text-success">Good</span>
                                    </div>
                                <?php elseif($data['maturity_level'] == 1): ?>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                                        <span class="text-warning">Needs Improvement</span>
                                    </div>
                                <?php else: ?>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-times-circle text-danger me-2"></i>
                                        <span class="text-danger">Poor</span>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            <div class="row">
                <div class="col-md-6">
                    <div class="legend d-flex flex-wrap gap-3">
                        <div class="d-flex align-items-center">
                            <span class="badge bg-success text-dark me-2">Level 3</span>
                            <small class="text-light">Advanced</small>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="badge bg-info text-dark me-2">Level 2</span>
                            <small class="text-light">Intermediate</small>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="badge bg-warning text-dark me-2">Level 1</span>
                            <small class="text-light">Basic</small>
                        </div>
                        <div class="d-flex align-items-center">
                            <span class="badge bg-danger text-dark me-2">Level 0</span>
                            <small class="text-light">Poor</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <a href="<?php echo e(route('assessment.download', $upload->id)); ?>" class="btn btn-outline-teal btn-sm">
                        <i class="fas fa-download me-1"></i> Download Results
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const radarData = <?php echo $radarChartData; ?>;
    
    // Customize radar chart colors for black & teal theme
    if (radarData.datasets && radarData.datasets.length > 0) {
        radarData.datasets.forEach((dataset, index) => {
            dataset.borderColor = '#20c997'; // Teal
            dataset.backgroundColor = 'rgba(32, 201, 151, 0.2)';
            dataset.pointBackgroundColor = '#20c997';
            dataset.pointBorderColor = '#ffffff';
            dataset.pointHoverBackgroundColor = '#ffffff';
            dataset.pointHoverBorderColor = '#20c997';
            dataset.fill = true;
        });
    }
    
    const ctx = document.getElementById('radarChart').getContext('2d');
    const radarChart = new Chart(ctx, {
        type: 'radar',
        data: radarData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true,
                    max: 3,
                    ticks: {
                        stepSize: 1,
                        color: '#e9ecef',
                        backdropColor: 'transparent'
                    },
                    angleLines: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    pointLabels: {
                        color: '#e9ecef',
                        font: {
                            size: 11
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#e9ecef',
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#2c3034',
                    titleColor: '#20c997',
                    bodyColor: '#e9ecef',
                    borderColor: '#20c997',
                    borderWidth: 1,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: Level ${context.raw}/3`;
                        }
                    }
                }
            }
        }
    });
</script>

<style>
    :root {
        --teal: #20c997;
        --teal-dark: #198754;
        --dark: #212529;
        --darker: #121416;
        --card-bg: #2c3034;
        --border-color: #343a40;
        --light-text: #e9ecef;
    }

    .card {
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        margin-bottom: 1.5rem;
    }

    .card-header {
        background: rgba(33, 37, 41, 0.9);
        border-bottom: 1px solid var(--border-color);
        padding: 0.75rem 1rem;
    }

    .card-title {
        color: white;
        font-weight: 600;
        font-size: 1.1rem;
        margin: 0;
    }

    .card-body {
        padding: 1rem;
    }

    .chart-container {
        position: relative;
        height: 400px;
        width: 100%;
    }

    /* Table Styling */
    .table-dark {
        --bs-table-bg: var(--darker);
        --bs-table-striped-bg: rgba(255, 255, 255, 0.05);
        --bs-table-hover-bg: rgba(32, 201, 151, 0.1);
        color: var(--light-text);
        border-color: var(--border-color);
    }

    .table-dark thead th {
        background-color: rgba(33, 37, 41, 0.9);
        border-color: var(--border-color);
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
        color: var(--teal);
        padding: 0.75rem;
    }

    .table-dark td {
        border-color: var(--border-color);
        padding: 0.75rem;
        vertical-align: middle;
    }

    /* Badge Styling */
    .badge {
        font-weight: 600;
        padding: 0.25em 0.6em;
        border-radius: 4px;
        font-size: 0.75rem;
    }

    .bg-success {
        background-color: #20c997 !important;
        color: var(--dark) !important;
    }

    .bg-info {
        background-color: #17a2b8 !important;
        color: var(--dark) !important;
    }

    .bg-warning {
        background-color: #ffc107 !important;
        color: var(--dark) !important;
    }

    .bg-danger {
        background-color: #dc3545 !important;
        color: white !important;
    }

    /* Text Colors */
    .text-teal {
        color: var(--teal) !important;
    }

    .text-white {
        color: white !important;
    }

    .text-light {
        color: var(--light-text) !important;
        opacity: 0.9;
    }

    /* Button Styling */
    .btn-outline-light {
        color: rgba(255, 255, 255, 0.8);
        border-color: rgba(255, 255, 255, 0.3);
    }

    .btn-outline-light:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
        border-color: rgba(255, 255, 255, 0.5);
    }

    .btn-outline-teal {
        color: var(--teal);
        border-color: var(--teal);
    }

    .btn-outline-teal:hover {
        background: var(--teal);
        color: var(--dark);
        border-color: var(--teal);
    }

    /* Element Icon */
    .element-icon {
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    /* Card Footer */
    .card-footer {
        background: rgba(33, 37, 41, 0.8);
        border-top: 1px solid var(--border-color);
        padding: 0.75rem 1rem;
    }

    /* Legend */
    .legend {
        margin: 0;
    }

    /* Responsive Adjustments */
    @media (max-width: 768px) {
        .chart-container {
            height: 300px;
        }
        
        .table-responsive {
            font-size: 0.875rem;
        }
        
        .legend {
            gap: 1rem;
            margin-bottom: 1rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\assessment\results.blade.php ENDPATH**/ ?>