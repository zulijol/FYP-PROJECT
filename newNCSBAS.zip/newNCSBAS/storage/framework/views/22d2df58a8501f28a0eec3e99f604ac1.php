<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | NCSBAS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Black & Teal gradient animation */
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        body {
            background: linear-gradient(
                -45deg,
                #000000,    /* Pure Black */
                #0a1929,    /* Deep Navy Blue */
                #0d2538,    /* Dark Teal Blue */
                #0a2e2e,    /* Dark Forest Green */
                #083344,    /* Deep Ocean Blue */
                #134e4a,    /* Dark Emerald */
                #115e59,    /* Teal */
                #0f766e,    /* Medium Teal */
                #0d9488,    /* Bright Teal */
                #14b8a6,    /* Light Teal */
                #2dd4bf     /* Pale Teal */
            );
            background-size: 400% 400%;
            animation: gradientShift 20s ease infinite;
            color: #f8fafc;
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Animated gradient overlay */
        .gradient-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                45deg,
                rgba(20, 184, 166, 0.1),
                rgba(13, 148, 136, 0.05),
                rgba(15, 118, 110, 0.03),
                transparent
            );
            pointer-events: none;
            z-index: -1;
        }
        
        /* Floating particles */
        .particle {
            position: fixed;
            background: rgba(20, 184, 166, 0.1);
            border-radius: 50%;
            pointer-events: none;
            z-index: -1;
        }
        
        .glass-card {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(45, 212, 191, 0.25);
            box-shadow: 
                0 10px 40px rgba(0, 0, 0, 0.4),
                0 0 40px rgba(20, 184, 166, 0.15),
                inset 0 1px 0 rgba(255, 255, 255, 0.1);
            transition: all 0.4s ease;
        }
        
        .glass-card:hover {
            border-color: rgba(94, 234, 212, 0.4);
            box-shadow: 
                0 15px 50px rgba(0, 0, 0, 0.5),
                0 0 60px rgba(20, 184, 166, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.15);
        }
        
        .teal-glow {
            box-shadow: 0 0 20px rgba(20, 184, 166, 0.5);
        }
        
        .input-field {
            background: rgba(30, 41, 59, 0.7);
            border: 1px solid rgba(94, 234, 212, 0.3);
            transition: all 0.3s ease;
        }
        
        .input-field:focus {
            background: rgba(30, 41, 59, 0.9);
            border-color: rgba(94, 234, 212, 0.6);
            box-shadow: 0 0 0 3px rgba(20, 184, 166, 0.3);
        }
        
        .teal-gradient-btn {
            background: linear-gradient(135deg, 
                #0d9488 0%, 
                #14b8a6 25%, 
                #2dd4bf 50%, 
                #14b8a6 75%, 
                #0d9488 100%);
            background-size: 200% auto;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }
        
        .teal-gradient-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent, 
                rgba(255, 255, 255, 0.2), 
                transparent);
            transition: 0.5s;
        }
        
        .teal-gradient-btn:hover::before {
            left: 100%;
        }
        
        .teal-gradient-btn:hover {
            background-position: right center;
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(20, 184, 166, 0.5);
        }
        
        .label-animation {
            transition: all 0.3s ease;
        }
        
        .input-field:focus + .input-label,
        .input-field:not(:placeholder-shown) + .input-label {
            transform: translateY(-24px) scale(0.9);
            color: #5eead4;
        }
        
        .checkbox-teal:checked {
            background-color: #0d9488;
            border-color: #0d9488;
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            color: #94a3b8;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid rgba(94, 234, 212, 0.3);
        }
        
        .divider:not(:empty)::before {
            margin-right: 1em;
        }
        
        .divider:not(:empty)::after {
            margin-left: 1em;
        }
        
        .teal-link {
            color: #5eead4;
            position: relative;
            text-decoration: none;
        }
        
        .teal-link:hover {
            color: #99f6e4;
        }
        
        .teal-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -2px;
            left: 0;
            background: linear-gradient(90deg, #5eead4, #14b8a6);
            transition: width 0.3s ease;
        }
        
        .teal-link:hover::after {
            width: 100%;
        }
        
        .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #14b8a6;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { 
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(20, 184, 166, 0.7); 
            }
            70% { 
                transform: scale(1);
                box-shadow: 0 0 0 10px rgba(20, 184, 166, 0); 
            }
            100% { 
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(20, 184, 166, 0); 
            }
        }
        
        /* NCSBAS branding with teal effect */
        .ncsbas-text {
            font-family: 'Arial', sans-serif;
            letter-spacing: 2px;
            font-weight: 800;
            text-shadow: 
                0 0 20px rgba(20, 184, 166, 0.5),
                0 0 40px rgba(20, 184, 166, 0.3);
            position: relative;
            display: inline-block;
        }
        
        .ncsbas-text::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: -5px;
            left: 0;
            background: linear-gradient(90deg, 
                transparent, 
                #5eead4, 
                #14b8a6, 
                #5eead4, 
                transparent);
            border-radius: 2px;
        }
        
        .back-btn {
            background: rgba(30, 41, 59, 0.7);
            border: 1px solid rgba(94, 234, 212, 0.3);
            transition: all 0.3s ease;
        }
        
        .back-btn:hover {
            background: rgba(30, 41, 59, 0.9);
            border-color: rgba(94, 234, 212, 0.6);
            box-shadow: 0 0 0 3px rgba(20, 184, 166, 0.3);
        }
        
        .success-message {
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .icon-float {
            animation: floatIcon 3s ease-in-out infinite;
        }
        
        @keyframes floatIcon {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }
    </style>
</head>

<body class="flex justify-center items-center min-h-screen p-4">
    <!-- Gradient Overlay -->
    <div class="gradient-overlay"></div>
    
    <!-- Animated Particles -->
    <div id="particles-container"></div>
    
    <div class="max-w-md w-full z-10">
        <!-- Forgot Password Card -->
        <div class="glass-card rounded-2xl p-8 space-y-6 relative overflow-hidden">
            <!-- Animated teal accent line at top -->
            <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-teal-500 to-transparent"></div>
            
            <!-- Header with NCSBAS branding -->
            <div class="flex flex-col items-center space-y-4">
                <div class="w-16 h-16 rounded-full bg-gradient-to-br from-teal-700 to-teal-900 flex items-center justify-center teal-glow mb-2 icon-float">
                    <i class="fas fa-key text-teal-300 text-2xl"></i>
                </div>
                <h1 class="text-3xl font-bold bg-gradient-to-r from-teal-400 via-teal-300 to-teal-200 bg-clip-text text-transparent ncsbas-text">NCSBAS</h1>
                <h2 class="text-2xl font-bold text-center text-slate-100">Reset Your Password</h2>
                <p class="text-slate-300 text-center text-sm">Enter your email address and we'll send you a link to reset your password</p>
            </div>

            <!-- Session Status and Errors -->
            <?php if(session('status')): ?>
                <div class="success-message p-4 rounded-xl bg-gradient-to-r from-teal-900/30 to-teal-800/20 border border-teal-700/30">
                    <div class="flex items-center text-teal-300">
                        <i class="fas fa-check-circle mr-3 text-xl"></i>
                        <span class="font-medium"><?php echo e(session('status')); ?></span>
                    </div>
                    <p class="text-sm text-teal-200 mt-2 ml-9">Check your email inbox for the password reset link.</p>
                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="p-4 rounded-xl bg-gradient-to-r from-rose-900/30 to-rose-800/20 border border-rose-700/30">
                    <div class="flex items-center text-rose-300">
                        <i class="fas fa-exclamation-triangle mr-3 text-xl"></i>
                        <div>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="text-sm"><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form method="POST" action="<?php echo e(route('password.email')); ?>" class="space-y-6">
                <?php echo csrf_field(); ?>
                
                <!-- Email Input -->
                <div class="relative group">
                    <input 
                        id="email" 
                        type="email" 
                        name="email" 
                        value="<?php echo e(old('email')); ?>" 
                        required 
                        autofocus
                        placeholder=" "
                        class="w-full px-5 py-4 rounded-xl input-field text-slate-200 placeholder-transparent focus:outline-none group-hover:border-teal-400 transition-all duration-300"
                    >
                    <label for="email" class="input-label absolute left-5 top-4 text-slate-300 pointer-events-none label-animation">
                        <i class="fas fa-envelope mr-2 text-teal-400"></i>Email Address
                    </label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="flex items-center mt-2 text-rose-400 text-sm">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <span><?php echo e($message); ?></span>
                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Instructions -->
                <div class="p-4 rounded-xl bg-gradient-to-r from-slate-800/30 to-slate-700/20 border border-slate-700/30">
                    <div class="flex items-start">
                        <i class="fas fa-info-circle text-teal-400 mt-1 mr-3"></i>
                        <div>
                            <p class="text-sm text-slate-300">
                                You will receive a password reset link at the email address you provide. 
                                The link will expire in 60 minutes.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full py-4 text-slate-100 font-semibold rounded-xl teal-gradient-btn text-lg">
                    <i class="fas fa-paper-plane mr-2"></i>Send Reset Link
                </button>
            </form>

            <!-- Back to Login -->
            <div class="text-center pt-4">
                <a href="<?php echo e(route('login')); ?>" class="inline-flex items-center text-sm teal-link hover:text-teal-300 transition-colors duration-300">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Login
                </a>
            </div>
            
            <!-- Status indicator -->
            <div class="flex items-center justify-center pt-4 border-t border-slate-800/50">
                <div class="pulse-dot mr-2"></div>
                <span class="text-xs text-teal-300">Secure password reset process</span>
            </div>
        </div>
        
        <!-- Footer note -->
        <p class="text-center text-slate-400 text-sm mt-6">
            <i class="fas fa-lock mr-1 text-teal-400"></i> Powered by NCSBAS - Secure Authentication
        </p>
    </div>

    <script>
        // Create animated particles
        function createParticles() {
            const container = document.getElementById('particles-container');
            const particleCount = 25;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                // Random size
                const size = Math.random() * 80 + 15;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                
                // Random position
                particle.style.left = `${Math.random() * 100}vw`;
                particle.style.top = `${Math.random() * 100}vh`;
                
                // Random opacity
                particle.style.opacity = Math.random() * 0.1 + 0.05;
                
                // Random animation
                const duration = Math.random() * 20 + 10;
                const delay = Math.random() * 5;
                
                particle.style.animation = `
                    float ${duration}s ease-in-out ${delay}s infinite alternate
                `;
                
                container.appendChild(particle);
            }
            
            // Add CSS for floating animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes float {
                    0% {
                        transform: translate(0, 0) rotate(0deg);
                    }
                    33% {
                        transform: translate(${Math.random() * 80 - 40}px, ${Math.random() * 80 - 40}px) rotate(${Math.random() * 180}deg);
                    }
                    66% {
                        transform: translate(${Math.random() * 80 - 40}px, ${Math.random() * 80 - 40}px) rotate(${Math.random() * 180}deg);
                    }
                    100% {
                        transform: translate(0, 0) rotate(0deg);
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        // Form interaction enhancements
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            
            const inputs = document.querySelectorAll('.input-field');
            
            inputs.forEach(input => {
                // Add floating label effect on page load if input has value
                if (input.value) {
                    input.nextElementSibling.classList.add('transformed');
                }
                
                // Add focus/blur effects
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('teal-glow');
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('teal-glow');
                });
            });
            
            // Form submission animation
            const form = document.querySelector('form');
            form.addEventListener('submit', function(e) {
                const btn = this.querySelector('button[type="submit"]');
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
                btn.disabled = true;
                btn.classList.add('opacity-90');
                
                // Re-enable button after 5 seconds in case of error
                setTimeout(() => {
                    btn.innerHTML = originalHTML;
                    btn.disabled = false;
                    btn.classList.remove('opacity-90');
                }, 5000);
            });
            
            // Auto focus email input if it has error
            const emailInput = document.getElementById('email');
            if (emailInput && emailInput.classList.contains('border-rose-500')) {
                emailInput.focus();
            }
        });
        
        // Auto-hide success message after 10 seconds
        setTimeout(() => {
            const successMsg = document.querySelector('.success-message');
            if (successMsg) {
                successMsg.style.opacity = '0';
                successMsg.style.transform = 'translateY(-10px)';
                setTimeout(() => {
                    successMsg.style.display = 'none';
                }, 500);
            }
        }, 10000);
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>