<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NCSBAS | National Cyber Security Baseline Assessment System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Your Custom Welcome CSS -->
    <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">
</head>


<body class="overflow-x-hidden">
    <!-- Digital circuit pattern -->
    <div class="circuit-overlay"></div>
    
    <!-- Data flow animation -->
    <div id="data-flow-container" class="data-flow"></div>
    
    <!-- Navigation -->
    <nav class="fixed w-full z-50 px-6 py-4 glass-card">
        <div class="max-w-7xl mx-auto">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center security-glow">
                        <i class="fas fa-shield-alt text-teal-300"></i>
                    </div>
                    <div>
                        <h1 class="text-xl font-bold ncsbas-full">NCSBAS</h1>
                        <p class="text-xs text-teal-300">National Cyber Security Baseline Assessment</p>
                    </div>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="#about" class="text-slate-300 hover:text-teal-300 transition-colors duration-300 font-medium">About</a>
                    <a href="#features" class="text-slate-300 hover:text-teal-300 transition-colors duration-300 font-medium">Features</a>
                    <a href="#framework" class="text-slate-300 hover:text-teal-300 transition-colors duration-300 font-medium">Framework</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="<?php echo e(route('login')); ?>" class="text-teal-300 hover:text-teal-200 transition-colors duration-300 font-medium">Sign In</a>
                    <a href="<?php echo e(route('register')); ?>" class="px-6 py-2 rounded-full cyber-gradient-btn text-slate-100 font-semibold transition-all duration-300">Start Assessment</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="min-h-screen flex items-center justify-center px-6 pt-20">
        <div class="max-w-7xl mx-auto">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                    <div class="inline-flex items-center px-4 py-2 rounded-full bg-teal-900/30 border border-teal-800/50 mb-6">
                        <span class="w-2 h-2 rounded-full bg-teal-400 mr-2 animate-pulse"></span>
                        <span class="text-teal-300 text-sm">Official Malaysia NCSB Framework</span>
                    </div>
                    
                    <h1 class="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                        <span class="text-slate-100">National Cyber Security</span><br>
                        <span class="ncsbas-full text-6xl md:text-7xl">Baseline Assessment System</span>
                    </h1>
                    
                    <p class="text-xl text-slate-300 mb-8 leading-relaxed">
                        Transform your organization's cybersecurity assessment with Malaysia's official automated National Cyber Security Baseline (NCSB) framework. Replace manual Excel processes with intelligent, real-time assessment and compliance tracking.
                    </p>
                    
                    <div class="flex flex-col sm:flex-row gap-6 mb-12">
                        <a href="<?php echo e(route('register')); ?>" class="px-8 py-4 rounded-xl cyber-gradient-btn text-slate-100 font-semibold text-lg transition-all duration-300 text-center">
                            <i class="fas fa-play-circle mr-2"></i>Start Assessment
                        </a>
                    </div>
                    
                    <!-- Stats -->
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
                        <div class="text-center">
                            <div class="text-3xl font-bold text-teal-400 mb-1" ></div>
                            <div class="text-sm text-slate-400"></div>
                        </div>
                        <div class="text-center">
                            <div class="text-3xl font-bold text-teal-400 mb-1" ></div>
                            <div class="text-sm text-slate-400"></div>
                        </div>
                        <div class="text-center">
                            <div class="text-3xl font-bold text-teal-400 mb-1"></div>
                            <div class="text-sm text-slate-400"></div>
                        </div>
                        <div class="text-center">
                            <div class="text-3xl font-bold text-teal-400 mb-1"></div>
                            <div class="text-sm text-slate-400"></div>
                        </div>
                    </div>
                </div>
                
                <div class="relative">
                    <div class="glass-card rounded-2xl p-8 h-full flex flex-col justify-center">
                        <div class="text-center mb-6">
                            <div class="w-20 h-20 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center security-glow mx-auto mb-4">
                                <i class="fas fa-shield-alt text-teal-300 text-3xl"></i>
                            </div>
                            <h3 class="text-2xl font-bold text-slate-100 mb-2">Key Benefits</h3>
                            <p class="text-slate-400">Experience the advantages of automated assessment</p>
                        </div>
                        
                        <div class="space-y-4">
                            <div class="flex items-center p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                                    <i class="fas fa-bolt text-teal-400"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-slate-100">Faster Assessment</h4>
                                    <p class="text-sm text-slate-400">Reduce assessment time significantly</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                                    <i class="fas fa-chart-line text-teal-400"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-slate-100">Real-Time Insights</h4>
                                    <p class="text-sm text-slate-400">Instant maturity scoring and analytics</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                                    <i class="fas fa-brain text-teal-400"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-slate-100">AI-Chatbot</h4>
                                    <p class="text-sm text-slate-400">Intelligent guide and insights</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                                    <i class="fas fa-lock text-teal-400"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-slate-100">Secure & Compliant</h4>
                                    <p class="text-sm text-slate-400">Enterprise-grade security and compliance</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-8 pt-6 border-t border-slate-700">
                            <div class="flex items-center justify-center">
                                <div class="w-2 h-2 rounded-full bg-teal-400 animate-pulse mr-2"></div>
                                <span class="text-sm text-teal-300">Official NCSB Framework Implementation</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 px-6 bg-black/20">
        <div class="max-w-7xl mx-auto">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold mb-4 section-title">
                    <span class="text-slate-100">About</span> <span class="ncsbas-full">NCSBAS</span>
                </h2>
                <p class="text-xl text-slate-300 max-w-4xl mx-auto">
                    The National Cyber Security Baseline Assessment System revolutionizes how Malaysian organizations assess their cybersecurity posture using the official NCSB framework.
                </p>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                    <h3 class="text-3xl font-bold mb-6 text-slate-100">
                        Replacing Manual Processes with Intelligent Automation
                    </h3>
                    <p class="text-lg text-slate-300 mb-6 leading-relaxed">
                        Traditional cybersecurity assessments using Excel spreadsheets are error-prone, time-consuming, and lack real-time insights. NCSBAS automates the entire assessment process, providing accurate, consistent, and actionable cybersecurity maturity scores.
                    </p>
                    
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="w-8 h-8 rounded-full bg-teal-900/50 flex items-center justify-center mr-4 mt-1">
                                <i class="fas fa-check text-teal-400"></i>
                            </div>
                            <div>
                                <h4 class="text-xl font-semibold mb-2 text-slate-100">Official NCSB Framework</h4>
                                <p class="text-slate-400">Based on Malaysia's National Cyber Security Baseline standards</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="w-8 h-8 rounded-full bg-teal-900/50 flex items-center justify-center mr-4 mt-1">
                                <i class="fas fa-check text-teal-400"></i>
                            </div>
                            <div>
                                <h4 class="text-xl font-semibold mb-2 text-slate-100">Automated Assessment</h4>
                                <p class="text-slate-400">Upload Excel files for automated processing and scoring</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="relative">
                    <div class="glass-card rounded-xl p-8 h-full flex flex-col justify-center">
                        <div class="flex items-center mb-6">
                            <div class="w-12 h-12 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mr-4">
                                <i class="fas fa-cogs text-teal-300 text-xl"></i>
                            </div>
                            <div>
                                <h3 class="text-2xl font-bold text-slate-100">Modern Assessment Platform</h3>
                                <p class="text-teal-400">Advanced cybersecurity evaluation system</p>
                            </div>
                        </div>
                        
                        <div class="space-y-4 mb-8">
                            <div class="flex items-center justify-between p-4 rounded-lg bg-slate-800/40">
                                <div class="flex items-center">
                                    <i class="fas fa-times-circle text-rose-400 mr-3"></i>
                                    <span class="text-slate-300">Excel Methods</span>
                                </div>
                                <div class="text-rose-400 font-semibold">Inefficient</div>
                            </div>
                            
                            <div class="flex items-center justify-between p-4 rounded-lg bg-slate-800/40">
                                <div class="flex items-center">
                                    <i class="fas fa-check-circle text-teal-400 mr-3"></i>
                                    <span class="text-slate-300">NCSBAS Automation</span>
                                </div>
                                <div class="text-teal-400 font-semibold">Highly Efficient</div>
                            </div>
                        </div>
                        
                        <div class="text-center">
                            <div class="inline-flex items-center px-4 py-2 rounded-full bg-teal-900/30 border border-teal-800/50">
                                <i class="fas fa-chart-bar text-teal-300 mr-2"></i>
                                <span class="text-teal-300">Advanced analytics and reporting</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-20 px-6">
        <div class="max-w-7xl mx-auto">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold mb-4 section-title">
                    <span class="text-slate-100">System</span> <span class="ncsbas-full">Features</span>
                </h2>
                <p class="text-xl text-slate-300 max-w-4xl mx-auto">
                    Comprehensive cybersecurity assessment tools designed for Malaysian organizations
                </p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Feature 1 -->
                <div class="feature-card glass-card rounded-xl p-8">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mb-6 security-glow">
                        <i class="fas fa-upload text-teal-300 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 text-slate-100">Automated Excel Processing</h3>
                    <p class="text-slate-400 mb-4">
                        Upload existing NCSB Excel files. Our system automatically extracts data, calculates maturity scores, and generates comprehensive reports.
                    </p>
                    <div class="text-teal-400 text-sm">
                        <i class="fas fa-microchip mr-2"></i>AI-Powered Data Extraction
                    </div>
                </div>
                
                <!-- Feature 2 -->
                <div class="feature-card glass-card rounded-xl p-8">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mb-6 security-glow">
                        <i class="fas fa-brain text-teal-300 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 text-slate-100">AI Chatbot Assistant</h3>
                    <p class="text-slate-400 mb-4">
                        Ask our AI chatbot about how the system works and get detailed explanations of NCSB framework requirements, controls, and implementation guidelines.
                    </p>
                    <div class="text-teal-400 text-sm">
                        <i class="fas fa-robot mr-2"></i>Machine Learning Insights
                    </div>
                </div>
                
                <!-- Feature 3 -->
                <div class="feature-card glass-card rounded-xl p-8">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mb-6 security-glow">
                        <i class="fas fa-tachometer-alt text-teal-300 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 text-slate-100">Interactive Dashboards</h3>
                    <p class="text-slate-400 mb-4">
                        Visualize your cybersecurity maturity with interactive radar charts, progress tracking, and real-time compliance monitoring.
                    </p>
                    <div class="text-teal-400 text-sm">
                        <i class="fas fa-chart-line mr-2"></i>Real-Time Analytics
                    </div>
                </div>
                
                <!-- Feature 4 -->
                <div class="feature-card glass-card rounded-xl p-8">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mb-6 security-glow">
                        <i class="fas fa-user-shield text-teal-300 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 text-slate-100">Role-Based Access Control</h3>
                    <p class="text-slate-400 mb-4">
                        Secure multi-user system with Admin, Assessor, and Reviewer roles to ensure proper access control and data security.
                    </p>
                    <div class="text-teal-400 text-sm">
                        <i class="fas fa-lock mr-2"></i>Enterprise Security
                    </div>
                </div>
                
                <!-- Feature 5 -->
                <div class="feature-card glass-card rounded-xl p-8">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mb-6 security-glow">
                        <i class="fas fa-file-contract text-teal-300 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 text-slate-100">Compliance Reporting</h3>
                    <p class="text-slate-400 mb-4">
                        Generate comprehensive compliance reports for regulatory requirements and executive presentations with export capabilities.
                    </p>
                    <div class="text-teal-400 text-sm">
                        <i class="fas fa-download mr-2"></i>PDF/Excel Export
                    </div>
                </div>
                
                <!-- Feature 6 -->
                <div class="feature-card glass-card rounded-xl p-8">
                    <div class="w-14 h-14 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center mb-6 security-glow">
                        <i class="fas fa-history text-teal-300 text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold mb-4 text-slate-100">Progress Tracking</h3>
                    <p class="text-slate-400 mb-4">
                        Monitor your cybersecurity maturity improvement over time with historical data comparison and trend analysis.
                    </p>
                    <div class="text-teal-400 text-sm">
                        <i class="fas fa-chart-bar mr-2"></i>Historical Analytics
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Framework Section -->
    <section id="framework" class="py-20 px-6 bg-black/20">
        <div class="max-w-7xl mx-auto">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold mb-4 section-title">
                    <span class="text-slate-100">NCSB</span> <span class="ncsbas-full">Framework</span>
                </h2>
                <p class="text-xl text-slate-300 max-w-4xl mx-auto">
                    Based on Malaysia's official National Cyber Security Baseline framework
                </p>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
    <div class="glass-card rounded-xl p-8">
        <h3 class="text-2xl font-bold mb-6 text-slate-100 text-center">Framework Domains</h3>
        
        <div class="space-y-6">
            <div class="flex items-start p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                    <span class="text-teal-400 font-bold">1</span>
                </div>
                <div>
                    <h4 class="text-xl font-semibold mb-2 text-slate-100">Govern</h4>
                    <p class="text-slate-400">Cybersecurity governance, policies, risk management, and organizational oversight</p>
                </div>
            </div>
            
            <div class="flex items-start p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                    <span class="text-teal-400 font-bold">2</span>
                </div>
                <div>
                    <h4 class="text-xl font-semibold mb-2 text-slate-100">Protect</h4>
                    <p class="text-slate-400">Access control, data security, awareness training, and protective technology</p>
                </div>
            </div>
            
            <div class="flex items-start p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                    <span class="text-teal-400 font-bold">3</span>
                </div>
                <div>
                    <h4 class="text-xl font-semibold mb-2 text-slate-100">Identify</h4>
                    <p class="text-slate-400">Asset management, business environment, governance, risk assessment, and strategy</p>
                </div>
            </div>
            
            <div class="flex items-start p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                    <span class="text-teal-400 font-bold">4</span>
                </div>
                <div>
                    <h4 class="text-xl font-semibold mb-2 text-slate-100">Detect</h4>
                    <p class="text-slate-400">Anomalies and events, security continuous monitoring, and detection processes</p>
                </div>
            </div>
            
            <div class="flex items-start p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                    <span class="text-teal-400 font-bold">5</span>
                </div>
                <div>
                    <h4 class="text-xl font-semibold mb-2 text-slate-100">Respond</h4>
                    <p class="text-slate-400">Response planning, communications, analysis, mitigation, and improvements</p>
                </div>
            </div>
            
            <div class="flex items-start p-4 rounded-lg bg-slate-800/40 hover:bg-slate-800/60 transition-colors duration-300">
                <div class="w-10 h-10 rounded-full bg-teal-900/50 flex items-center justify-center mr-4">
                    <span class="text-teal-400 font-bold">6</span>
                </div>
                <div>
                    <h4 class="text-xl font-semibold mb-2 text-slate-100">Recover</h4>
                    <p class="text-slate-400">Recovery planning, improvements, and communications for restoration capabilities</p>
                </div>
            </div>
        </div>
    </div>
                
                <div class="glass-card rounded-xl p-8">
                    <h3 class="text-2xl font-bold mb-6 text-slate-100 text-center">Maturity Levels</h3>
                    
                    <div class="space-y-6">
                        <div class="p-4 rounded-lg border-l-4 border-rose-500 bg-slate-800/40">
                            <div class="flex justify-between items-center mb-2">
                                <h4 class="text-lg font-semibold text-slate-100">Level 0</h4>
                                <span class="text-rose-400 font-bold">Initial</span>
                            </div>
                            <p class="text-slate-400"></p>
                        </div>
                        
                        <div class="p-4 rounded-lg border-l-4 border-amber-500 bg-slate-800/40">
                            <div class="flex justify-between items-center mb-2">
                                <h4 class="text-lg font-semibold text-slate-100">Level 1</h4>
                                <span class="text-amber-400 font-bold">Basic</span>
                            </div>
                            <p class="text-slate-400"></p>
                        </div>
                        
                        <div class="p-4 rounded-lg border-l-4 border-blue-500 bg-slate-800/40">
                            <div class="flex justify-between items-center mb-2">
                                <h4 class="text-lg font-semibold text-slate-100">Level 2</h4>
                                <span class="text-blue-400 font-bold">Intermediate</span>
                            </div>
                            <p class="text-slate-400"></p>
                        </div>
                        
                        <div class="p-4 rounded-lg border-l-4 border-emerald-500 bg-slate-800/40">
                            <div class="flex justify-between items-center mb-2">
                                <h4 class="text-lg font-semibold text-slate-100">Level 3</h4>
                                <span class="text-emerald-400 font-bold">Advanced</span>
                            </div>
                            <p class="text-slate-400"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 px-6">
        <div class="max-w-4xl mx-auto text-center">
            <div class="glass-card rounded-2xl p-12 relative overflow-hidden">
                <!-- Animated teal accent line at top -->
                <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-teal-500 to-transparent"></div>
                
                <div class="w-20 h-20 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center security-glow mx-auto mb-6">
                    <i class="fas fa-shield-alt text-teal-300 text-3xl"></i>
                </div>
                
                <h2 class="text-4xl font-bold mb-6 text-slate-100">
                    Ready to Transform Your Cybersecurity Assessment?
                </h2>
                <p class="text-xl text-slate-300 mb-10 max-w-2xl mx-auto">
                    Join Malaysian organizations that have modernized their cybersecurity assessment with NCSBAS. Start your automated assessment today.
                </p>
                
                <div class="flex flex-col md:flex-row gap-6 justify-center">
                    <a href="<?php echo e(route('register')); ?>" class="px-8 py-4 rounded-xl cyber-gradient-btn text-slate-100 font-semibold text-lg transition-all duration-300">
                        <i class="fas fa-rocket mr-2"></i>Start Assessment
                    </a>
                </div>
                
                <div class="mt-8 text-slate-400 text-sm">
                    <p><i class="fas fa-shield-alt mr-2 text-teal-400"></i>Official NCSB Framework • Enterprise Security • Government Compliant</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-12 px-6 border-t border-slate-800">
        <div class="max-w-7xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                    <div class="flex items-center space-x-3 mb-6">
                        <div class="w-10 h-10 rounded-full bg-gradient-to-br from-teal-800 to-teal-900 flex items-center justify-center">
                            <i class="fas fa-shield-alt text-teal-300"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold ncsbas-full">NCSBAS</h3>
                            <p class="text-sm text-slate-400">National Cyber Security Baseline Assessment System</p>
                        </div>
                    </div>
                    <p class="text-slate-400 text-sm">
                        Official automated assessment system for Malaysia's National Cyber Security Baseline framework.
                    </p>
                </div>
                
                <div>
                    <h4 class="text-lg font-semibold mb-6 text-slate-100">Quick Links</h4>
                    <div class="space-y-3">
                        <a href="<?php echo e(route('login')); ?>" class="block text-slate-400 hover:text-teal-300 transition-colors duration-300">Sign In</a>
                        <a href="<?php echo e(route('register')); ?>" class="block text-slate-400 hover:text-teal-300 transition-colors duration-300">Start Assessment</a>
                        <a href="#framework" class="block text-slate-400 hover:text-teal-300 transition-colors duration-300">NCSB Framework</a>
                        <a href="#features" class="block text-slate-400 hover:text-teal-300 transition-colors duration-300">System Features</a>
                    </div>
                </div>
            </div>
            
            <div class="mt-8 pt-8 border-t border-slate-800 text-center">
                <p class="text-slate-400 text-sm">
                    © 2024 National Cyber Security Baseline Assessment System. All rights reserved.<br>
                    <span class="text-xs">Official Government System • Secure • Compliant • Trusted</span>
                </p>
            </div>
        </div>
    </footer>

    <!-- Your Welcome Page JavaScript -->
    <script src="<?php echo e(asset('js/welcome.js')); ?>"></script>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\newNCSBAS\resources\views\welcome.blade.php ENDPATH**/ ?>