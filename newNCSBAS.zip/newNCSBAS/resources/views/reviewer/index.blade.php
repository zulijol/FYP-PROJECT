@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-0">Assessments for Review</h2>
            <p class="text-muted">Assessments that need review (Imported or In Review)</p>
        </div>
        <div class="col-auto">
            <div class="btn-group">
                <a href="{{ route('review.dashboard') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-dashboard me-1"></i>Dashboard
                </a>
                <a href="{{ route('review.reviewed') }}" class="btn btn-outline-success">
                    <i class="fas fa-check-circle me-1"></i>View Completed
                </a>
            </div>
        </div>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            @if($assessments->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Filename</th>
                                <th>Uploaded By</th>
                                <th>Upload Date</th>
                                <th>Questions</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($assessments as $assessment)
                            <tr>
                                <td>#{{ $assessment->id }}</td>
                                <td>
                                    <span class="d-inline-block text-truncate" style="max-width: 200px;" title="{{ $assessment->filename }}">
                                        {{ $assessment->filename }}
                                    </span>
                                </td>
                                <td>{{ $assessment->user->name ?? 'Unknown User' }}</td>
                                <td>{{ $assessment->uploaded_at->format('d M Y, H:i') }}</td>
                                <td>{{ $assessment->total_questions }}</td>
                                <td>
                                    @php
                                        $statusClass = [
                                            'imported' => 'secondary',
                                            'in_review' => 'warning',
                                            'completed' => 'success',
                                            'not_reviewed' => 'danger'
                                        ][$assessment->status] ?? 'secondary';
                                        
                                        $statusLabels = [
                                            'imported' => 'Imported',
                                            'in_review' => 'In Review',
                                            'completed' => 'Completed',
                                            'not_reviewed' => 'Not Reviewed'
                                        ];
                                    @endphp
                                    <span class="badge bg-{{ $statusClass }}">
                                        {{ $statusLabels[$assessment->status] ?? $assessment->status }}
                                    </span>
                                    
                                    @if($assessment->reviewed_at)
                                        <div class="small text-muted mt-1">
                                            {{ $assessment->reviewed_at->format('d M Y') }}
                                        </div>
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="{{ route('review.show', $assessment->id) }}" 
                                           class="btn btn-outline-primary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        @if($assessment->status == 'imported')
                                            <form action="{{ route('review.mark.reviewed', $assessment->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                <button type="submit" class="btn btn-outline-warning" title="Mark as In Review">
                                                    <i class="fas fa-play-circle"></i>
                                                </button>
                                            </form>
                                        @endif
                                        
                                        @if($assessment->status == 'in_review')
                                            <form action="{{ route('review.update.status', $assessment->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                <input type="hidden" name="status" value="completed">
                                                <button type="submit" class="btn btn-outline-success" title="Mark as Completed">
                                                    <i class="fas fa-check"></i>
                                                </button>
                                            </form>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                @if($assessments->hasPages())
                <div class="d-flex justify-content-center mt-4">
                    {{ $assessments->links() }}
                </div>
                @endif
            @else
                <div class="text-center py-5">
                    <div class="mb-3">
                        <i class="fas fa-check-circle fa-3x text-success"></i>
                    </div>
                    <h5 class="text-muted">All caught up!</h5>
                    <p class="text-muted">No assessments need review at the moment.</p>
                    <a href="{{ route('review.dashboard') }}" class="btn btn-primary mt-2">
                        <i class="fas fa-dashboard me-1"></i>Go to Dashboard
                    </a>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection