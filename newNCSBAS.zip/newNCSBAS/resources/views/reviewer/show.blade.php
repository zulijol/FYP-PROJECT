@extends('layouts.app')

@section('content')
<div class="container py-4">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ route('review.dashboard') }}">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="{{ route('review.assessments') }}">All Assessments</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Assessment #{{ $assessment->id }}</li>
                </ol>
            </nav>
            
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h2 class="mb-1">Assessment #{{ $assessment->id }}</h2>
                    <p class="text-muted mb-0">{{ $assessment->filename }}</p>
                    <p class="text-muted mb-0">
                        Uploaded by <strong>{{ $assessment->user->name ?? 'Unknown User' }}</strong> 
                        on {{ $assessment->uploaded_at->format('d M Y, H:i') }}
                    </p>
                </div>
                <a href="{{ route('review.assessments') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to List
                </a>
            </div>
        </div>
    </div>

    <!-- Success Message -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-primary">
                <div class="card-body text-center">
                    <h3 class="card-title display-6 text-primary">{{ $stats['total'] }}</h3>
                    <p class="card-text text-muted">Total Questions</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-success">{{ $stats['yes_count'] }}</h3>
                    <p class="text-muted mb-0">Yes ({{ $stats['yes_percentage'] }}%)</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-danger">{{ $stats['no_count'] }}</h3>
                    <p class="text-muted mb-0">No ({{ $stats['no_percentage'] }}%)</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-warning">{{ $stats['empty_count'] }}</h3>
                    <p class="text-muted mb-0">Empty ({{ $stats['empty_percentage'] }}%)</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Review Actions Card -->
    <div class="card mb-4">
        <div class="card-header">
            <h5 class="mb-0">Review Actions</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('review.update.status', $assessment->id) }}" method="POST">
                @csrf
                
                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label">Update Status</label>
                            <select name="status" class="form-select" required>
                                <option value="imported" {{ $assessment->status == 'imported' ? 'selected' : '' }}>Imported</option>
                                <option value="in_review" {{ $assessment->status == 'in_review' ? 'selected' : '' }}>In Review</option>
                                <option value="completed" {{ $assessment->status == 'completed' ? 'selected' : '' }}>Mark as Completed</option>
                                <option value="not_reviewed" {{ $assessment->status == 'not_reviewed' ? 'selected' : '' }}>Not Reviewed</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label class="form-label">Review Comments (Optional)</label>
                            <textarea name="comments" class="form-control" rows="2" 
                                      placeholder="Add any comments or feedback for the assessor...">{{ $assessment->notes ?? '' }}</textarea>
                            <small class="text-muted">Comments will be saved in the assessment notes.</small>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <div>
                        <a href="{{ route('review.assessments') }}" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i>Back to List
                        </a>
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i>Update Status
                        </button>
                        
                        @if($assessment->status == 'imported')
                            <button type="button" class="btn btn-warning" 
                                    onclick="document.querySelector('select[name=\"status\"]').value='in_review'; document.querySelector('form').submit();">
                                <i class="fas fa-play-circle me-1"></i>Start Review
                            </button>
                        @endif
                        
                        @if($assessment->status == 'in_review')
                            <button type="button" class="btn btn-success" 
                                    onclick="document.querySelector('select[name=\"status\"]').value='completed'; document.querySelector('form').submit();">
                                <i class="fas fa-check-circle me-1"></i>Mark as Completed
                            </button>
                        @endif
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Current Status Info -->
    <div class="alert 
        @if($assessment->status == 'imported') alert-secondary
        @elseif($assessment->status == 'in_review') alert-warning
        @elseif($assessment->status == 'completed') alert-success
        @elseif($assessment->status == 'not_reviewed') alert-danger
        @else alert-info @endif">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <strong>Current Status:</strong>
                @php
                    $statusClass = [
                        'imported' => 'secondary',
                        'in_review' => 'warning',
                        'completed' => 'success',
                        'not_reviewed' => 'danger'
                    ][$assessment->status] ?? 'secondary';
                    
                    $statusLabels = [
                        'imported' => 'Imported',
                        'in_review' => 'In Review',
                        'completed' => 'Completed',
                        'not_reviewed' => 'Not Reviewed'
                    ];
                @endphp
                <span class="badge bg-{{ $statusClass }} ms-2">
                    {{ $statusLabels[$assessment->status] ?? $assessment->status }}
                </span>
                
                @if($assessment->reviewed_at)
                    <div class="mt-1">
                        <i class="fas fa-calendar-check me-1"></i>
                        Reviewed on: {{ $assessment->reviewed_at->format('d M Y, H:i') }}
                        @if($assessment->reviewed_by)
                            by {{ $assessment->reviewed_by_user->name ?? 'Reviewer' }}
                        @endif
                    </div>
                @endif
            </div>
            
            @if($assessment->notes)
                <div>
                    <button class="btn btn-sm btn-outline-info" type="button" data-bs-toggle="collapse" data-bs-target="#notesCollapse">
                        <i class="fas fa-sticky-note me-1"></i>View Notes
                    </button>
                </div>
            @endif
        </div>
        
        @if($assessment->notes)
        <div class="collapse mt-3" id="notesCollapse">
            <div class="card card-body">
                <strong>Assessment Notes:</strong>
                <p class="mb-0">{{ $assessment->notes }}</p>
            </div>
        </div>
        @endif
    </div>

    <!-- Responses by Domain -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Questions & Responses</h5>
            <p class="text-muted mb-0">Organized by domain</p>
        </div>
        <div class="card-body">
            @if($responsesByDomain->count() > 0)
                @foreach($responsesByDomain as $domain => $responses)
                <div class="mb-5">
                    <h5 class="border-bottom pb-2 mb-3">
                        {{ $domain }}
                        <span class="badge bg-secondary ms-2">{{ $responses->count() }} questions</span>
                    </h5>
                    
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th width="60">#</th>
                                    <th>Category</th>
                                    <th>Element</th>
                                    <th>Question</th>
                                    <th width="100">Response</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($responses as $response)
                                <tr>
                                    <td class="text-muted">{{ $response->number }}</td>
                                    <td><small>{{ $response->category }}</small></td>
                                    <td><small>{{ $response->element }}</small></td>
                                    <td>
                                        <div class="fw-bold mb-1">{{ $response->question }}</div>
                                        @if($response->description)
                                            <small class="text-muted d-block">{{ $response->description }}</small>
                                        @endif
                                    </td>
                                    <td>
                                        @if($response->response === 'Yes')
                                            <span class="badge bg-success">Yes</span>
                                        @elseif($response->response === 'No')
                                            <span class="badge bg-danger">No</span>
                                        @elseif($response->response === 'N/A' || $response->response === 'NA')
                                            <span class="badge bg-secondary">N/A</span>
                                        @elseif(empty($response->response) || $response->response === null)
                                            <span class="badge bg-warning text-dark">Empty</span>
                                        @else
                                            <span class="badge bg-info">{{ $response->response }}</span>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                @endforeach
            @else
                <div class="text-center py-4">
                    <p class="text-muted">No responses found for this assessment.</p>
                </div>
            @endif
        </div>
        <div class="card-footer">
            <div class="d-flex justify-content-between align-items-center">
                <div class="text-muted small">
                    Assessment ID: #{{ $assessment->id }} | 
                    Questions: {{ $assessment->total_questions }} |
                    Uploaded: {{ $assessment->uploaded_at->format('d M Y') }}
                </div>
                <a href="{{ route('review.assessments') }}" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-1"></i>Back to All Assessments
                </a>
            </div>
        </div>
    </div>
</div>

<style>
    .table-sm td, .table-sm th {
        padding: 0.75rem 0.5rem;
    }
    .badge {
        font-size: 0.85em;
        padding: 0.35em 0.65em;
    }
    .alert {
        border-left: 4px solid;
    }
    .alert-secondary {
        border-left-color: #6c757d;
    }
    .alert-warning {
        border-left-color: #ffc107;
    }
    .alert-success {
        border-left-color: #198754;
    }
    .alert-danger {
        border-left-color: #dc3545;
    }
</style>
@endsection