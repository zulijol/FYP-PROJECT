@extends('layouts.app')

@section('title', 'Maturity Radar Charts')

@section('content')
<div class="container-fluid py-3">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h2 mb-1 text-white">
                <i class="fas fa-chart-radar text-teal me-2"></i>
                Maturity Radar Charts
            </h1>
            <p class="text-light mb-0">
                Assessment: {{ $assessment->filename }} • 
                Overall: <strong class="text-teal">{{ number_format($results['overall_maturity'], 2) }}/1.00</strong>
            </p>
        </div>
        
        <div class="btn-group">
            <a href="{{ route('assessment.show', $assessment->id) }}" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-1"></i> Back
            </a>
            <button onclick="exportCharts()" class="btn btn-outline-teal">
                <i class="fas fa-download me-1"></i> Export
            </button>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-teal h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-teal text-uppercase mb-1">
                                Overall Maturity
                            </div>
                            <div class="h4 mb-0 font-weight-bold text-white">
                                {{ number_format($results['overall_maturity'], 2) }}/1.00
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-chart-line fa-2x text-teal opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-success h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Elements Started
                            </div>
                            <div class="h4 mb-0 font-weight-bold text-white">
                                {{ $results['elements_started'] }}/{{ $results['total_elements'] }}
                            </div>
                            <div class="mt-2">
                                <div class="progress bg-dark" style="height: 4px;">
                                    <div class="progress-bar bg-success" style="width: {{ ($results['elements_started']/$results['total_elements'])*100 }}%"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-play-circle fa-2x text-success opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-info h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Best Domain
                            </div>
                            @php
                                $maxDomain = max($results['domains']['levels']);
                                $maxDomainName = array_search($maxDomain, $results['domains']['levels']);
                            @endphp
                            <div class="h4 mb-0 font-weight-bold text-white">
                                {{ number_format($maxDomain, 2) }}/3.00
                            </div>
                            <div class="mt-2 mb-0 text-light small">
                                <i class="fas fa-trophy me-1 text-teal"></i>
                                {{ $maxDomainName }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-trophy fa-2x text-info opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-warning h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Needs Focus
                            </div>
                            @php
                                $minDomain = min($results['domains']['levels']);
                                $minDomainName = array_search($minDomain, $results['domains']['levels']);
                            @endphp
                            <div class="h4 mb-0 font-weight-bold text-white">
                                {{ number_format($minDomain, 2) }}/3.00
                            </div>
                            <div class="mt-2 mb-0 text-light small">
                                <i class="fas fa-exclamation-triangle me-1 text-warning"></i>
                                {{ $minDomainName }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-exclamation-triangle fa-2x text-warning opacity-25"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Radar Charts Tabs -->
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs" id="radarTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active text-white" id="domain-tab" data-bs-toggle="tab" 
                            data-bs-target="#domain" type="button" role="tab">
                        <i class="fas fa-globe text-teal me-2"></i> Domain (6)
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link text-white" id="category-tab" data-bs-toggle="tab" 
                            data-bs-target="#category" type="button" role="tab">
                        <i class="fas fa-layer-group text-teal me-2"></i> Category ({{ count($radarData['category']['labels']) }})
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link text-white" id="element-tab" data-bs-toggle="tab" 
                            data-bs-target="#element" type="button" role="tab">
                        <i class="fas fa-cube text-teal me-2"></i> Element (33)
                    </button>
                </li>
            </ul>
        </div>
        <div class="card-body p-0">
            <div class="tab-content">
                <!-- Domain Radar -->
                <div class="tab-pane fade show active p-3" id="domain" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="chart-container" style="height: 450px;">
                                <canvas id="domainRadar"></canvas>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card border-teal bg-dark h-100">
                                <div class="card-header bg-transparent border-teal">
                                    <h6 class="mb-0 text-white">Domain Scores</h6>
                                </div>
                                <div class="card-body">
                                    @foreach($results['domains']['levels'] as $domain => $score)
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between mb-1">
                                            <span class="text-light small">{{ $domain }}</span>
                                            <span class="fw-bold text-teal">{{ number_format($score, 2) }}</span>
                                        </div>
                                        <div class="progress bg-dark" style="height: 6px;">
                                            <div class="progress-bar bg-teal" style="width: {{ ($score/3)*100 }}%"></div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Category Radar -->
                <div class="tab-pane fade p-3" id="category" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="chart-container" style="height: 450px;">
                                <canvas id="categoryRadar"></canvas>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card border-teal bg-dark h-100">
                                <div class="card-header bg-transparent border-teal">
                                    <h6 class="mb-0 text-white">Top Categories</h6>
                                </div>
                                <div class="card-body">
                                    @php
                                        $categories = $results['categories']['levels'];
                                        arsort($categories);
                                        $topCategories = array_slice($categories, 0, 8, true);
                                    @endphp
                                    @foreach($topCategories as $category => $score)
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between mb-1">
                                            <span class="text-truncate text-light small" title="{{ $category }}">
                                                {{ Str::limit($category, 20) }}
                                            </span>
                                            <span class="fw-bold text-teal">{{ number_format($score, 1) }}</span>
                                        </div>
                                        <div class="progress bg-dark" style="height: 4px;">
                                            <div class="progress-bar bg-teal" style="width: {{ ($score/3)*100 }}%"></div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Element Radar -->
                <div class="tab-pane fade p-3" id="element" role="tabpanel">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="chart-container" style="height: 450px;">
                                <canvas id="elementRadar"></canvas>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card border-teal bg-dark h-100">
                                <div class="card-header bg-transparent border-teal">
                                    <h6 class="mb-0 text-white">Element Analysis</h6>
                                </div>
                                <div class="card-body">
                                    @php
                                        $levels = [0 => 0, 1 => 0, 2 => 0, 3 => 0];
                                        foreach($results['elements']['levels'] as $level) {
                                            $levels[$level]++;
                                        }
                                    @endphp
                                    
                                    <div class="mb-3">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-success text-dark me-2">Level 3</span>
                                            <span class="text-light small">Advanced: {{ $levels[3] }}</span>
                                            <span class="ms-auto text-teal">{{ number_format(($levels[3]/33)*100, 1) }}%</span>
                                        </div>
                                        <div class="progress bg-dark" style="height: 4px;">
                                            <div class="progress-bar bg-success" style="width: {{ ($levels[3]/33)*100 }}%"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-info text-dark me-2">Level 2</span>
                                            <span class="text-light small">Intermediate: {{ $levels[2] }}</span>
                                            <span class="ms-auto text-teal">{{ number_format(($levels[2]/33)*100, 1) }}%</span>
                                        </div>
                                        <div class="progress bg-dark" style="height: 4px;">
                                            <div class="progress-bar bg-info" style="width: {{ ($levels[2]/33)*100 }}%"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-warning text-dark me-2">Level 1</span>
                                            <span class="text-light small">Basic: {{ $levels[1] }}</span>
                                            <span class="ms-auto text-teal">{{ number_format(($levels[1]/33)*100, 1) }}%</span>
                                        </div>
                                        <div class="progress bg-dark" style="height: 4px;">
                                            <div class="progress-bar bg-warning" style="width: {{ ($levels[1]/33)*100 }}%"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="d-flex align-items-center mb-2">
                                            <span class="badge bg-danger me-2">Level 0</span>
                                            <span class="text-light small">Initial: {{ $levels[0] }}</span>
                                            <span class="ms-auto text-teal">{{ number_format(($levels[0]/33)*100, 1) }}%</span>
                                        </div>
                                        <div class="progress bg-dark" style="height: 4px;">
                                            <div class="progress-bar bg-danger" style="width: {{ ($levels[0]/33)*100 }}%"></div>
                                        </div>
                                    </div>
                                    
                                    <hr class="border-secondary my-3">
                                    
                                    <h6 class="text-white mb-2">Element Details</h6>
                                    <div id="elementDetails" class="small text-light">
                                        <p class="text-muted mb-0">Click any point on the radar to view element details</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart Legend -->
    <div class="row mt-3">
        <div class="col-12">
            <div class="card border-teal">
                <div class="card-header bg-transparent border-teal">
                    <h6 class="mb-0 text-white">Maturity Level Legend</h6>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-3 mb-2 mb-md-0">
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="color-box bg-success me-2"></div>
                                <span class="text-light">Level 3: Advanced (2.5-3.0)</span>
                            </div>
                        </div>
                        <div class="col-md-3 mb-2 mb-md-0">
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="color-box bg-info me-2"></div>
                                <span class="text-light">Level 2: Intermediate (1.5-2.4)</span>
                            </div>
                        </div>
                        <div class="col-md-3 mb-2 mb-md-0">
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="color-box bg-warning me-2"></div>
                                <span class="text-light">Level 1: Basic (0.5-1.4)</span>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="d-flex align-items-center justify-content-center">
                                <div class="color-box bg-danger me-2"></div>
                                <span class="text-light">Level 0: Initial (0-0.4)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

@push('scripts')
<script>
// Colors for black & teal theme
const themeColors = {
    teal: '#20c997',
    tealDark: '#198754',
    dark: '#212529',
    darker: '#121416',
    lightText: '#e9ecef',
    borderColor: '#343a40',
    cardBg: '#2c3034'
};

// Get point color based on value
const getPointColor = (value) => {
    if (value >= 2.5) return '#20c997'; // Teal - Level 3
    if (value >= 1.5) return '#17a2b8'; // Info - Level 2
    if (value >= 0.5) return '#ffc107'; // Warning - Level 1
    return '#dc3545'; // Danger - Level 0
};

// Domain Radar - Scale 0-3
const domainCtx = document.getElementById('domainRadar').getContext('2d');
const domainChart = new Chart(domainCtx, {
    type: 'radar',
    data: {
        labels: @json($radarData['domain']['labels']),
        datasets: [{
            label: 'Domain Maturity',
            data: @json($radarData['domain']['data']),
            backgroundColor: 'rgba(32, 201, 151, 0.2)',
            borderColor: themeColors.teal,
            borderWidth: 2,
            pointBackgroundColor: (ctx) => getPointColor(ctx.dataset.data[ctx.dataIndex]),
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverRadius: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            r: {
                min: 0,
                max: 3,
                ticks: {
                    stepSize: 1,
                    color: themeColors.lightText,
                    backdropColor: 'transparent',
                    callback: (value) => {
                        if (value === 0) return 'Level 0';
                        if (value === 1) return 'Level 1';
                        if (value === 2) return 'Level 2';
                        if (value === 3) return 'Level 3';
                        return '';
                    }
                },
                angleLines: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                pointLabels: {
                    color: themeColors.lightText,
                    font: {
                        size: 12
                    }
                }
            }
        },
        plugins: {
            legend: { 
                display: false 
            },
            tooltip: {
                backgroundColor: themeColors.cardBg,
                titleColor: themeColors.teal,
                bodyColor: themeColors.lightText,
                borderColor: themeColors.teal,
                borderWidth: 1,
                callbacks: {
                    label: (ctx) => `${ctx.label}: ${ctx.raw.toFixed(2)}/3.00`
                }
            }
        }
    }
});

// Category Radar - Scale 0-3
const categoryCtx = document.getElementById('categoryRadar').getContext('2d');
const categoryChart = new Chart(categoryCtx, {
    type: 'radar',
    data: {
        labels: @json($radarData['category']['labels']).map(label => 
            label.length > 25 ? label.substring(0, 22) + '...' : label
        ),
        datasets: [{
            label: 'Category Maturity',
            data: @json($radarData['category']['data']),
            backgroundColor: 'rgba(23, 162, 184, 0.2)',
            borderColor: '#17a2b8',
            borderWidth: 2,
            pointBackgroundColor: (ctx) => getPointColor(ctx.dataset.data[ctx.dataIndex]),
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 7
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            r: {
                min: 0,
                max: 3,
                ticks: {
                    stepSize: 1,
                    display: false
                },
                angleLines: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                pointLabels: {
                    color: themeColors.lightText,
                    font: { 
                        size: 10 
                    }
                }
            }
        },
        plugins: {
            legend: { 
                display: false 
            },
            tooltip: {
                backgroundColor: themeColors.cardBg,
                titleColor: '#17a2b8',
                bodyColor: themeColors.lightText,
                borderColor: '#17a2b8',
                borderWidth: 1,
                callbacks: {
                    label: (ctx) => {
                        const fullLabel = @json($radarData['category']['labels'])[ctx.dataIndex];
                        return `${fullLabel}: ${ctx.raw.toFixed(2)}/3.00`;
                    }
                }
            }
        }
    }
});

// Element Radar - Scale 0-3
const elementCtx = document.getElementById('elementRadar').getContext('2d');
const elementChart = new Chart(elementCtx, {
    type: 'radar',
    data: {
        labels: @json($radarData['element']['labels']).map(label => 
            label.length > 20 ? label.substring(0, 17) + '...' : label
        ),
        datasets: [{
            label: 'Element Maturity',
            data: @json($radarData['element']['data']),
            backgroundColor: 'rgba(255, 193, 7, 0.2)',
            borderColor: '#ffc107',
            borderWidth: 1,
            pointBackgroundColor: (ctx) => getPointColor(ctx.dataset.data[ctx.dataIndex]),
            pointBorderColor: '#fff',
            pointBorderWidth: 1,
            pointRadius: 3,
            pointHoverRadius: 6
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            r: {
                min: 0,
                max: 3,
                ticks: {
                    stepSize: 1,
                    display: false
                },
                angleLines: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                pointLabels: {
                    color: themeColors.lightText,
                    font: { 
                        size: 9 
                    }
                }
            }
        },
        plugins: {
            legend: { 
                display: false 
            },
            tooltip: {
                backgroundColor: themeColors.cardBg,
                titleColor: '#ffc107',
                bodyColor: themeColors.lightText,
                borderColor: '#ffc107',
                borderWidth: 1,
                callbacks: {
                    label: (ctx) => `${ctx.label}: ${ctx.raw.toFixed(2)}/3.00`
                }
            }
        },
        onClick: (evt, elements) => {
            if (elements.length > 0) {
                const idx = elements[0].index;
                const elementName = @json($radarData['element']['labels'])[idx];
                const elementData = @json($results['elements']['details'])[elementName];
                
                if (elementData) {
                    const level = elementData.level;
                    let levelName = 'Initial';
                    if (level >= 2.5) levelName = 'Advanced';
                    else if (level >= 1.5) levelName = 'Intermediate';
                    else if (level >= 0.5) levelName = 'Basic';
                    
                    const details = `
                        <div class="p-2">
                            <h6 class="text-teal mb-2">${elementName}</h6>
                            <div class="mb-2">
                                <span class="badge bg-${level >= 2.5 ? 'success' : level >= 1.5 ? 'info' : level >= 0.5 ? 'warning' : 'danger'} text-dark me-2">
                                    Level ${Math.floor(level)}
                                </span>
                                <span class="text-light">${levelName}</span>
                            </div>
                            <div class="mb-2">
                                <small class="text-muted">Score:</small>
                                <div class="text-white">${level.toFixed(2)}/3.00</div>
                            </div>
                            <div class="mb-2">
                                <small class="text-muted">YES Responses:</small>
                                <div class="text-white">${elementData.yes_count}/${elementData.max_possible_yes}</div>
                            </div>
                            <div>
                                <small class="text-muted">Status:</small>
                                <div>${elementData.yes_count >= 1 ? 
                                    '<span class="text-success"><i class="fas fa-check-circle me-1"></i> Started</span>' : 
                                    '<span class="text-danger"><i class="fas fa-times-circle me-1"></i> Not Started</span>'}
                                </div>
                            </div>
                        </div>
                    `;
                    document.getElementById('elementDetails').innerHTML = details;
                }
            }
        }
    }
});

// Export charts
function exportCharts() {
    const domainImg = domainChart.toBase64Image();
    const categoryImg = categoryChart.toBase64Image();
    const elementImg = elementChart.toBase64Image();
    
    const win = window.open('', '_blank');
    win.document.write(`
        <html><head><title>Radar Charts Export</title>
        <style>
            body { background: #121416; color: #e9ecef; padding: 20px; text-align: center; font-family: 'Segoe UI', sans-serif; }
            img { max-width: 800px; border: 1px solid #343a40; border-radius: 8px; margin: 10px 0; }
            .header { background: #2c3034; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #20c997; }
            .chart-container { margin: 30px 0; }
        </style></head>
        <body>
            <div class="header">
                <h2>Maturity Radar Charts</h2>
                <p>Assessment: {{ $assessment->filename }}</p>
                <p>Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}</p>
            </div>
            
            <div class="chart-container">
                <h3>Domain Radar</h3>
                <img src="${domainImg}">
            </div>
            
            <div class="chart-container">
                <h3>Category Radar</h3>
                <img src="${categoryImg}">
            </div>
            
            <div class="chart-container">
                <h3>Element Radar</h3>
                <img src="${elementImg}">
            </div>
            
            <script>window.print()<\/script>
        </body></html>
    `);
    win.document.close();
}
</script>
@endpush

<style>
:root {
    --teal: #20c997;
    --teal-dark: #198754;
    --dark: #212529;
    --darker: #121416;
    --light-text: #e9ecef;
    --border-color: #343a40;
    --card-bg: #2c3034;
}

body {
    background-color: var(--darker);
}

/* Card Styling */
.card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    margin-bottom: 1.5rem;
}

.card-header {
    background: rgba(33, 37, 41, 0.9);
    border-bottom: 1px solid var(--border-color);
}

.border-left-teal {
    border-left: 0.25rem solid var(--teal) !important;
}

.border-left-success {
    border-left: 0.25rem solid #1cc88a !important;
}

.border-left-info {
    border-left: 0.25rem solid #17a2b8 !important;
}

.border-left-warning {
    border-left: 0.25rem solid #ffc107 !important;
}

.border-teal {
    border-color: var(--teal) !important;
}

/* Nav Tabs */
.nav-tabs .nav-link {
    color: rgba(255, 255, 255, 0.8);
    border: none;
    border-bottom: 3px solid transparent;
    padding: 0.75rem 1rem;
    font-weight: 500;
}

.nav-tabs .nav-link.active {
    color: var(--teal);
    background: transparent;
    border-bottom: 3px solid var(--teal);
}

.nav-tabs .nav-link:hover {
    color: white;
    background: rgba(32, 201, 151, 0.1);
}

/* Chart Container */
.chart-container {
    position: relative;
    width: 100%;
}

/* Color Box */
.color-box {
    width: 20px;
    height: 20px;
    border-radius: 4px;
    border: 1px solid rgba(255, 255, 255, 0.1);
}

/* Progress Bar */
.progress {
    background-color: rgba(255, 255, 255, 0.05);
    border-radius: 3px;
}

.progress-bar {
    border-radius: 3px;
}

.bg-teal {
    background-color: var(--teal) !important;
}

/* Text Colors */
.text-teal {
    color: var(--teal) !important;
}

.text-white {
    color: white !important;
}

.text-light {
    color: var(--light-text) !important;
}

/* Badge Styling */
.badge {
    font-weight: 600;
    padding: 0.25em 0.6em;
    border-radius: 4px;
    font-size: 0.75rem;
}

.bg-success {
    background-color: #20c997 !important;
    color: var(--dark) !important;
}

.bg-info {
    background-color: #17a2b8 !important;
    color: var(--dark) !important;
}

.bg-warning {
    background-color: #ffc107 !important;
    color: var(--dark) !important;
}

.bg-danger {
    background-color: #dc3545 !important;
    color: white !important;
}

/* Button Styling */
.btn-outline-light {
    color: rgba(255, 255, 255, 0.8);
    border-color: rgba(255, 255, 255, 0.3);
}

.btn-outline-light:hover {
    background: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.5);
    color: white;
}

.btn-outline-teal {
    color: var(--teal);
    border-color: var(--teal);
}

.btn-outline-teal:hover {
    background: var(--teal);
    color: var(--dark);
    border-color: var(--teal);
}

/* Responsive */
@media (max-width: 768px) {
    .chart-container {
        height: 300px !important;
    }
    
    .card-body {
        padding: 1rem !important;
    }
    
    .col-lg-4, .col-lg-8 {
        padding-left: 0.5rem;
        padding-right: 0.5rem;
    }
}
</style>
@endsection