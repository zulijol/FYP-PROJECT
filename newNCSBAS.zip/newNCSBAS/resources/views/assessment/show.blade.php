@extends('layouts.app')

@section('title', 'Assessment Details')

@section('content')
<div class="container-fluid py-3">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-white">
                <i class="fas fa-file-alt text-teal me-2"></i>
                Assessment: {{ $assessment->filename }}
            </h1>
            <p class="text-light mb-0">
                <i class="fas fa-calendar-alt text-teal me-1"></i>
                Uploaded: {{ $assessment->uploaded_at->format('F d, Y H:i') }}
                • <i class="fas fa-question-circle text-teal me-1 ms-2"></i>{{ $assessment->total_questions }} questions
                @if($assessment->calculated_at)
                    • <i class="fas fa-calculator text-teal me-1 ms-2"></i>
                    Maturity calculated: {{ $assessment->calculated_at->format('M d, H:i') }}
                @endif
            </p>
        </div>
        
        <div class="btn-group">
            <a href="{{ route('assessment.list') }}" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-1"></i> Back to List
            </a>
            <a href="{{ route('assessment.download.pdf', $assessment->id) }}" class="btn btn-outline-teal">
                <i class="fas fa-file-pdf me-1"></i> Download PDF Report
            </a>
            @if($assessment->maturity_results)
            <a href="{{ route('assessment.view.pdf', $assessment->id) }}" class="btn btn-outline-success" target="_blank">
                <i class="fas fa-eye me-1"></i> View Report
            </a>
            @endif
        </div>
    </div>

    <!-- Quick Stats Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-teal h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-teal text-uppercase mb-1">
                                Total Questions
                            </div>
                            <div class="h4 mb-0 font-weight-bold text-white">{{ $stats['total'] }}</div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-teal">
                                <i class="fas fa-question-circle text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-success h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Yes Responses
                            </div>
                            <div class="h4 mb-0 font-weight-bold text-white">{{ $stats['yes_count'] }}</div>
                            <div class="mt-2">
                                <div class="progress bg-dark" style="height: 4px;">
                                    <div class="progress-bar bg-success" style="width: {{ $stats['yes_percentage'] }}%"></div>
                                </div>
                                <small class="text-light">{{ $stats['yes_percentage'] }}% of total</small>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-success">
                                <i class="fas fa-check-circle text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-danger h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                No Responses
                            </div>
                            <div class="h4 mb-0 font-weight-bold text-white">{{ $stats['no_count'] }}</div>
                            <div class="mt-2">
                                <div class="progress bg-dark" style="height: 4px;">
                                    <div class="progress-bar bg-danger" style="width: {{ $stats['no_percentage'] }}%"></div>
                                </div>
                                <small class="text-light">{{ $stats['no_percentage'] }}% of total</small>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-danger">
                                <i class="fas fa-times-circle text-white"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card border-left-warning h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Not Answered
                            </div>
                            <div class="h4 mb-0 font-weight-bold text-white">{{ $stats['empty_count'] }}</div>
                            <div class="mt-2">
                                <div class="progress bg-dark" style="height: 4px;">
                                    <div class="progress-bar bg-warning" style="width: {{ $stats['empty_percentage'] }}%"></div>
                                </div>
                                <small class="text-light">{{ $stats['empty_percentage'] }}% of total</small>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-warning">
                                <i class="fas fa-minus-circle text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Maturity Overview Section -->
    @if(isset($maturityResults))
    <div class="card mb-4 border-teal">
        <div class="card-header">
            <h5 class="card-title mb-0 text-white">
                <i class="fas fa-chart-line text-teal me-2"></i>
                Cybersecurity Maturity Overview
            </h5>
        </div>
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <div class="mb-4">
                        <h4 class="text-white mb-2">Overall Maturity Score</h4>
                        <div class="d-flex align-items-center mb-3">
                            <div class="progress flex-grow-1 me-3 bg-dark" style="height: 30px; border-radius: 15px;">
                                <div class="progress-bar" role="progressbar" 
                                     style="width: {{ $maturityResults['overall_maturity'] * 100 }}%; 
                                            background: linear-gradient(90deg, 
                                                {{ $maturityResults['overall_maturity'] >= 0.75 ? '#20c997' : 
                                                   ($maturityResults['overall_maturity'] >= 0.50 ? '#17a2b8' : 
                                                   ($maturityResults['overall_maturity'] >= 0.25 ? '#ffc107' : '#dc3545')) 
                                                }}, 
                                                {{ $maturityResults['overall_maturity'] >= 0.75 ? '#198754' : 
                                                   ($maturityResults['overall_maturity'] >= 0.50 ? '#117a8b' : 
                                                   ($maturityResults['overall_maturity'] >= 0.25 ? '#e0a800' : '#c82333')) 
                                                }}
                                            ); 
                                            border-radius: 15px;"
                                     aria-valuenow="{{ $maturityResults['overall_maturity'] * 100 }}" 
                                     aria-valuemin="0" aria-valuemax="100">
                                    <strong class="text-dark">{{ number_format($maturityResults['overall_maturity'] * 100, 1) }}%</strong>
                                </div>
                            </div>
                            <h3 class="mb-0 text-teal">
                                {{ number_format($maturityResults['overall_maturity'], 2) }}/1.00
                            </h3>
                        </div>
                        @php
                            $overallLevel = 'Initial';
                            $levelColor = 'danger';
                            $levelIcon = 'fa-times-circle';
                            if ($maturityResults['overall_maturity'] >= 0.75) {
                                $overallLevel = 'Advanced';
                                $levelColor = 'success';
                                $levelIcon = 'fa-check-double';
                            } elseif ($maturityResults['overall_maturity'] >= 0.50) {
                                $overallLevel = 'Intermediate';
                                $levelColor = 'info';
                                $levelIcon = 'fa-check-circle';
                            } elseif ($maturityResults['overall_maturity'] >= 0.25) {
                                $overallLevel = 'Basic';
                                $levelColor = 'warning';
                                $levelIcon = 'fa-exclamation-circle';
                            }
                        @endphp
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <span class="badge bg-{{ $levelColor }} text-dark">
                                    <i class="fas {{ $levelIcon }} me-1"></i>
                                    Current Level: {{ $overallLevel }}
                                </span>
                            </div>
                            <div>
                                <span class="badge bg-dark border border-teal">
                                    <i class="fas fa-layer-group text-teal me-1"></i>
                                    {{ $maturityResults['elements_started'] }}/{{ $maturityResults['total_elements'] }} elements started
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <div class="card bg-dark border-teal h-100">
                                <div class="card-body text-center py-3">
                                    <h2 class="text-teal mb-1">{{ $maturityResults['elements_started'] }}</h2>
                                    <small class="text-light">Elements Started</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-dark border-danger h-100">
                                <div class="card-body text-center py-3">
                                    <h2 class="text-danger mb-1">
                                        {{ $maturityResults['total_elements'] - $maturityResults['elements_started'] }}
                                    </h2>
                                    <small class="text-light">Elements Not Started</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-6">
                    <div class="card bg-dark border-teal h-100">
                        <div class="card-header bg-transparent border-teal">
                            <h6 class="mb-0 text-white">Domain Maturity Scores</h6>
                        </div>
                        <div class="card-body">
                            @foreach($maturityResults['domains']['levels'] as $domain => $score)
                            <div class="mb-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="text-light">{{ $domain }}</span>
                                    <span class="fw-bold text-teal">{{ number_format($score, 2) }}/3.00</span>
                                </div>
                                @php
                                    $percentage = ($score / 3) * 100;
                                    if ($score >= 2.5) {
                                        $color = 'bg-success';
                                        $levelName = 'Advanced';
                                    } elseif ($score >= 1.5) {
                                        $color = 'bg-info';
                                        $levelName = 'Intermediate';
                                    } elseif ($score >= 0.5) {
                                        $color = 'bg-warning';
                                        $levelName = 'Basic';
                                    } else {
                                        $color = 'bg-danger';
                                        $levelName = 'Initial';
                                    }
                                @endphp
                                <div class="progress bg-dark" style="height: 8px;">
                                    <div class="progress-bar {{ $color }}" 
                                         style="width: {{ $percentage }}%"
                                         title="{{ $levelName }}">
                                    </div>
                                </div>
                                <small class="text-light d-block mt-1">
                                    <i class="fas fa-{{ $score >= 2.5 ? 'check-double' : ($score >= 1.5 ? 'check-circle' : ($score >= 0.5 ? 'exclamation-circle' : 'times-circle')) }} 
                                       text-{{ $score >= 2.5 ? 'success' : ($score >= 1.5 ? 'info' : ($score >= 0.5 ? 'warning' : 'danger')) }} me-1"></i>
                                    {{ $levelName }}
                                </small>
                            </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div class="mt-4 pt-3 border-top border-secondary">
                <div class="d-flex flex-wrap justify-content-between">
                    <div class="mb-2 mb-md-0">
                        <a href="{{ route('assessment.maturity.dashboard', $assessment->id) }}" 
                           class="btn btn-primary">
                            <i class="fas fa-radar me-1"></i> View Detailed Maturity Dashboard
                        </a>
                        <a href="{{ route('assessment.maturity.data', $assessment->id) }}" 
                           class="btn btn-outline-light ms-2" target="_blank">
                            <i class="fas fa-code me-1"></i> View Raw Data
                        </a>
                    </div>
                    <form action="{{ route('assessment.calculate', $assessment->id) }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-outline-warning">
                            <i class="fas fa-redo me-1"></i> Recalculate Maturity
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @endif

    <!-- Questions Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0 text-white">
                <i class="fas fa-list-ol text-teal me-2"></i>
                Assessment Questions ({{ $assessment->responses->count() }})
            </h5>
        </div>
        <div class="card-body p-0">
            @if($assessment->responses->count() > 0)
            <div class="table-responsive">
                <table class="table table-dark table-hover mb-0">
                    <thead>
                        <tr>
                            <th width="60" class="ps-4">#</th>
                            <th>Domain</th>
                            <th>Category</th>
                            <th>Element</th>
                            <th>Question</th>
                            <th width="100">Response</th>
                            <th width="100" class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($assessment->responses as $response)
                        <tr class="align-middle">
                            <td class="ps-4">
                                <span class="fw-bold text-teal">#{{ $response->number }}</span>
                            </td>
                            <td>
                                <span class="badge bg-teal text-dark">{{ $response->domain }}</span>
                            </td>
                            <td>
                                <small class="text-light">{{ $response->category }}</small>
                            </td>
                            <td>
                                <span class="badge bg-info text-dark">{{ $response->element }}</span>
                            </td>
                            <td>
                                <div class="text-truncate text-white" style="max-width: 400px;" 
                                     title="{{ $response->question }}">
                                    {{ $response->question }}
                                </div>
                                @if($response->description)
                                <small class="text-light d-block">
                                    {{ Str::limit($response->description, 80) }}
                                </small>
                                @endif
                            </td>
                            <td>
                                @if($response->response === 'Yes')
                                <span class="badge bg-success text-dark">
                                    <i class="fas fa-check me-1"></i>Yes
                                </span>
                                @elseif($response->response === 'No')
                                <span class="badge bg-danger">
                                    <i class="fas fa-times me-1"></i>No
                                </span>
                                @else
                                <span class="badge bg-secondary">
                                    <i class="fas fa-minus me-1"></i>Not Answered
                                </span>
                                @endif
                            </td>
                            <td class="text-end pe-4">
                                <button type="button" class="btn btn-sm btn-outline-teal" 
                                        data-bs-toggle="tooltip" title="View Details"
                                        onclick="showQuestionDetails({{ json_encode($response) }})">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            @else
            <div class="text-center py-5">
                <div class="mb-4">
                    <i class="fas fa-inbox fa-3x text-secondary"></i>
                </div>
                <h5 class="text-white mb-2">No Questions Found</h5>
                <p class="text-light mb-0">This assessment doesn't have any questions yet.</p>
            </div>
            @endif
        </div>
        @if($assessment->responses->count() > 10)
        <div class="card-footer">
            <div class="d-flex justify-content-between align-items-center">
                <small class="text-light">
                    Showing all {{ $assessment->responses->count() }} questions.
                </small>
                <small class="text-muted">
                    Use browser search (Ctrl+F) to find specific questions
                </small>
            </div>
        </div>
        @endif
    </div>
</div>

<!-- Question Details Modal -->
<div class="modal fade" id="questionDetailsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark">
            <div class="modal-header border-secondary">
                <h5 class="modal-title text-white">Question Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <table class="table table-dark table-borderless">
                    <tr>
                        <th width="150" class="text-teal">Question #:</th>
                        <td id="modal-number" class="text-white fw-bold"></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Domain:</th>
                        <td><span class="badge bg-teal text-dark" id="modal-domain"></span></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Category:</th>
                        <td id="modal-category" class="text-light"></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Element:</th>
                        <td><span class="badge bg-info text-dark" id="modal-element"></span></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Description:</th>
                        <td id="modal-description" class="text-light"></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Question:</th>
                        <td id="modal-question" class="text-white"></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Response:</th>
                        <td id="modal-response"></td>
                    </tr>
                    <tr>
                        <th class="text-teal">Uploaded:</th>
                        <td id="modal-uploaded" class="text-light"></td>
                    </tr>
                </table>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-outline-light" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function showQuestionDetails(response) {
    document.getElementById('modal-number').textContent = response.number;
    document.getElementById('modal-domain').textContent = response.domain;
    document.getElementById('modal-category').textContent = response.category;
    document.getElementById('modal-element').textContent = response.element;
    document.getElementById('modal-description').textContent = response.description || 'N/A';
    document.getElementById('modal-question').textContent = response.question;
    
    // Format response with badge
    const responseCell = document.getElementById('modal-response');
    if (response.response === 'Yes') {
        responseCell.innerHTML = '<span class="badge bg-success text-dark"><i class="fas fa-check me-1"></i>Yes</span>';
    } else if (response.response === 'No') {
        responseCell.innerHTML = '<span class="badge bg-danger"><i class="fas fa-times me-1"></i>No</span>';
    } else {
        responseCell.innerHTML = '<span class="badge bg-secondary"><i class="fas fa-minus me-1"></i>Not Answered</span>';
    }
    
    // Format date
    const uploaded = new Date(response.uploaded_at);
    document.getElementById('modal-uploaded').textContent = 
        uploaded.toLocaleDateString() + ' ' + uploaded.toLocaleTimeString();
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('questionDetailsModal'));
    modal.show();
}

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>
@endpush

<style>
:root {
    --teal: #20c997;
    --teal-dark: #198754;
    --dark: #212529;
    --darker: #121416;
    --light-text: #e9ecef;
    --border-color: #343a40;
    --card-bg: #2c3034;
}

body {
    background-color: var(--darker);
}

/* Card Styling */
.card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    margin-bottom: 1.5rem;
}

.card-header {
    background: rgba(33, 37, 41, 0.9);
    border-bottom: 1px solid var(--border-color);
}

.border-left-teal {
    border-left: 0.25rem solid var(--teal) !important;
}

.border-left-success {
    border-left: 0.25rem solid #1cc88a !important;
}

.border-left-danger {
    border-left: 0.25rem solid #dc3545 !important;
}

.border-left-warning {
    border-left: 0.25rem solid #ffc107 !important;
}

.border-teal {
    border-color: var(--teal) !important;
}

/* Icon Circle */
.icon-circle {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
}

.bg-teal {
    background-color: var(--teal) !important;
}

/* Progress Bar */
.progress {
    background-color: rgba(255, 255, 255, 0.05);
    border-radius: 10px;
    overflow: visible;
}

.progress-bar {
    border-radius: 10px;
    position: relative;
    overflow: visible;
}

.progress-bar strong {
    position: absolute;
    right: 10px;
    color: var(--dark);
    font-weight: 600;
}

/* Table Styling */
.table-dark {
    --bs-table-bg: var(--darker);
    --bs-table-striped-bg: rgba(255, 255, 255, 0.05);
    --bs-table-hover-bg: rgba(32, 201, 151, 0.1);
    color: var(--light-text);
    border-color: var(--border-color);
}

.table-dark thead th {
    background-color: rgba(33, 37, 41, 0.9);
    border-color: var(--border-color);
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    color: var(--teal);
    padding: 0.75rem;
}

.table-dark td {
    border-color: var(--border-color);
    padding: 0.75rem;
    vertical-align: middle;
}

/* Badge Styling */
.badge {
    font-weight: 600;
    padding: 0.25em 0.6em;
    border-radius: 4px;
    font-size: 0.75rem;
}

.bg-teal {
    background-color: var(--teal) !important;
    color: var(--dark) !important;
}

.bg-success {
    background-color: #20c997 !important;
    color: var(--dark) !important;
}

.bg-info {
    background-color: #17a2b8 !important;
    color: var(--dark) !important;
}

.bg-warning {
    background-color: #ffc107 !important;
    color: var(--dark) !important;
}

.bg-danger {
    background-color: #dc3545 !important;
    color: white !important;
}

.bg-dark {
    background-color: var(--dark) !important;
    color: var(--light-text) !important;
}

/* Text Colors */
.text-teal {
    color: var(--teal) !important;
}

.text-white {
    color: white !important;
}

.text-light {
    color: var(--light-text) !important;
}

/* Button Styling */
.btn-primary {
    background: linear-gradient(135deg, var(--teal), var(--teal-dark));
    border: none;
    color: var(--dark);
    font-weight: 600;
}

.btn-primary:hover {
    background: linear-gradient(135deg, var(--teal-dark), #157347);
    color: var(--dark);
    transform: translateY(-1px);
    box-shadow: 0 4px 10px rgba(32, 201, 151, 0.3);
}

.btn-outline-light {
    color: rgba(255, 255, 255, 0.8);
    border-color: rgba(255, 255, 255, 0.3);
}

.btn-outline-light:hover {
    background: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.5);
    color: white;
}

.btn-outline-teal {
    color: var(--teal);
    border-color: var(--teal);
}

.btn-outline-teal:hover {
    background: var(--teal);
    color: var(--dark);
    border-color: var(--teal);
}

.btn-outline-warning {
    color: #ffc107;
    border-color: #ffc107;
}

.btn-outline-warning:hover {
    background: #ffc107;
    color: var(--dark);
    border-color: #ffc107;
}

.btn-outline-success {
    color: #20c997;
    border-color: #20c997;
}

.btn-outline-success:hover {
    background: #20c997;
    color: var(--dark);
    border-color: #20c997;
}

/* Modal Styling */
.modal-content {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
}

.modal-header, .modal-footer {
    border-color: var(--border-color);
}

/* Responsive */
@media (max-width: 768px) {
    .btn-group {
        flex-wrap: wrap;
    }
    
    .btn {
        margin-bottom: 0.25rem;
    }
    
    .table-responsive {
        font-size: 0.875rem;
    }
}
</style>
@endsection