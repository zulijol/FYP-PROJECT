{{-- resources/views/assessment/list.blade.php --}}
@extends('layouts.app')

@section('title', 'Assessment List')

@section('content')
<div class="container-fluid">
    <!-- Page Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
        <h1 class="h2 mb-0 text-white">
            <i class="fas fa-list me-2 text-teal"></i>All Assessments
        </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="{{ route('dashboard') }}" class="btn btn-outline-light">
                <i class="fas fa-arrow-left me-1"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <!-- Assessments Table Card -->
    <div class="card shadow-sm">
        <div class="card-header py-3">
            <h5 class="card-title mb-0 text-white">
                <i class="fas fa-file-excel text-teal me-2"></i>Uploaded Assessments
                <span class="badge bg-teal text-dark ms-2">{{ $assessments->total() }} total</span>
            </h5>
        </div>
        <div class="card-body p-0">
            @if($assessments->isEmpty())
                <div class="text-center py-5">
                    <div class="mb-4">
                        <i class="fas fa-file-excel fa-4x text-secondary opacity-50"></i>
                    </div>
                    <h4 class="text-white mb-3">No assessments found</h4>
                    <a href="{{ route('dashboard') }}" class="btn btn-outline-light">
                        <i class="fas fa-arrow-left me-1"></i> Return to Dashboard
                    </a>
                </div>
            @else
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Upload Date</th>
                                <th>File Name</th>
                                <th>Questions</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($assessments as $assessment)
                            <tr>
                                <td class="ps-4">
                                    <span class="fw-bold text-teal">#{{ $assessment->id }}</span>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span class="text-white">{{ $assessment->uploaded_at->format('d M Y') }}</span>
                                        <small class="text-light">{{ $assessment->uploaded_at->format('H:i A') }}</small>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-file-excel text-teal me-2"></i>
                                        <span class="text-white">{{ $assessment->filename }}</span>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-dark text-teal border border-teal">
                                        {{ $assessment->total_questions }}
                                    </span>
                                </td>
                                <td>
                                    @php
                                        $statusColors = [
                                            'imported' => 'teal',
                                            'in_review' => 'warning',
                                            'completed' => 'success',
                                            'not_reviewed' => 'secondary'
                                        ];
                                        $color = $statusColors[$assessment->status] ?? 'secondary';
                                    @endphp
                                    <span class="badge bg-{{ $color }} text-dark">
                                        {{ ucfirst(str_replace('_', ' ', $assessment->status)) }}
                                    </span>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
        
        @if($assessments->hasPages())
        <div class="card-footer">
            <div class="d-flex justify-content-center">
                {{ $assessments->links() }}
            </div>
        </div>
        @endif
    </div>
</div>

<style>
:root {
    --teal: #20c997;
    --dark: #212529;
    --card-bg: #2c3034;
    --border-color: #343a40;
}

.card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 10px;
}

.table-dark {
    --bs-table-bg: #121416;
    --bs-table-hover-bg: rgba(32, 201, 151, 0.1);
    color: #e9ecef;
}

.table-dark thead th {
    border-bottom: 2px solid var(--border-color);
    color: var(--teal);
    font-weight: 600;
}

.table-dark td {
    border-color: var(--border-color);
    padding: 1rem;
}

.bg-teal {
    background-color: var(--teal) !important;
    color: var(--dark) !important;
}

.text-teal {
    color: var(--teal) !important;
}
</style>
@endsection