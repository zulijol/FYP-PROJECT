<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recovery Code | NCSBAS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Same styles as above, you can copy from the two-factor-challenge file */
        /* ... paste all the CSS styles from the previous file ... */
    </style>
</head>

<body class="flex justify-center items-center min-h-screen p-4">
    <!-- Gradient Overlay -->
    <div class="gradient-overlay"></div>
    
    <!-- Animated Particles -->
    <div id="particles-container"></div>
    
    <div class="max-w-md w-full z-10">
        <!-- Recovery Code Card -->
        <div class="glass-card rounded-2xl p-8 space-y-6 relative overflow-hidden">
            <!-- Animated teal accent line at top -->
            <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-teal-500 to-transparent"></div>
            
            <!-- Header -->
            <div class="flex flex-col items-center space-y-4">
                <div class="w-16 h-16 rounded-full bg-gradient-to-br from-teal-700 to-teal-900 flex items-center justify-center teal-glow mb-2">
                    <i class="fas fa-key text-teal-300 text-2xl"></i>
                </div>
                <h1 class="text-3xl font-bold bg-gradient-to-r from-teal-400 via-teal-300 to-teal-200 bg-clip-text text-transparent ncsbas-text">NCSBAS</h1>
                <h2 class="text-2xl font-bold text-center text-slate-100">Recovery Code</h2>
                <p class="text-slate-300 text-center">Enter one of your recovery codes</p>
            </div>

            <!-- Session Status and Errors -->
            @if ($errors->any())
                <div class="p-4 rounded-xl bg-gradient-to-r from-rose-900/30 to-rose-800/20 border border-rose-700/30">
                    <div class="flex items-center text-rose-300">
                        <i class="fas fa-exclamation-triangle mr-3 text-xl"></i>
                        <div>
                            @foreach ($errors->all() as $error)
                                <p class="text-sm">{{ $error }}</p>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif

            <!-- Form -->
            <form method="POST" action="{{ url('/two-factor-challenge') }}" class="space-y-6">
                @csrf
                
                <!-- Recovery Code Input -->
                <div class="relative group">
                    <input 
                        type="text" 
                        name="recovery_code" 
                        required 
                        autofocus
                        placeholder="Enter recovery code"
                        class="w-full px-5 py-4 rounded-xl input-field text-slate-200 placeholder-slate-400 focus:outline-none group-hover:border-teal-400 transition-all duration-300"
                    >
                    @error('recovery_code')
                        <div class="flex items-center mt-2 text-rose-400 text-sm">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <span>{{ $message }}</span>
                        </div>
                    @enderror
                </div>

                <!-- Instructions -->
                <div class="p-4 rounded-xl bg-gradient-to-r from-slate-800/30 to-slate-700/20 border border-slate-700/30">
                    <div class="flex items-start">
                        <i class="fas fa-info-circle text-teal-400 mt-1 mr-3"></i>
                        <div>
                            <p class="text-sm text-slate-300">
                                Each recovery code can only be used once. 
                                After using a code, it will be removed from your list.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full py-4 text-slate-100 font-semibold rounded-xl teal-gradient-btn text-lg">
                    <i class="fas fa-unlock mr-2"></i>Use Recovery Code
                </button>
            </form>

            <!-- Back to OTP -->
            <div class="text-center pt-4 border-t border-slate-800/50">
                <a href="{{ route('two-factor.login') }}" class="inline-flex items-center text-sm teal-link hover:text-teal-300 transition-colors duration-300">
                    <i class="fas fa-arrow-left mr-2"></i>Back to authenticator code
                </a>
            </div>
            
            <!-- Security Status -->
            <div class="flex items-center justify-center pt-4">
                <div class="security-badge">
                    <i class="fas fa-shield-alt"></i>
                    <span>Emergency Access</span>
                </div>
            </div>
        </div>
        
        <!-- Footer note -->
        <p class="text-center text-slate-400 text-sm mt-6">
            <i class="fas fa-user-shield mr-1 text-teal-400"></i> Powered by NCSBAS - Secure Recovery
        </p>
    </div>

    <script>
        // Similar particles script as above
        // ... copy the particles script from previous file ...
    </script>
</body>
</html>