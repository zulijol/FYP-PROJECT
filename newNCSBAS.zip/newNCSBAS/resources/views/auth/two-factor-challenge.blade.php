<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Two-Factor Authentication | NCSBAS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Black & Teal gradient animation */
        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            25% { background-position: 50% 50%; }
            50% { background-position: 100% 50%; }
            75% { background-position: 50% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        body {
            background: linear-gradient(
                -45deg,
                #000000,    /* Pure Black */
                #0a1929,    /* Deep Navy Blue */
                #0d2538,    /* Dark Teal Blue */
                #0a2e2e,    /* Dark Forest Green */
                #083344,    /* Deep Ocean Blue */
                #134e4a,    /* Dark Emerald */
                #115e59,    /* Teal */
                #0f766e,    /* Medium Teal */
                #0d9488,    /* Bright Teal */
                #14b8a6,    /* Light Teal */
                #2dd4bf     /* Pale Teal */
            );
            background-size: 400% 400%;
            animation: gradientShift 20s ease infinite;
            color: #f8fafc;
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        /* Animated gradient overlay */
        .gradient-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                45deg,
                rgba(20, 184, 166, 0.1),
                rgba(13, 148, 136, 0.05),
                rgba(15, 118, 110, 0.03),
                transparent
            );
            pointer-events: none;
            z-index: -1;
        }
        
        /* Floating particles */
        .particle {
            position: fixed;
            background: rgba(20, 184, 166, 0.1);
            border-radius: 50%;
            pointer-events: none;
            z-index: -1;
        }
        
        .glass-card {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(45, 212, 191, 0.25);
            box-shadow: 
                0 10px 40px rgba(0, 0, 0, 0.4),
                0 0 40px rgba(20, 184, 166, 0.15),
                inset 0 1px 0 rgba(255, 255, 255, 0.1);
            transition: all 0.4s ease;
        }
        
        .glass-card:hover {
            border-color: rgba(94, 234, 212, 0.4);
            box-shadow: 
                0 15px 50px rgba(0, 0, 0, 0.5),
                0 0 60px rgba(20, 184, 166, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.15);
        }
        
        .teal-glow {
            box-shadow: 0 0 20px rgba(20, 184, 166, 0.5);
        }
        
        .input-field {
            background: rgba(30, 41, 59, 0.7);
            border: 1px solid rgba(94, 234, 212, 0.3);
            transition: all 0.3s ease;
        }
        
        .input-field:focus {
            background: rgba(30, 41, 59, 0.9);
            border-color: rgba(94, 234, 212, 0.6);
            box-shadow: 0 0 0 3px rgba(20, 184, 166, 0.3);
        }
        
        .teal-gradient-btn {
            background: linear-gradient(135deg, 
                #0d9488 0%, 
                #14b8a6 25%, 
                #2dd4bf 50%, 
                #14b8a6 75%, 
                #0d9488 100%);
            background-size: 200% auto;
            transition: all 0.4s ease;
            position: relative;
            overflow: hidden;
        }
        
        .teal-gradient-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, 
                transparent, 
                rgba(255, 255, 255, 0.2), 
                transparent);
            transition: 0.5s;
        }
        
        .teal-gradient-btn:hover::before {
            left: 100%;
        }
        
        .teal-gradient-btn:hover {
            background-position: right center;
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(20, 184, 166, 0.5);
        }
        
        .code-input {
            width: 50px;
            height: 60px;
            font-size: 24px;
            text-align: center;
            font-weight: bold;
            letter-spacing: 2px;
        }
        
        .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background-color: #14b8a6;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { 
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(20, 184, 166, 0.7); 
            }
            70% { 
                transform: scale(1);
                box-shadow: 0 0 0 10px rgba(20, 184, 166, 0); 
            }
            100% { 
                transform: scale(0.95);
                box-shadow: 0 0 0 0 rgba(20, 184, 166, 0); 
            }
        }
        
        .ncsbas-text {
            font-family: 'Arial', sans-serif;
            letter-spacing: 2px;
            font-weight: 800;
            text-shadow: 
                0 0 20px rgba(20, 184, 166, 0.5),
                0 0 40px rgba(20, 184, 166, 0.3);
            position: relative;
            display: inline-block;
        }
        
        .ncsbas-text::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: -5px;
            left: 0;
            background: linear-gradient(90deg, 
                transparent, 
                #5eead4, 
                #14b8a6, 
                #5eead4, 
                transparent);
            border-radius: 2px;
        }
        
        .teal-link {
            color: #5eead4;
            position: relative;
            text-decoration: none;
        }
        
        .teal-link:hover {
            color: #99f6e4;
        }
        
        .teal-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -2px;
            left: 0;
            background: linear-gradient(90deg, #5eead4, #14b8a6);
            transition: width 0.3s ease;
        }
        
        .teal-link:hover::after {
            width: 100%;
        }
        
        .otp-input-container {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        
        .code-input:focus {
            border-color: #5eead4;
            box-shadow: 0 0 0 3px rgba(94, 234, 212, 0.3);
            outline: none;
        }
        
        .security-badge {
            background: linear-gradient(135deg, #0f766e, #0d9488);
            border-radius: 50px;
            padding: 6px 16px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 0.875rem;
        }
    </style>
</head>

<body class="flex justify-center items-center min-h-screen p-4">
    <!-- Gradient Overlay -->
    <div class="gradient-overlay"></div>
    
    <!-- Animated Particles -->
    <div id="particles-container"></div>
    
    <div class="max-w-md w-full z-10">
        <!-- Two-Factor Authentication Card -->
        <div class="glass-card rounded-2xl p-8 space-y-6 relative overflow-hidden">
            <!-- Animated teal accent line at top -->
            <div class="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-teal-500 to-transparent"></div>
            
            <!-- Header -->
            <div class="flex flex-col items-center space-y-4">
                <div class="w-16 h-16 rounded-full bg-gradient-to-br from-teal-700 to-teal-900 flex items-center justify-center teal-glow mb-2">
                    <i class="fas fa-shield-alt text-teal-300 text-2xl"></i>
                </div>
                <h1 class="text-3xl font-bold bg-gradient-to-r from-teal-400 via-teal-300 to-teal-200 bg-clip-text text-transparent ncsbas-text">NCSBAS</h1>
                <h2 class="text-2xl font-bold text-center text-slate-100">Two-Factor Authentication</h2>
                <p class="text-slate-300 text-center">Enter the 6-digit code from your authenticator app</p>
            </div>

            <!-- Session Status and Errors -->
            @if ($errors->any())
                <div class="p-4 rounded-xl bg-gradient-to-r from-rose-900/30 to-rose-800/20 border border-rose-700/30">
                    <div class="flex items-center text-rose-300">
                        <i class="fas fa-exclamation-triangle mr-3 text-xl"></i>
                        <div>
                            @foreach ($errors->all() as $error)
                                <p class="text-sm">{{ $error }}</p>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif

            <!-- Form -->
            <form method="POST" action="{{ url('/two-factor-challenge') }}" class="space-y-6">
                @csrf
                
                <!-- Code Input -->
                <div class="space-y-4">
                    <div class="otp-input-container">
                        @for($i = 1; $i <= 6; $i++)
                            <input 
                                type="text" 
                                name="code[]" 
                                maxlength="1" 
                                class="code-input rounded-xl input-field text-slate-200 text-center focus:outline-none"
                                data-index="{{ $i-1 }}"
                                oninput="moveToNext(this, event)"
                                onkeydown="moveToPrevious(this, event)"
                                autofocus="{{ $i == 1 ? 'autofocus' : '' }}"
                            >
                        @endfor
                    </div>
                    
                    <!-- Hidden field for the full code -->
                    <input type="hidden" name="code" id="full-code">
                    
                    @error('code')
                        <div class="flex items-center mt-2 text-rose-400 text-sm">
                            <i class="fas fa-exclamation-circle mr-2"></i>
                            <span>{{ $message }}</span>
                        </div>
                    @enderror
                </div>

                <!-- Instructions -->
                <div class="p-4 rounded-xl bg-gradient-to-r from-slate-800/30 to-slate-700/20 border border-slate-700/30">
                    <div class="flex items-start">
                        <i class="fas fa-mobile-alt text-teal-400 mt-1 mr-3"></i>
                        <div>
                            <p class="text-sm text-slate-300">
                                Open your authenticator app (Google Authenticator, Authy, etc.) 
                                and enter the 6-digit verification code.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full py-4 text-slate-100 font-semibold rounded-xl teal-gradient-btn text-lg" onclick="submitForm()">
                    <i class="fas fa-check-circle mr-2"></i>Verify Code
                </button>
            </form>

            <!-- Recovery Option -->
            <div class="text-center pt-4 border-t border-slate-800/50">
                <p class="text-sm text-slate-300 mb-2">Can't access your authenticator?</p>
                <a href="{{ route('two-factor.recovery') }}" class="inline-flex items-center text-sm teal-link hover:text-teal-300 transition-colors duration-300">
                    <i class="fas fa-life-ring mr-2"></i>Use a recovery code
                </a>
            </div>
            
            <!-- Security Status -->
            <div class="flex items-center justify-center pt-4">
                <div class="security-badge">
                    <i class="fas fa-lock"></i>
                    <span>Enhanced Security Active</span>
                </div>
            </div>
        </div>
        
        <!-- Footer note -->
        <p class="text-center text-slate-400 text-sm mt-6">
            <i class="fas fa-user-shield mr-1 text-teal-400"></i> Powered by NCSBAS - Multi-Factor Authentication
        </p>
    </div>

    <script>
        // Create animated particles
        function createParticles() {
            const container = document.getElementById('particles-container');
            const particleCount = 20;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.classList.add('particle');
                
                const size = Math.random() * 60 + 10;
                particle.style.width = `${size}px`;
                particle.style.height = `${size}px`;
                particle.style.left = `${Math.random() * 100}vw`;
                particle.style.top = `${Math.random() * 100}vh`;
                particle.style.opacity = Math.random() * 0.1 + 0.05;
                
                const duration = Math.random() * 20 + 10;
                const delay = Math.random() * 5;
                
                particle.style.animation = `float ${duration}s ease-in-out ${delay}s infinite alternate`;
                container.appendChild(particle);
            }
            
            const style = document.createElement('style');
            style.textContent = `
                @keyframes float {
                    0% { transform: translate(0, 0) rotate(0deg); }
                    33% { transform: translate(${Math.random() * 60 - 30}px, ${Math.random() * 60 - 30}px) rotate(${Math.random() * 180}deg); }
                    66% { transform: translate(${Math.random() * 60 - 30}px, ${Math.random() * 60 - 30}px) rotate(${Math.random() * 180}deg); }
                    100% { transform: translate(0, 0) rotate(0deg); }
                }
            `;
            document.head.appendChild(style);
        }
        
        // OTP input handling
        function moveToNext(input, event) {
            const value = event.target.value;
            const index = parseInt(input.dataset.index);
            
            if (value.length === 1 && index < 5) {
                const nextInput = document.querySelector(`input[data-index="${index + 1}"]`);
                nextInput.focus();
                nextInput.select();
            }
            
            // Combine all digits
            combineCode();
        }
        
        function moveToPrevious(input, event) {
            const index = parseInt(input.dataset.index);
            
            if (event.key === 'Backspace' && input.value === '' && index > 0) {
                const prevInput = document.querySelector(`input[data-index="${index - 1}"]`);
                prevInput.focus();
                prevInput.select();
            }
            
            // Combine all digits
            if (event.key === 'Backspace') {
                setTimeout(combineCode, 10);
            }
        }
        
        function combineCode() {
            const inputs = document.querySelectorAll('input[name="code[]"]');
            let code = '';
            
            inputs.forEach(input => {
                code += input.value;
            });
            
            document.getElementById('full-code').value = code;
        }
        
        function submitForm() {
            combineCode();
            const fullCode = document.getElementById('full-code').value;
            
            if (fullCode.length === 6) {
                const btn = document.querySelector('button[type="submit"]');
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Verifying...';
                btn.disabled = true;
                
                setTimeout(() => {
                    btn.innerHTML = originalHTML;
                    btn.disabled = false;
                }, 3000);
            }
        }
        
        // Auto-focus first input
        document.addEventListener('DOMContentLoaded', function() {
            createParticles();
            document.querySelector('input[data-index="0"]').focus();
            
            // Paste handling
            document.addEventListener('paste', function(e) {
                e.preventDefault();
                const pastedData = e.clipboardData.getData('text').trim();
                
                if (/^\d{6}$/.test(pastedData)) {
                    const inputs = document.querySelectorAll('input[name="code[]"]');
                    inputs.forEach((input, index) => {
                        input.value = pastedData[index] || '';
                    });
                    combineCode();
                    document.querySelector('button[type="submit"]').focus();
                }
            });
        });
    </script>
</body>
</html>