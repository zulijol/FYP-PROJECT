<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Two-Factor | NCSBAS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Same styles as before -->
</head>
<body class="flex justify-center items-center min-h-screen p-4">
    <div class="max-w-2xl w-full z-10">
        <div class="glass-card rounded-2xl p-8 space-y-8">
            <!-- Header -->
            <div class="text-center">
                <h2 class="text-3xl font-bold text-slate-100 mb-2">Setup Two-Factor Authentication</h2>
                <p class="text-slate-300">Scan the QR code with your authenticator app</p>
            </div>
            
            <!-- QR Code -->
            <div class="flex flex-col md:flex-row gap-8 items-center">
                <div class="flex-1">
                    <div class="bg-white p-4 rounded-lg inline-block">
                        {!! $qrCode !!}
                    </div>
                </div>
                
                <div class="flex-1 space-y-4">
                    <div class="p-4 rounded-xl bg-gradient-to-r from-slate-800/30 to-slate-700/20 border border-slate-700/30">
                        <h3 class="text-teal-300 font-semibold mb-2"><i class="fas fa-list-ol mr-2"></i>Setup Instructions</h3>
                        <ol class="list-decimal pl-5 text-sm text-slate-300 space-y-2">
                            <li>Install Google Authenticator or Authy on your phone</li>
                            <li>Open the app and tap "Add Account"</li>
                            <li>Scan the QR code with your phone's camera</li>
                            <li>Enter the 6-digit code below to verify</li>
                        </ol>
                    </div>
                    
                    <!-- Manual Secret -->
                    <div class="p-4 rounded-xl bg-gradient-to-r from-slate-800/30 to-slate-700/20 border border-slate-700/30">
                        <h3 class="text-teal-300 font-semibold mb-2"><i class="fas fa-key mr