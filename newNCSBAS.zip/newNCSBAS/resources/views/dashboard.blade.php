{{-- resources/views/dashboard.blade.php --}}
@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="container-fluid">
    <!-- Dashboard Header -->
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-4">
        <h1 class="h2 mb-0 text-white">
            <i class="fas fa-tachometer-alt me-2 text-teal"></i>Dashboard
        </h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <div class="btn-group">
                <a href="{{ route('assessment.upload.form') }}" class="btn btn-primary">
                    <i class="fas fa-upload me-1"></i> Upload Assessment
                </a>
                <a href="{{ route('assessment.list') }}" class="btn btn-outline-light">
                    <i class="fas fa-list me-1"></i> View All
                </a>
            </div>
        </div>
    </div>

    <!-- Welcome Alert -->
    <div class="alert alert-info alert-dismissible fade show mb-4" role="alert">
        <div class="d-flex align-items-center">
            <div class="flex-shrink-0">
                <i class="fas fa-user-circle fa-2x me-3 text-teal"></i>
            </div>
            <div class="flex-grow-1">
                <h5 class="alert-heading mb-1 text-white">Welcome back, {{ auth()->user()->name }}!</h5>
                <p class="mb-0 text-light">You have uploaded <strong class="text-teal">{{ $totalUploads }}</strong> assessment(s) so far.</p>
            </div>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>

    <!-- Stats Cards Row -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-teal shadow-sm h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-teal text-uppercase mb-1">
                                Total Uploads
                            </div>
                            <div class="h3 mb-0 font-weight-bold text-white">{{ $totalUploads }}</div>
                            <div class="mt-2 mb-0">
                                <span class="text-light small">
                                    <i class="fas fa-file-excel me-1 text-teal"></i> Assessment Files
                                </span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-teal">
                                <i class="fas fa-upload text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow-sm h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Total Questions
                            </div>
                            <div class="h3 mb-0 font-weight-bold text-white">
                                {{ number_format($stats['total_questions'] ?? 0) }}
                            </div>
                            <div class="mt-2 mb-0">
                                <span class="text-light small">
                                    <i class="fas fa-question-circle me-1 text-success"></i> Imported Questions
                                </span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-success">
                                <i class="fas fa-chart-bar text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Recent Activity
                            </div>
                            <div class="h3 mb-0 font-weight-bold text-white">{{ $recentUploads->count() }}</div>
                            <div class="mt-2 mb-0">
                                <span class="text-light small">
                                    <i class="fas fa-history me-1 text-warning"></i> Last 10 uploads
                                </span>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-warning">
                                <i class="fas fa-clock text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow-sm h-100">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                Quick Actions
                            </div>
                            <div class="h6 mb-2 text-white">Manage Assessments</div>
                            <div class="mt-3">
                                <a href="{{ route('assessment.upload.form') }}" class="btn btn-sm btn-primary me-1 mb-1">
                                    <i class="fas fa-upload me-1"></i> Upload
                                </a>
                                <a href="{{ route('assessment.list') }}" class="btn btn-sm btn-outline-light me-1 mb-1">
                                    <i class="fas fa-history me-1"></i> View All
                                </a>
                                <button class="btn btn-sm btn-outline-secondary mb-1" data-bs-toggle="tooltip" title="Coming Soon">
                                    <i class="fas fa-chart-pie"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-auto">
                            <div class="icon-circle bg-info">
                                <i class="fas fa-bolt text-dark"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Uploads Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0 text-white">
                <i class="fas fa-history text-teal me-2"></i>Recent Assessments
            </h5>
            <a href="{{ route('assessment.list') }}" class="btn btn-sm btn-outline-light">
                <i class="fas fa-list me-1"></i> View All
            </a>
        </div>
        <div class="card-body p-0">
            @if($recentUploads->isEmpty())
                <div class="text-center py-5">
                    <div class="mb-4">
                        <i class="fas fa-file-excel fa-4x text-secondary opacity-50"></i>
                    </div>
                    <h4 class="text-white mb-3">No assessments uploaded yet</h4>
                    <p class="text-light mb-4">Get started by uploading your first assessment file.</p>
                    <a href="{{ route('assessment.upload.form') }}" class="btn btn-primary btn-lg">
                        <i class="fas fa-upload me-2"></i> Upload First Assessment
                    </a>
                </div>
            @else
                <div class="table-responsive">
                    <table class="table table-dark table-hover mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Upload Date</th>
                                <th>File Name</th>
                                <th>Questions</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($recentUploads as $upload)
                            <tr class="align-middle">
                                <td class="ps-4">
                                    <span class="fw-bold text-teal">#{{ $upload->id }}</span>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span class="fw-medium text-white">{{ $upload->uploaded_at->format('d M Y') }}</span>
                                        <small class="text-light">{{ $upload->uploaded_at->format('H:i A') }}</small>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-file-excel text-teal me-2"></i>
                                        <span class="text-truncate text-white" style="max-width: 200px;">
                                            {{ $upload->filename }}
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge bg-dark text-teal border border-teal">
                                        <i class="fas fa-question-circle me-1"></i>
                                        {{ $upload->total_questions }}
                                    </span>
                                </td>
                                <td>
                                    @php
                                        $statusConfig = [
                                            'imported' => ['color' => 'teal', 'icon' => 'fa-check-circle'],
                                            'in_review' => ['color' => 'warning', 'icon' => 'fa-clock'],
                                            'completed' => ['color' => 'success', 'icon' => 'fa-check-double'],
                                            'not_reviewed' => ['color' => 'secondary', 'icon' => 'fa-eye-slash']
                                        ];
                                        $config = $statusConfig[$upload->status] ?? ['color' => 'secondary', 'icon' => 'fa-question-circle'];
                                    @endphp
                                    <span class="badge bg-{{ $config['color'] }} text-dark">
                                        <i class="fas {{ $config['icon'] }} me-1"></i>
                                        {{ ucfirst(str_replace('_', ' ', $upload->status)) }}
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="{{ route('assessment.show', $upload->id) }}" 
                                           class="btn btn-outline-teal" 
                                           data-bs-toggle="tooltip" 
                                           title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <form action="{{ route('assessment.destroy', $upload->id) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                    class="btn btn-outline-danger"
                                                    data-bs-toggle="tooltip"
                                                    title="Delete"
                                                    onclick="return confirm('Are you sure you want to delete this assessment? This action cannot be undone.')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
        @if(!$recentUploads->isEmpty())
        <div class="card-footer border-top-0 pt-0">
            <div class="text-center">
                <a href="{{ route('assessment.list') }}" class="btn btn-link text-teal">
                    View All Assessments <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
        </div>
        @endif
    </div>

    <!-- Quick Guide Section -->
    <div class="row mt-2">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-header py-3">
                    <h5 class="card-title mb-0 text-white">
                        <i class="fas fa-info-circle text-info me-2"></i>Quick Guide
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-4">
                        <div class="col-lg-3 col-md-6">
                            <div class="d-flex flex-column align-items-center text-center p-3 h-100">
                                <div class="icon-wrapper mb-3">
                                    <div class="rounded-circle bg-teal bg-opacity-20 p-3 border border-teal">
                                        <i class="fas fa-upload fa-2x text-teal"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold mb-2 text-white">Upload Excel</h6>
                                <p class="small text-light mb-0 text-center">
                                    Use the provided template format with required columns for smooth import
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="d-flex flex-column align-items-center text-center p-3 h-100">
                                <div class="icon-wrapper mb-3">
                                    <div class="rounded-circle bg-success bg-opacity-20 p-3 border border-success">
                                        <i class="fas fa-chart-bar fa-2x text-success"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold mb-2 text-white">View Statistics</h6>
                                <p class="small text-light mb-0 text-center">
                                    Analyze detailed assessment data and track response rates
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="d-flex flex-column align-items-center text-center p-3 h-100">
                                <div class="icon-wrapper mb-3">
                                    <div class="rounded-circle bg-warning bg-opacity-20 p-3 border border-warning">
                                        <i class="fas fa-download fa-2x text-warning"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold mb-2 text-white">Download Reports</h6>
                                <p class="small text-light mb-0 text-center">
                                    Export assessment data as CSV files for further analysis
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="d-flex flex-column align-items-center text-center p-3 h-100">
                                <div class="icon-wrapper mb-3">
                                    <div class="rounded-circle bg-info bg-opacity-20 p-3 border border-info">
                                        <i class="fas fa-history fa-2x text-info"></i>
                                    </div>
                                </div>
                                <h6 class="fw-bold mb-2 text-white">Track Progress</h6>
                                <p class="small text-light mb-0 text-center">
                                    Monitor improvements and progress over time with historical data
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Custom Variables */
:root {
    --teal: #20c997;
    --teal-dark: #198754;
    --dark: #212529;
    --darker: #121416;
    --card-bg: #2c3034;
    --border-color: #343a40;
    --light-text: #e9ecef;
}

/* Card Styling */
.card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
}

.card-header {
    background: rgba(33, 37, 41, 0.8);
    border-bottom: 1px solid var(--border-color);
}

/* Border Left Colors */
.border-left-teal {
    border-left: 0.25rem solid var(--teal) !important;
}

.border-left-success {
    border-left: 0.25rem solid #1cc88a !important;
}

.border-left-warning {
    border-left: 0.25rem solid #f6c23e !important;
}

.border-left-info {
    border-left: 0.25rem solid #36b9cc !important;
}

/* Icon Circle */
.icon-circle {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
}

.bg-teal {
    background-color: var(--teal) !important;
}

.text-teal {
    color: var(--teal) !important;
}

.btn-outline-teal {
    color: var(--teal);
    border-color: var(--teal);
}

.btn-outline-teal:hover {
    background-color: var(--teal);
    color: var(--dark);
    border-color: var(--teal);
}

/* Table Styling */
.table-dark {
    --bs-table-bg: var(--darker);
    --bs-table-striped-bg: rgba(255, 255, 255, 0.05);
    --bs-table-hover-bg: rgba(32, 201, 151, 0.1);
    color: var(--light-text);
}

.table-dark thead th {
    background-color: rgba(33, 37, 41, 0.9);
    border-bottom: 2px solid var(--border-color);
    color: var(--teal);
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.75rem;
    letter-spacing: 0.5px;
    padding: 1rem;
}

.table-dark td {
    border-color: var(--border-color);
    padding: 1rem;
    vertical-align: middle;
}

/* Badge Styling */
.badge {
    font-weight: 600;
    padding: 0.4em 0.8em;
    border-radius: 6px;
}

.bg-teal {
    background-color: var(--teal) !important;
    color: var(--dark) !important;
}

.bg-success {
    background-color: #1cc88a !important;
    color: var(--dark) !important;
}

.bg-warning {
    background-color: #f6c23e !important;
    color: var(--dark) !important;
}

.bg-info {
    background-color: #36b9cc !important;
    color: var(--dark) !important;
}

.bg-dark {
    background-color: var(--dark) !important;
}

/* Button Group */
.btn-group-sm > .btn {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

/* Icon Wrapper Hover Effect */
.icon-wrapper .rounded-circle {
    transition: all 0.3s ease;
}

.icon-wrapper:hover .rounded-circle {
    transform: scale(1.1);
    box-shadow: 0 4px 15px rgba(32, 201, 151, 0.3);
}

/* Text Sizes */
.text-xs {
    font-size: 0.75rem;
}

.text-sm {
    font-size: 0.875rem;
}

/* Ensure Text Readability */
.text-white {
    color: white !important;
}

.text-light {
    color: var(--light-text) !important;
    opacity: 0.9;
}

/* Alert Styling */
.alert-info {
    background: rgba(32, 201, 151, 0.15);
    border: 1px solid rgba(32, 201, 151, 0.3);
    border-left: 4px solid var(--teal);
}

/* Hover Effects */
.btn-primary:hover, .btn-outline-light:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(32, 201, 151, 0.3);
    transition: all 0.3s ease;
}

/* Animation for Cards */
.card {
    animation: fadeInUp 0.5s ease-out;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
</style>

<script>
// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
    
    // Add animation to stats cards
    const statsCards = document.querySelectorAll('.card.border-left-teal, .card.border-left-success, .card.border-left-warning, .card.border-left-info');
    statsCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-5px)';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });
});
</script>
@endsection