// public/js/app.js - Main Application JavaScript

document.addEventListener('DOMContentLoaded', function() {
    console.log('NCSBAS Application Loaded');
    
    // ============================================
    // 1. Initialize Bootstrap Tooltips
    // ============================================
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // ============================================
    // 2. Auto-dismiss alerts after 5 seconds
    // ============================================
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
        alerts.forEach(function(alert) {
            try {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            } catch (e) {
                // If bootstrap.Alert fails, just hide it
                alert.style.transition = 'opacity 0.5s';
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            }
        });
    }, 5000);
    
    // ============================================
    // 3. Add active class to current page in navbar
    // ============================================
    var currentUrl = window.location.pathname;
    var navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(function(link) {
        if (link.getAttribute('href') === currentUrl) {
            link.classList.add('active');
        }
    });
    
    // ============================================
    // 4. Initialize Bootstrap Popovers
    // ============================================
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // ============================================
    // 5. Form validation feedback
    // ============================================
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // ============================================
    // 6. Dynamic table row selection
    // ============================================
    document.querySelectorAll('table tbody tr').forEach(function(row) {
        row.addEventListener('click', function() {
            this.classList.toggle('table-active');
        });
    });
    
    // ============================================
    // 7. Confirm before delete
    // ============================================
    document.querySelectorAll('form[data-confirm]').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            if (!confirm(this.getAttribute('data-confirm') || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });
    
    // ============================================
    // 8. Dashboard-specific animations
    // ============================================
    const statsCards = document.querySelectorAll('.card.border-left-teal, .card.border-left-success, .card.border-left-warning, .card.border-left-info');
    statsCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-5px)';
            card.style.transition = 'transform 0.3s ease';
        });
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    });
    
    // ============================================
    // 9. Fade-in animation for content
    // ============================================
    document.querySelectorAll('.fade-in').forEach(function(element) {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        
        setTimeout(function() {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }, 100);
    });
    
    // ============================================
    // 10. Password visibility toggle
    // ============================================
    document.querySelectorAll('.password-toggle').forEach(function(toggle) {
        toggle.addEventListener('click', function() {
            var input = document.querySelector(this.getAttribute('data-target'));
            var icon = this.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // ============================================
    // 11. Character counters for textareas
    // ============================================
    document.querySelectorAll('textarea[data-maxlength]').forEach(function(textarea) {
        var maxLength = parseInt(textarea.getAttribute('data-maxlength'));
        var counterId = textarea.id + '-counter';
        var counter = document.getElementById(counterId);
        
        if (!counter) {
            counter = document.createElement('div');
            counter.className = 'form-text text-end small';
            counter.id = counterId;
            textarea.parentNode.appendChild(counter);
        }
        
        function updateCounter() {
            var length = textarea.value.length;
            counter.textContent = length + ' / ' + maxLength + ' characters';
            counter.style.color = length > maxLength ? '#dc3545' : '#6c757d';
        }
        
        textarea.addEventListener('input', updateCounter);
        updateCounter();
    });
    
    // ============================================
    // 12. Smooth scroll to top button
    // ============================================
    var scrollToTopBtn = document.getElementById('scrollToTop');
    if (!scrollToTopBtn) {
        scrollToTopBtn = document.createElement('button');
        scrollToTopBtn.id = 'scrollToTop';
        scrollToTopBtn.className = 'btn btn-primary btn-sm rounded-circle';
        scrollToTopBtn.innerHTML = '<i class="fas fa-chevron-up"></i>';
        scrollToTopBtn.style.position = 'fixed';
        scrollToTopBtn.style.bottom = '20px';
        scrollToTopBtn.style.right = '20px';
        scrollToTopBtn.style.zIndex = '1000';
        scrollToTopBtn.style.display = 'none';
        document.body.appendChild(scrollToTopBtn);
        
        scrollToTopBtn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                scrollToTopBtn.style.display = 'block';
            } else {
                scrollToTopBtn.style.display = 'none';
            }
        });
    }
});

// ============================================
// Utility Functions
// ============================================

/**
 * Show a toast notification
 * @param {string} message - The message to display
 * @param {string} type - success, error, warning, info
 * @param {number} duration - Duration in milliseconds
 */
function showToast(message, type = 'info', duration = 3000) {
    const toastContainer = document.getElementById('toast-container') || createToastContainer();
    const toastId = 'toast-' + Date.now();
    
    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `;
    
    toastContainer.appendChild(toast);
    
    const bsToast = new bootstrap.Toast(toast, { delay: duration });
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', function() {
        toast.remove();
    });
}

/**
 * Create toast container if it doesn't exist
 */
function createToastContainer() {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    container.style.zIndex = '1055';
    document.body.appendChild(container);
    return container;
}

/**
 * Format date to readable string
 */
function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-MY', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/**
 * Copy text to clipboard
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        showToast('Copied to clipboard!', 'success');
    }).catch(function(err) {
        console.error('Failed to copy: ', err);
        showToast('Failed to copy to clipboard', 'error');
    });
}