    // Create data flow animation
        function createDataFlow() {
            const container = document.getElementById('data-flow-container');
            const nodeCount = 50;
            
            for (let i = 0; i < nodeCount; i++) {
                const node = document.createElement('div');
                node.classList.add('data-node');
                
                // Random position and animation
                const startX = Math.random() * 100;
                const targetX = Math.random() * 100;
                const delay = Math.random() * 15;
                const duration = 15 + Math.random() * 10;
                
                node.style.setProperty('--tx', targetX / 100);
                node.style.left = `${startX}vw`;
                node.style.animationDelay = `${delay}s`;
                node.style.animationDuration = `${duration}s`;
                
                container.appendChild(node);
            }
        }
        
        // Animate counters
        function animateCounter(elementId, target, suffix = '') {
            const element = document.getElementById(elementId);
            let current = 0;
            const increment = target / 100;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    element.textContent = target + suffix;
                    clearInterval(timer);
                } else {
                    element.textContent = Math.floor(current) + suffix;
                }
            }, 20);
        }
        
        // Smooth scrolling for anchor links
        function initSmoothScroll() {
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    if (targetId === '#') return;
                    
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 80,
                            behavior: 'smooth'
                        });
                    }
                });
            });
        }
        
        // Initialize everything
        document.addEventListener('DOMContentLoaded', function() {
            createDataFlow();
            initSmoothScroll();
            
            // Animate stats counters
            setTimeout(() => {
                animateCounter('orgs-count', 125, '+');
                animateCounter('assessments-count', 850, '+');
            }, 1000);
            
            // Add hover effects to feature cards
            const cards = document.querySelectorAll('.feature-card');
            cards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.classList.add('security-glow');
                });
                
                card.addEventListener('mouseleave', function() {
                    this.classList.remove('security-glow');
                });
            });
            
            // Navbar scroll effect
            const navbar = document.querySelector('nav');
            window.addEventListener('scroll', () => {
                if (window.scrollY > 50) {
                    navbar.classList.add('glass-card');
                } else {
                    navbar.classList.remove('glass-card');
                }
            });
        });