<?php
// routes/web.php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\AssessmentController;
use App\Http\Controllers\ChatbotController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\ReviewerController;
use App\Http\Controllers\TwoFactorController;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// =============================================
// 1. LOAD FORTIFY AUTHENTICATION ROUTES
// =============================================
require __DIR__.'/../vendor/laravel/fortify/routes/routes.php';

// =============================================
// 2. PUBLIC ROUTES (No authentication required)
// =============================================

Route::get('/', function () {
    return view('welcome');
})->name('home');

// =============================================
// 3. EMAIL VERIFICATION ROUTES
// =============================================
Route::middleware(['auth'])->group(function () {
    // Email verification notice
    Route::get('/email/verify', function () {
        return view('auth.verify-email');
    })->name('verification.notice');
    
    // Email verification handler
    Route::get('/email/verify/{id}/{hash}', function (EmailVerificationRequest $request) {
        $request->fulfill();
        return redirect('/dashboard')->with('status', 'Email verified successfully!');
    })->middleware(['signed'])->name('verification.verify');
    
    // Resend verification email
    Route::post('/email/verification-notification', function (Request $request) {
        $request->user()->sendEmailVerificationNotification();
        return back()->with('status', 'Verification link sent!');
    })->middleware(['throttle:6,1'])->name('verification.send');
});

// =============================================
// 4. TWO-FACTOR CHALLENGE ROUTES (for login)
// =============================================
Route::middleware(['guest'])->group(function () {
    Route::get('/two-factor-challenge', function () {
        return view('auth.two-factor-challenge');
    })->name('two-factor.login');
    
    Route::get('/two-factor-recovery', function () {
        return view('auth.two-factor-recovery');
    })->name('two-factor.recovery');
});

// =============================================
// 5. AUTHENTICATED ROUTES (Require login)
// =============================================
Route::middleware(['auth', 'verified'])->group(function () {  // Added 'verified' middleware
    
    // =============================================
    // DASHBOARD (All authenticated users)
    // =============================================
    Route::get('/dashboard', function () {
        $user = auth()->user();
        
        if ($user->hasRole('reviewer')) {
            return redirect()->route('review.dashboard');
        }
        
        if ($user->hasRole('assessor')) {
            return app(DashboardController::class)->index();
        }
        
        if ($user->hasRole('admin')) {
            return redirect()->route('admin.dashboard');
        }
        
        // Default fallback
        return app(DashboardController::class)->index();
    })->name('dashboard');
    
    // =============================================
    // TWO-FACTOR AUTHENTICATION ROUTES
    // =============================================
    Route::prefix('two-factor')->name('two-factor.')->group(function () {
        // Two-factor setup
        Route::get('/enable', [TwoFactorController::class, 'enable'])->name('enable');
        Route::post('/confirm', [TwoFactorController::class, 'confirm'])->name('confirm');
        
        // Two-factor management
        Route::post('/disable', [TwoFactorController::class, 'disable'])->name('disable');
        
        // Recovery codes
        Route::get('/recovery-codes', [TwoFactorController::class, 'showRecoveryCodes'])->name('recovery-codes');
        Route::post('/new-recovery-codes', [TwoFactorController::class, 'generateNewRecoveryCodes'])->name('new-recovery-codes');
    });
    
    // =============================================
    // ASSESSOR-ONLY ROUTES
    // =============================================
    Route::middleware(['role:assessor'])->group(function () {
        Route::prefix('assessment')->name('assessment.')->group(function () {
            Route::get('/upload', [AssessmentController::class, 'showUploadForm'])->name('upload.form');
            Route::post('/upload', [AssessmentController::class, 'upload'])->name('upload');
            Route::get('/list', [AssessmentController::class, 'list'])->name('list');
            Route::get('/{id}', [AssessmentController::class, 'show'])->name('show');
            Route::get('/{id}/stats', [AssessmentController::class, 'stats'])->name('stats');
            
            // PDF Report Routes (replacing CSV download)
            Route::get('/{id}/download-pdf', [AssessmentController::class, 'downloadPdfReport'])
                ->name('download.pdf');
            Route::get('/{id}/view-pdf', [AssessmentController::class, 'viewPdfReport'])
                ->name('view.pdf');
            
            Route::delete('/{id}', [AssessmentController::class, 'destroy'])->name('destroy');
            
            // Maturity Calculation
            Route::get('/{id}/maturity', [AssessmentController::class, 'showMaturityDashboard'])
                ->name('maturity.dashboard');
            Route::post('/{id}/calculate', [AssessmentController::class, 'calculateMaturity'])
                ->name('calculate');
            Route::get('/{id}/maturity-data', [AssessmentController::class, 'getMaturityData'])
                ->name('maturity.data');
            
        });
    });
    
    // =============================================
    // REVIEWER ROUTES
    // =============================================
    Route::middleware(['role:reviewer'])->group(function () {
        Route::prefix('review')->name('review.')->group(function () {
            // Reviewer Dashboard
            Route::get('/dashboard', [ReviewerController::class, 'dashboard'])->name('dashboard');
            
            // List assessments needing review
            Route::get('/assessments', [ReviewerController::class, 'index'])->name('assessments');
            
            // View assessment details
            Route::get('/assessment/{id}', [ReviewerController::class, 'show'])->name('show');
            
            // Update assessment status
            Route::post('/assessment/{id}/update-status', [ReviewerController::class, 'updateStatus'])
                ->name('update.status');
            
            // Mark as reviewed (quick action)
            Route::post('/assessment/{id}/mark-reviewed', [ReviewerController::class, 'markAsReviewed'])
                ->name('mark.reviewed');
        });
    });
    
    // =============================================
    // ADMIN ROUTES - SIMPLIFIED
    // =============================================
    Route::middleware(['role:admin'])->group(function () {
        Route::prefix('admin')->name('admin.')->group(function () {
            // Admin Dashboard (main page with user list)
            Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');
            
            // Update user role
            Route::post('/users/{id}/update-role', [AdminController::class, 'updateUserRole'])
                ->name('users.updateRole');
            
            // Delete user
            Route::delete('/users/{id}', [AdminController::class, 'deleteUser'])
                ->name('users.delete');
        });
    });
    
    // =============================================
    // CHATBOT ROUTES
    // =============================================
    Route::post('/chatbot/message', [ChatbotController::class, 'message'])
        ->name('chatbot.message');
});

// =============================================
// 6. TEST EMAIL ROUTE (for debugging)
// =============================================
Route::get('/test-email-simple', function () {
    try {
        // Simple test without creating Mail class
        \Illuminate\Support\Facades\Mail::raw('Hello, this is a test email from Laravel with XAMPP!', function ($message) {
            $message->to(config('mail.from.address'))  // Send to yourself
                    ->subject('Test Email from Laravel');
        });
        
        return 'Test email sent! Check your inbox and spam folder.';
    } catch (\Exception $e) {
        return 'Error: ' . $e->getMessage() . 
               '<br>Check: 1. App Password 2. .env file 3. Cache cleared';
    }
})->name('test.email');

// =============================================
// 7. EMAIL DEBUG ROUTE
// =============================================
Route::get('/mail-debug', function () {
    echo "<h2>Email Configuration Debug</h2>";
    
    // Check .env values
    echo "MAIL_MAILER: " . config('mail.mailer') . "<br>";
    echo "MAIL_HOST: " . config('mail.mailers.smtp.host') . "<br>";
    echo "MAIL_PORT: " . config('mail.mailers.smtp.port') . "<br>";
    echo "MAIL_USERNAME: " . config('mail.mailers.smtp.username') . "<br>";
    echo "MAIL_ENCRYPTION: " . config('mail.mailers.smtp.encryption') . "<br>";
    
    // Test connection
    try {
        $transport = new \Swift_SmtpTransport(
            config('mail.mailers.smtp.host'),
            config('mail.mailers.smtp.port'),
            config('mail.mailers.smtp.encryption')
        );
        
        $transport->setUsername(config('mail.mailers.smtp.username'));
        $transport->setPassword(config('mail.mailers.smtp.password'));
        
        $mailer = new \Swift_Mailer($transport);
        $mailer->getTransport()->start();
        
        echo "<br><span style='color:green;'>✓ SMTP Connection Successful!</span>";
    } catch (\Exception $e) {
        echo "<br><span style='color:red;'>✗ SMTP Connection Failed: " . $e->getMessage() . "</span>";
    }
})->name('mail.debug');

// =============================================
// 8. FALLBACK ROUTE
// =============================================
Route::fallback(function () {
    return redirect()->route('home');
});